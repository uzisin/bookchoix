<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package BookChoix WordPress theme
 */

$settings = acmthemes_settings();

if( isset( $settings['enable_offcanvas_shop_sidebar'] ) && 1 == $settings['enable_offcanvas_shop_sidebar'] ) {

	$sidebar_class = 'offcanvas-left';


	?>
	<?php do_action( 'before_sidebar' ); ?>

	<aside id="offcanvas-sidebar" class="offcanvas-sidebar widget-area <?php echo wp_kses_post( $sidebar_class ); ?>" <?php acmthemes_schema_markup( 'sidebar' ); ?>>

		<?php do_action( 'before_sidebar_inner' ); ?>

		<div id="sidebar-inner" class="clr">

			<div class="offcanvas-close-btn">
				<a class="acmthemes-off-canvas-hide" href="#"><i class="icon-close"></i></a>
			</div>

			<?php
				dynamic_sidebar( 'off_canvas' );
			?>

		</div><!-- #sidebar-inner -->

		<?php do_action( 'after_sidebar_inner' ); ?>

	</aside><!-- #right-sidebar -->

	<?php do_action( 'after_sidebar' ); 

}
