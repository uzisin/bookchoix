<?php
/**
 * Single product template.
 *
 * @package BookChoix WordPress theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

	global $product;

	//get framework settings
  $settings = acmthemes_settings();

  do_action( 'before_woo_single_product_content' );

  woocommerce_template_single_title();

	//display authors links
	bookchoix_add_authors_link();

	//display publisher link
	bookchoix_add_publisher_link();

  woocommerce_template_single_rating();

	$bkc_single_product_price = apply_filters( 'bookchoix_product_price_tag', true );

	if( $bkc_single_product_price )
  	woocommerce_template_single_price();

  $single_product_content_class = 'woo-single-product-content-full';
?>

<div class="<?php echo esc_attr( $single_product_content_class ); ?>">
  <?php

    the_content();

		if( ! isset( $settings['shop_type'] ) || 'default' == $settings['shop_type'] || $product->is_type('external') ) {
			do_action( 'bookchoix_woo_single_add_to_cart' );
		}

   ?>
</div>

<?php
	do_action( 'bookchoix_woo_single_quick_features' );

  //show custom product meta
	acmthemes_show_single_product_meta();

  do_action( 'after_woo_single_product_content' );
