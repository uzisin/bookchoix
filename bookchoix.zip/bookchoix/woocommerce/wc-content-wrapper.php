<?php
/**
 * After Container template.
 *
 * @package BookChoix WordPress theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
} ?>

<?php do_action( 'before_content_wrap' ); ?>

<?php
$settings = acmthemes_settings();
?>

<div id="content-wrap" class="main-content-wrap woo-content-wrap container clr">

	<?php do_action( 'before_primary' ); ?>

	<div id="primary" class="<?php echo acmthemes_shop_content_area_class(); ?> clr">

		<?php do_action( 'before_content' ); ?>

		<div id="content" class="clr site-content">

			<?php do_action( 'before_content_inner' ); ?>

			<article class="entry-content entry clr">
