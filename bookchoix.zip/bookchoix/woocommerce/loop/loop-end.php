<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     9999
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</div>
