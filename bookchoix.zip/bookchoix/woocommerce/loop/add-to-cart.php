<?php
/**
 * Loop Add to Cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/add-to-cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @package 	WooCommerce/Templates
 * @version   9999
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;

$classes = array();
$classes[] = 'btn-add-to-cart';

if( $product->is_type('simple') ) {
	$classes[] = 'ajax_add_to_cart';
	$classes[] = 'add_to_cart_button';
}


$classes = implode( ' ', $classes );

echo apply_filters(
	'woocommerce_loop_add_to_cart_link', // WPCS: XSS ok.
	sprintf(
		'<span class="info-balloon">%s</span><span class="info-balloon-view-cart">%s</span><a href="%s" data-quantity="%s" class="%s" %s><span class="icon icon-basket-loaded"></span></a>',
		esc_html( $product->add_to_cart_text() ),
		esc_html__( 'View cart', 'bookchoix' ),
		esc_url( $product->add_to_cart_url() ),
		esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
		esc_attr( $classes ),
		isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : ''
	),
	$product,
	$args
);

echo '<div class="add-to-cart-in-compare">';

//get product url
$id = $product->get_id();
$product_url = get_permalink( $id );

echo apply_filters(
	'woocommerce_loop_add_to_cart_link', // WPCS: XSS ok.
	sprintf(
		'<a href="%s" data-quantity="%s" class="button" %s><span>%s</span></a>',
		esc_url( $product_url ),
		esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
		isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
		esc_html( $product->add_to_cart_text() )
	),
	$product,
	$args
);

echo '</div>';
