<?php
/**
 * Image Swap style thumbnail
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Return dummy image if no featured image is defined
if ( ! has_post_thumbnail() ) {

	acmthemes_woo_placeholder_img();
	return; 
	
}

$settings = acmthemes_settings();
//set product grid image size
$prod_grid_img_size = 'bookchoix_single_product';

if( isset( $settings['prod_grid_img_size'] ) ) {

  if ( $settings['prod_grid_img_size'] == 'full' ) {
    $prod_grid_img_size = 'full';
  }
  elseif ( $settings['prod_grid_img_size'] == 'small' ) {
    $prod_grid_img_size = 'bookchoix_catalog_thumb';
  }
  else {
    $prod_grid_img_size = 'bookchoix_single_product';
  }

}

//book image shadow effect
$grid_img_effect_class = ' sh-effect ';
if( isset( $settings['prod_grid_img_effect'] ) && 'yes' == $settings['prod_grid_img_effect'] )  {
	$grid_img_effect_class = ' sh-effect ';
}
elseif( isset( $settings['prod_grid_img_effect'] ) && 'no' == $settings['prod_grid_img_effect'] )  {
	$grid_img_effect_class = '';
}

$shop_catalog_thumb_size = apply_filters( 'shop_catalog_thumb_size', $prod_grid_img_size );

// Globals
global $product;

// Get first image
$attachment = get_post_thumbnail_id();

//image flip class
$flip_class = 'has-noflip-image';

// Get Second Image in Gallery
if ( version_compare( ACMTHEMES_WOOCOMMERCE_CONFIG::get_wc_version(), '2.7', '>=' ) ) {
	$attachment_ids   = $product->get_gallery_image_ids();
} else {
	$attachment_ids   = $product->get_gallery_attachment_ids();
}
$attachment_ids[] = $attachment; // Add featured image to the array
$secondary_img_id = '';

if ( ! empty( $attachment_ids ) ) {
	$attachment_ids = array_unique( $attachment_ids ); // remove duplicate images
	if ( count( $attachment_ids ) > '1' ) {
		$flip_class = 'has-flip-image';
		if ( $attachment_ids['0'] !== $attachment ) {
			$secondary_img_id = $attachment_ids['0'];
		} elseif ( $attachment_ids['1'] !== $attachment ) {
			$secondary_img_id = $attachment_ids['1'];
		}
	}
}

// Image args
$first_img = array(
    'class'         => 'product-image-back-main',
    'alt'           => get_the_title(),
);
if ( acmthemes_get_schema_markup( 'image' ) ) {
	$first_img['itemprop'] = 'image';
}

$second_img = array(
    'class'         => 'product-image-back',
    'alt'           => get_the_title(),
);
if ( acmthemes_get_schema_markup( 'image' ) ) {
	$second_img['itemprop'] = 'image';
}

// Return thumbnail
if ( $secondary_img_id ) : ?>

	<?php do_action( 'before_product_entry_image' ); ?>

	<a href="<?php the_permalink(); ?>" class="woocommerce-LoopProduct-link">
		<figure class="<?php echo esc_attr( $flip_class ); ?><?php echo esc_attr( $grid_img_effect_class ); ?> clr">
		<?php
		// Main Image
		if ( ! empty( get_the_post_thumbnail( $product->get_id(), $shop_catalog_thumb_size ) ) ) {
			echo wp_get_attachment_image( $attachment, $shop_catalog_thumb_size, '', $first_img );
		}
		else
			echo acmthemes_get_placeholder( 'placeholder-265x330.png' );

		// Secondary Image
		echo wp_get_attachment_image( $secondary_img_id, $shop_catalog_thumb_size, '', $second_img ); ?>
		</figure>
	</a><!-- woo-image-swap -->

	<?php do_action( 'after_product_entry_image' ); ?>

<?php else : ?>

	<?php do_action( 'before_product_entry_image' ); ?>

	<a href="<?php the_permalink(); ?>" class="woocommerce-LoopProduct-link">
		<figure class="<?php echo esc_attr( $flip_class ); ?><?php echo esc_attr( $grid_img_effect_class ); ?> clr">
		<?php
		// Main Image
		if ( ! empty( get_the_post_thumbnail( $product->get_id(), $shop_catalog_thumb_size ) ) ) {
			echo get_the_post_thumbnail( $product->get_id(), $shop_catalog_thumb_size, array( "class" => "product-image-front" ));
		}
		else
			echo acmthemes_get_placeholder( 'placeholder-265x330.png' );
	 ?>
		</figure>
	</a><!-- woo-image-swap -->

	<?php do_action( 'after_product_entry_image' ); ?>

<?php endif;
