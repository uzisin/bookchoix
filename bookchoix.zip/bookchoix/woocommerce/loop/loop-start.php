<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     9999
 */

//get framework settings
$settings = acmthemes_settings();

$match_grid_class = ( isset( $settings['prod_grid_enable_matchheight'] ) && $settings['prod_grid_enable_matchheight'] == 1 ) ? 'match-grids' : '';

// Classes
$wrap_classes = array( 'products', 'acmthemes-row', 'clr', $match_grid_class );

// List/grid style
if ( ( acmthemes_is_woo_shop() || acmthemes_is_woo_tax() )
	&& isset( $settings['shop_showcase_type'] ) && $settings['shop_showcase_type'] == 'list' ) {
	$wrap_classes[] = 'list';
} else {
	$wrap_classes[] = 'grid';
}

//book background hover effect class
if ( isset( $settings['shop_grid_hover_effect'] ) && 'off' == $settings['shop_grid_hover_effect'] ) {    
}
else {
  $wrap_classes[] = 'hover-effect-on';
}

$wrap_classes = implode( ' ', $wrap_classes ); ?>

<div class="grid-style-1 <?php echo esc_attr( $wrap_classes ); ?>">
