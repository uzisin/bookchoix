<?php
/**
 * Product loop sale flash
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version   9999
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$settings = acmthemes_settings();

if( isset( $settings['disable_sale_badge_ingrid'] ) && $settings['disable_sale_badge_ingrid'] == 1 )
return;

global $post, $product;

if ( ! $product->is_in_stock() ) return;
if ( ! $product->is_on_sale() ) return;

/*show sale badge label
*
* @since 1.0.0
*/
if( isset( $settings['sale_badge_type'] ) && 'percent' == $settings['sale_badge_type'] ) {
  /*
  ** show product discount percentage
  *
  * @since 1.0.0
  */
  $sale_percent = 0;
  if ( $product->is_type( 'simple' ) ) {
   $sale_percent = ( ( $product->get_regular_price() - $product->get_sale_price() ) / $product->get_regular_price() ) * 100;
  }
  elseif ( $product->is_type( 'variable' ) ) {

   $sale_percent = 0;
   foreach ( $product->get_children() as $child_id ) {
      $variation = wc_get_product( $child_id );
      $price = $variation->get_regular_price();
      $sale = $variation->get_sale_price();
      if ( $price != 0 && ! empty( $sale ) )
        $percent = ( $price - $sale ) / $price * 100;
      if( !empty( $percent ) ) {
        if ( $percent > $sale_percent ) {
           $sale_percent = $percent;
        }
      }
   }

  }

  if( !empty( $sale_percent ) )
    echo apply_filters( 'woocommerce_sale_flash', '<div class="on-sale-wrap"><span class="on-sale"><span>-' . ceil($sale_percent) . '%</span></span></div>', $post, $product );

}
else {
  echo apply_filters( 'woocommerce_sale_flash', '<div class="on-sale-wrap"><span class="on-sale on-sale-label">' . esc_html__( 'Sale', 'bookchoix' ) . '</span></div>', $post, $product );
}
