<?php
/**
 * Quick view template.
 *
 * @package BookChoix WordPress theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
} ?>

<div id="acm-quickview-wrap">
	<div class="acm-quickview-container">
		<div class="acm-quickview-contentwrap">
			<div class="acm-quickview-content-inner">
				<a href="#" class="acm-quickview-close">×</a>
				<div id="acm-quickview-content" class="woocommerce single-product"></div>
			</div>
		</div>
	</div>
	<div class="acm-quickview-overlay"></div>
</div>
