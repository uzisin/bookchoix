<?php
/**
 * Single Product title
 *
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 9999
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// Heading tag
$heading = 'h1';
$heading = apply_filters( 'woo_product_title_tag', $heading ); ?>

<<?php echo esc_attr( $heading ); ?> class="single-post-title product_title entry-title"<?php acmthemes_schema_markup( 'author_name' ); ?>><?php the_title(); ?></<?php echo esc_attr( $heading ); ?>>
