<?php
/**
 * The template for displaying product content within loops.
 * Grid Style 2
 * Override this template by copying it to bookchoix/woocommerce/content-product.php
 *
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 99999
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

//get framework settings
$settings = acmthemes_settings();

//set product grid image size
$prod_grid_img_size = 'bookchoix_single_product';

if (isset($settings['prod_grid_img_size'])) {

	if ($settings['prod_grid_img_size'] == 'full') {
		$prod_grid_img_size = 'full';
	} elseif ($settings['prod_grid_img_size'] == 'small') {
		$prod_grid_img_size = 'bookchoix_catalog_thumb';
	} else {
		$prod_grid_img_size = 'bookchoix_single_product';
	}

}

//book image shadow effect
$grid_img_effect_class = '';
if (isset($settings['prod_grid_img_effect']) && 'yes' == $settings['prod_grid_img_effect']) {
	$grid_img_effect_class = ' sh-effect ';
} elseif (isset($settings['prod_grid_img_effect']) && 'no' == $settings['prod_grid_img_effect']) {
	$grid_img_effect_class = '';
}

$carousel_catalog_thumb_size = apply_filters('carousel_catalog_thumb_size', $prod_grid_img_size);

global $product, $woocommerce_loop;

// Store loop count we're currently on
if (empty($woocommerce_loop['loop'])) {
	$woocommerce_loop['loop'] = 0;
}

// Store column count for displaying the grid
if (empty($woocommerce_loop['columns'])) {
	$woocommerce_loop['columns'] = apply_filters('loop_shop_columns', 4);
}

// Ensure visibility
if (!$product || !$product->is_visible()) {
	return;
}

// Increase loop count
$woocommerce_loop['loop']++;

// Extra post classes
$classes = array();
$classes[] = 'item';

$post_id = $post->ID;
$stock_status = get_post_meta($post_id, '_stock_status', true) == 'outofstock';
?>
<div <?php post_class($classes); ?>>
	<div class="product-wrap">
		<div class="product-inner-wrap">

			<?php wc_get_template('loop/sale-flash.php'); ?>
			<div class="product-image">

				<div class="catalog-image">
					<a href="<?php the_permalink(); ?>">
						<?php
						$gallery_images = $product->get_gallery_image_ids();
						$flip_class = (!empty($gallery_images)) ? "has-flip-image" : "has-noflip-image";
						?>
						<figure
							class="<?php echo esc_attr($flip_class); ?><?php echo esc_attr($grid_img_effect_class); ?>">
							<?php
							if (!empty(get_the_post_thumbnail($post->ID, $carousel_catalog_thumb_size))) {
								echo get_the_post_thumbnail($post->ID, $carousel_catalog_thumb_size, array("class" => "product-image-front"));
							} else
								echo acmthemes_get_placeholder('placeholder.png');
							?>
							<?php
							if (!empty($gallery_images)) {
								echo wp_get_attachment_image($gallery_images[0], $carousel_catalog_thumb_size, "", array("class" => "product-image-back"));
							}
							?>
						</figure>
					</a>				

				</div>

				<div class="product-buttons">
						<?php
						/*
						 ** show quick view button
						 */
						if (isset($settings['catalog_quick_view']) && !empty($settings['catalog_quick_view'])) {
							echo '<div class="woo-quickview-btn"><span class="info-balloon">' . esc_html__('Quick View', 'bookchoix') . '</span>' . apply_filters('woo_quick_view_button_html', '<a href="#" class="owp-quick-view" id="product_id_' . $product->get_id() . '" data-product_id="' . $product->get_id() . '"><i class="icon-eye"></i></a>') . '</div>';
						}
						?>

						<?php
						/*
						 ** show compare button
						 */
						if (isset($settings['product_compare']) && !empty($settings['product_compare']) && shortcode_exists('woosc')) {
							echo '<div class="compare_btn">';
							echo '<span class="info-balloon">' . esc_html__('Compare', 'bookchoix') . '</span>';
							echo do_shortcode('[woosc id="' . $product->get_id() . '" type="link"]');
							echo '</div>';
						}
						?>

						<?php
						/*
						 ** show yith wishlist button
						 */
						if (isset($settings['yith_wish_list']) && !empty($settings['yith_wish_list']) && shortcode_exists('yith_wcwl_add_to_wishlist')) {
							echo '<div class="yith-wish-list">';
							echo '<span class="info-balloon">' . esc_html__('Add to wishlist', 'bookchoix') . '</span>';
							echo do_shortcode('[yith_wcwl_add_to_wishlist]');
							echo '</div>';
						}
						?>

					</div>

			</div><!-- end product-image -->
			<div class="product-content">
				<div class="product-cats">
					<?php echo wc_get_product_category_list($post->ID, ', '); ?>
				</div>
				<h3 class="product_title"><a class="product_title_link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

				<?php do_action('woocommerce_after_shop_loop_item_title'); ?>
                
                

				<?php
				$book_authors = bookchoix_add_authors_link();
				if (isset($book_authors) && !empty($book_authors)) { ?>
					<div class="book-authors">
						<?php bookchoix_add_authors_link(); ?>
					</div>
				<?php } ?>
				<?php
				//add filter to bkc product price html
				$bkc_product_price = '';
				$bkc_product_price = apply_filters('bookchoix_product_price_tag', $product->get_price_html());
				?>
				<div class="product-price">
					<?php echo wp_kses_post($bkc_product_price); ?>
				</div>

				<div class="product-rating">
					<?php woocommerce_template_loop_rating(); ?>
				</div>

				<?php
				if ( $product->is_on_sale() && isset( $args['show_sale_timer'] ) && true == $args['show_sale_timer'] ) {
					?>
					<div class="bkc-countdown-timer" data-countdown="<?php echo wp_kses_post( $product->get_date_on_sale_to() ); ?>">
						<span>
							<?php 
							if( !empty( $args['sale_timer_label'] ) ) {
								echo esc_html( $args['sale_timer_label'] );
							}
							else
								echo esc_html__('Ends in:', 'bookchoix'); 
							?>
						</span>
						<span class="timer"></span>
					</div>
				<?php
				}
				?>

				<div class="product-add-to-cart">
					<?php woocommerce_template_loop_add_to_cart(); ?>
				</div>

				<?php do_action('bookchoix_after_carousel_product_content'); ?>

			</div><!-- end product-content -->

		</div>
	</div>
</div>