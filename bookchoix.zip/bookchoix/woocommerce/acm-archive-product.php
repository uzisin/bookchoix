<?php
/**
 * Archive product template.
 *
 * @package BookChoix WordPress theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product, $post;

//get framework settings
$settings = acmthemes_settings();

do_action( 'before_archive_product_item' );

?>
<div class="product-inner-wrap clr">

<?php	wc_get_template( 'loop/sale-flash.php' ); ?>

	<div class="product-image">
		<div class="catalog-image">

			<?php do_action( 'before_archive_product_image' );
				if ( class_exists( 'ACMTHEMES_WOOCOMMERCE_CONFIG' ) ) {
					ACMTHEMES_WOOCOMMERCE_CONFIG::add_out_of_stock_badge();
				}
				//woocommerce_show_product_loop_sale_flash();
				if ( class_exists( 'ACMTHEMES_WOOCOMMERCE_CONFIG' ) ) {
					ACMTHEMES_WOOCOMMERCE_CONFIG::loop_product_thumbnail();
				}
				do_action( 'after_archive_product_image' );
				?>

				<div class="product-buttons">
				<?php
				/*
				** show quick view button
				*/
				if( isset( $settings[ 'catalog_quick_view' ] ) && ! empty( $settings[ 'catalog_quick_view' ] ) ) {
					echo '<div class="woo-quickview-btn">
					<span class="info-balloon">' . esc_html__('Quick View', 'bookchoix') . '</span>' . apply_filters( 'woo_quick_view_button_html', '<a href="#" class="owp-quick-view" id="product_id_' . $product->get_id() . '" data-product_id="' . $product->get_id() . '"><i class="icon-eye"></i></a>' )
					.'</div>';
				}

				/*
				** show yith wishlist button
				*/
				if( isset( $settings[ 'yith_wish_list' ] ) && ! empty( $settings[ 'yith_wish_list' ] ) && shortcode_exists( 'yith_wcwl_add_to_wishlist' ) ) {
					echo '<div class="yith-wish-list">';
					echo '<span class="info-balloon">'. esc_html__('Add to Wishlist', 'bookchoix') . '</span>';					
					echo do_shortcode('[yith_wcwl_add_to_wishlist]');
					echo '</div>';
				 }

				 /*
 				** show compare button
 				*/
 				if( isset( $settings[ 'product_compare' ] ) && ! empty( $settings[ 'product_compare' ] ) && shortcode_exists( 'woosc' ) ) {
 					echo '<div class="compare_btn">';
 					echo '<span class="info-balloon">'. esc_html__('Compare', 'bookchoix') . '</span>';
 					echo do_shortcode('[woosc id="'. $product->get_id() . '" type="link"]');
 					echo '</div>';
 				}

				?>

				<div class="product-add-to-cart">
					<?php woocommerce_template_loop_add_to_cart(); ?>
				</div>

			 </div>

			</div>
	</div><!-- product-image wrap -->

<div class="product-content">
	<div class="product-cats"><?php echo wc_get_product_category_list($post->ID, ', '); ?></div>
		<h3 class="product_title"><a class="product_title_link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

		<?php do_action( 'woocommerce_after_shop_loop_item_title' ); ?>
		<?php
		$book_authors = bookchoix_add_authors_link();
		if( isset( $book_authors ) && ! empty( $book_authors ) ) { ?>
		 <div class="book-authors"><?php bookchoix_add_authors_link(); ?></div>
	 <?php }

	  //show publish date
	  bookchoix_book_publish_date();

	 	//add filter to bkc product price html
		$bkc_product_price = '';
		$bkc_product_price = apply_filters( 'bookchoix_product_price_tag', $product->get_price_html() );
	  ?>
		<div class="product-price"><?php echo wp_kses_post ( $bkc_product_price ); ?></div>

		<div class="product-desc"><?php echo wp_kses_post ( $product->get_short_description() ); ?></div>
		<div class="product-rating"><?php woocommerce_template_loop_rating(); ?></div>

		<?php do_action( 'bookchoix_after_loop_product_content' ); ?>

</div><!-- end product-content -->


</div>

<div class="product-list-inner-wrap clr">

<?php	wc_get_template( 'loop/sale-flash.php' ); ?>

	<div class="product-image">
		<div class="catalog-image">

			<?php do_action( 'before_archive_product_image' );
				if ( class_exists( 'ACMTHEMES_WOOCOMMERCE_CONFIG' ) ) {
					ACMTHEMES_WOOCOMMERCE_CONFIG::add_out_of_stock_badge();
				}
				//woocommerce_show_product_loop_sale_flash();
				if ( class_exists( 'ACMTHEMES_WOOCOMMERCE_CONFIG' ) ) {
					ACMTHEMES_WOOCOMMERCE_CONFIG::loop_product_thumbnail();
				}
				do_action( 'after_archive_product_image' );
				?>

				<div class="product-buttons">
					<?php
					/*
					** show quick view button
					*/
					echo '<div class="woo-quickview-btn"><span class="info-balloon">' . esc_html__('Quick View', 'bookchoix') . '</span>' . apply_filters( 'woo_quick_view_button_html', '<a href="#" class="owp-quick-view" id="product_id_' . $product->get_id() . '" data-product_id="' . $product->get_id() . '"><i class="icon-eye"></i></a>' ) .'</div>';

					/*
					** show yith compare button
					*/
					if( shortcode_exists( 'yith_compare_button' ) ) {
						echo '<div class="yith_compare_btn">';
						echo '<span class="info-balloon">'. esc_html__('Compare', 'bookchoix') . '</span>';
						echo '<a href="'. get_site_url() .'?action=yith-woocompare-add-product&id='. $product->get_id() .'"
						class="compare" data-product_id="'. $product->get_id() .'" rel="nofollow"><i class="fa fa-random"></i></a>';
						echo '</div>';
					}

					/*
					** show yith wishlist button
					*/
					if(shortcode_exists( 'yith_wcwl_add_to_wishlist' ) ) {
						echo '<div class="yith-wish-list">';
						echo '<span class="info-balloon">'. esc_html__('Add to Wishlist', 'bookchoix') . '</span>';
						echo do_shortcode('[yith_wcwl_add_to_wishlist]');
						echo '</div>';
					 }
					?>
			 </div>

			</div>
	</div><!-- product-image wrap -->

<div class="product-content">
	<div class="product-cats"><?php echo wc_get_product_category_list($post->ID, ', '); ?></div>
		<h3 class="product_title"><a class="product_title_link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

		<?php do_action( 'woocommerce_after_shop_loop_item_title' ); ?>
		<?php
		//get book authors list
		$book_authors = bookchoix_add_authors_link();

		if( isset( $book_authors ) && ! empty( $book_authors ) ) { ?>
		 <div class="book-authors"><?php bookchoix_add_authors_link(); ?></div>
	 <?php } ?>
		<div class="product-price"><?php echo wp_kses_post ( $bkc_product_price ); ?></div>
		<div class="product-desc"><?php echo wp_kses_post ( $product->get_short_description() ); ?></div>
		<div class="product-rating"><?php woocommerce_template_loop_rating(); ?></div>
	  <div class="product-add-to-cart"><?php woocommerce_template_loop_add_to_cart(); ?></div>
</div><!-- end product-content -->

</div>


<?php do_action( 'after_archive_product_item' ); ?>
