<?php
/**
 * The template for displaying a "No posts found" message.
 *
 * @package BookChoix WordPress theme
 */
?>

<div class="page-content page-none">
	<?php if ( is_home() && current_user_can( 'publish_posts' ) ) { ?>
		<p><?php echo sprintf( esc_html__( 'Ready to publish your first post? %1$sGet started here%2$s.', 'bookchoix' ), '<a href="'. esc_url( admin_url( 'post-new.php' ) ) .'" target="_blank">', '</a>' ); ?></p>
	<?php } elseif ( is_search() ) { ?>
		<h2><?php esc_html_e( "Whoops! We can't find that page!", 'bookchoix' ); ?></h2>
		<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with different keywords.', 'bookchoix' ); ?></p>

		<?php get_template_part( 'searchform' ); ?>
		<p>
			<a class="take_me_home" href="<?php echo home_url(); ?>">
				<?php esc_html_e( 'Or Take Me Home', 'bookchoix' ); ?>
			</a>
		</p>

	<?php } elseif ( is_category() ) { ?>
		<h2><?php esc_html_e( 'Whoops! Nothing Found!', 'bookchoix' ); ?></h2>
		<p><?php esc_html_e( 'There aren\'t any posts currently published in this category.', 'bookchoix' ); ?></p>
	<?php } elseif ( is_tax() ) { ?>
		<h2><?php esc_html_e( 'Whoops! Nothing Found!', 'bookchoix' ); ?></h2>
		<p><?php esc_html_e( 'There aren\'t any posts currently published under this author.', 'bookchoix' ); ?></p>
	<?php } elseif ( is_tag() ) { ?>
		<h2><?php esc_html_e( 'Whoops! Nothing Found!', 'bookchoix' ); ?></h2>
		<p><?php esc_html_e( 'There aren\'t any posts currently published under this tag.', 'bookchoix' ); ?></p>
	<?php } else { ?>
		<h2><?php esc_html_e( 'Whoops! Nothing Found!', 'bookchoix' ); ?></h2>
		<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for.', 'bookchoix' ); ?></p>
	<?php } ?>
</div><!-- .page-content -->
