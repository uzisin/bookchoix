<?php
/**
 * The template for displaying the page header.
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Return if page header is disabled
if ( ! acmthemes_has_page_header() ) {
	return;
}

//get theme Options
$settings = acmthemes_settings();

//get page id
$current_page_id = get_the_ID();

// Classes
$classes = array( 'page-header' );

// Get header style
$style = acmthemes_page_header_style();

// Add classes for title style
if ( $style ) {
	$classes[$style .'-page-header'] = $style .'-page-header';
}

// Visibility
$visibility = 'all-devices';

// Turn into space seperated list
$classes = implode( ' ', $classes );

// Heading tag
$heading = 'h1';
$heading = apply_filters( 'page_header_heading', $heading ); ?>

<?php do_action( 'before_page_header' );

// Return if page header is disabled
if ( acmthemes_has_page_header_heading() ) { ?>

<?php if( ! is_front_page() ) { //disable for front page
	$show_page_header = false;
	if ( isset( $settings['enable_page_header'] ) && !empty( $settings['enable_page_header'] )) {
		$show_page_header = true;
	}
	$page_header_status = get_post_meta( $current_page_id, 'show_page_header', true );
	if( !empty( $page_header_status ) && $page_header_status == 'show' ) {
		$show_page_header = true;
	}
	elseif( !empty( $page_header_status ) && $page_header_status == 'hide' ) {
		$show_page_header = false;
	}
	?>

<?php if( true === $show_page_header ) { ?>
<header class="<?php echo esc_attr( $classes ); ?>">

	<?php do_action( 'before_page_header_inner' ); ?>

	<div class="page-header-wrap">
		<div class="container clr page-header-inner">
			<?php
			 if( ! is_single() && ! acmthemes_is_woo_single() ) { ?>
				<<?php echo esc_attr( $heading ); ?> class="page-header-title clr"<?php acmthemes_schema_markup( 'headline' ); ?>><?php echo wp_kses_post( acmthemes_title() ); ?></<?php echo esc_attr( $heading ); ?>>
			<?php } ?>
			<?php get_template_part( 'partials/page-header-subheading' ); ?>

				<?php

				if ( function_exists( 'acmthemes_breadcrumb_trail' ) ) {
					acmthemes_breadcrumb_trail();
				}

				?>
		</div><!-- .page-header-inner -->
	</div><!-- .page-header-wrap -->

	<?php acmthemes_page_header_overlay(); ?>

	<?php do_action( 'after_page_header_inner' ); ?>

</header><!-- .page-header -->

<?php } //show page header ?>

<?php } ?>

<?php } ?>

<?php do_action( 'after_page_header' );
