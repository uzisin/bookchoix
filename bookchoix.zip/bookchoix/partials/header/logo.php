<?php
/**
 * Header Logo
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = acmthemes_settings();

// Header style
$header_style = acmthemes_header_style();

// Vars
$full_screen_logo 	= (!empty($settings['full_screen_header_logo']['url'])) ? $settings['full_screen_header_logo']['url'] : '';
$retina_logo 	= (!empty($settings['full_screen_header_retina_logo']['url'])) ? $settings['full_screen_header_retina_logo']['url'] : '';
$mobile_logo 	= (!empty($settings['mob_screen_header_logo']['url'])) ? $settings['mob_screen_header_logo']['url'] : '';
?>

<?php do_action( 'before_logo' ); ?>

<?php if( 'header-fullwidth-navi' == $header_style ) { ?>
<div class="container pos-rel flex">
<?php } ?>

	<div id="site-logo" class="<?php echo esc_attr( acmthemes_header_logo_classes() ); ?>"<?php acmthemes_schema_markup( 'logo' ); ?>>

		<?php do_action( 'before_logo_inner' ); ?>

		<div id="site-logo-inner" class="clr">

			<?php
			// Custom site-wide image logo
			if ( $full_screen_logo || $retina_logo ) {

				do_action( 'before_logo_img' );

				// Full screen logo
				if ( $full_screen_logo ) {
					acmthemes_custom_full_screen_logo();
				}

				// Full screen logo
				if ( $mobile_logo ) {
					acmthemes_mobile_logo();
				}

				do_action( 'after_logo_img' );

			} else {

				// Default logo
				acmthemes_default_logo();

			} ?>

		</div><!-- #site-logo-inner -->


		<?php do_action( 'after_logo_inner' ); ?>

	</div><!-- #site-logo -->

<?php if( 'header-fullwidth-navi' == $header_style ) { ?>

	<?php get_template_part( 'partials/header/custom-content' ); ?>

</div>
<?php } ?>

<?php do_action( 'after_logo' ); ?>
