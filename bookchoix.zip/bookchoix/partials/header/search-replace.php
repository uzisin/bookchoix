<?php
/**
 * Site header search header replace
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

//get theme settings
$settings = acmthemes_settings();

// Post type
$post_type = ( !empty($settings['header_search_type']) && $settings['header_search_type'] == 'all' ) ? 2 : 1; ?>

<div id="searchform-header-replace" class="header-searchform-wrap clr">
	<form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="header-searchform">
		<input class="field" type="search" name="s" autocomplete="off" value="" placeholder="<?php echo esc_html_e( 'Search by Title, Category or ISBN', 'bookchoix' ); ?>" />
		<?php if ( 1 == $post_type ) { ?>
			<input type="hidden" name="post_type" value="product">
		<?php } ?>
	</form>
	<span id="searchform-header-replace-close" class="icon-close"></span>
</div><!-- #searchform-header-replace -->
