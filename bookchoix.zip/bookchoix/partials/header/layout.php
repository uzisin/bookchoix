<?php
/**
 * Main Header Layout
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$settings = acmthemes_settings();

// Header style
$header_style = acmthemes_header_style();

// Header height, used for local scrolling
$header_height = '81';

// Add container class if the header is not full width
$class = '';

if( empty( $header_style ) || 'header-default' == $header_style ) {
  $class = ' container header-default';
}
elseif( ! empty( $header_style ) && 'header-transparent' == $header_style ) {
  $class = ' container header-transparent-inner';
}
else {
  $class = ' ' . $header_style;
}

do_action( 'before_header' );

// If transparent header style
if ( 'header-transparent' == $header_style ) { ?>
	<div id="transparent-header-wrap" class="clr">
<?php
} ?>

<header id="site-header" class="<?php echo esc_attr( acmthemes_header_classes() ); ?>" data-height="<?php echo esc_attr( $header_height ); ?>"<?php acmthemes_schema_markup( 'header' ); ?>>

	<?php

		// If header video
		if ( function_exists( 'has_header_video' ) && has_header_video() ) { ?>
			<div class="custom-header-media">
				<?php the_custom_header_markup(); ?>
			</div>
		<?php
		}

		// If custom header style
		else if ( 'custom' == $header_style ) {
			get_template_part( 'partials/header/style/custom-header' );
		}

		// Default header style
		else { ?>

			<?php do_action( 'before_header_inner' ); ?>

			<div id="site-header-inner" class="clr<?php echo esc_attr( $class ); ?>">

				<?php do_action( 'header_inner_left_content' ); ?>

				<?php do_action( 'header_inner_middle_content' ); ?>

				<?php do_action( 'header_inner_right_content' ); ?>

			</div><!-- #site-header-inner -->

			<?php do_action( 'after_header_inner' ); ?>

		<?php
		} ?>

		<?php
		// If header media
		if ( has_header_image() ) { ?>
			<div class="overlay-header-media"></div>
		<?php
		} ?>

	<?php

  //mobile search
  if( isset($settings['show_mobile_search']) && $settings['show_mobile_search'] == 1 )
    get_template_part( 'partials/mobile/mobile-search' );

  ?>

</header><!-- #site-header -->

<?php
// If transparent header style
if ( 'header-transparent' == $header_style ) { ?>
	</div>
<?php
}

do_action( 'after_header' ); ?>
