<?php
/**
 * Header menu template part.
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Return if disabled
if ( ! acmthemes_display_navigation() ) {
	return;
}

//get framework settings
$settings = acmthemes_settings();

// Header style
$header_style = acmthemes_header_style();

// Get classes for the header menu
$wrap_classes  = acmthemes_header_menu_classes( 'wrapper' );
$inner_classes = acmthemes_header_menu_classes( 'inner' );

// Menu Location
$menu_location = apply_filters( 'main_menu_location', 'main_menu' );


	// Display menu if defined
	if ( has_nav_menu( $menu_location ) ) :

		// Get menu classes
		$menu_classes = array( 'main-menu' );

		// If full screen header style
		if ( 'full_screen' == $header_style ) {
			$menu_classes[] = 'fs-dropdown-menu';
		} else {
			$menu_classes[] = 'dropdown-menu';
		}

		// If is not full screen or vertical header style
		if ( 'full_screen' != $header_style
			&& 'vertical' != $header_style ) {
			$menu_classes[] = 'sf-menu';
		}

		// Turn menu classes into space seperated string
		$menu_classes = implode( ' ', $menu_classes );

		// Menu arguments
		$menu_args = array(
			'theme_location' => $menu_location,
			'menu_class'     => $menu_classes,
			'container'      => false,
			'fallback_cb'    => false,
			'link_before'    => '<span class="text-wrap">',
			'link_after'     => '</span>',
			'walker'         => new ACMTHEMES_Custom_Nav_Walker(),
		);

		// Check if custom menu
		if ( $menu = acmthemes_header_custom_menu() ) {
			$menu_args['menu']  = $menu;
		}

		do_action( 'before_nav' );

		// If is not full screen header style
		if ( 'full_screen' != $header_style ) { ?>
			<div id="site-navigation-wrap" class="<?php echo esc_attr( $wrap_classes ); ?>">
					<?php } ?>

						<?php do_action( 'before_nav_inner' ); ?>

						<?php
						// Add container if is medium header style
						if ( 'medium' == $header_style ) { ?>
							<div class="container clr">
						<?php } ?>

						<nav id="site-navigation" class="<?php echo esc_attr( $inner_classes ); ?>"<?php acmthemes_schema_markup( 'site_navigation' ); ?>>

							<?php

							wp_nav_menu( $menu_args );

							get_template_part( 'partials/header/search-replace' );

			 ?>
						</nav><!-- #site-navigation -->

						<?php
						// Add container if is medium header style
						if ( 'medium' == $header_style ) { ?>
							</div>
						<?php } ?>

						<?php do_action( 'after_nav_inner' );

			// If is not full screen header style
			if ( 'full_screen' != $header_style ) { ?>
			</div><!-- #site-navigation-wrap -->
		<?php } ?>

		<div class="woo-cart-item">
			<?php
			if( ! isset( $settings['shop_type'] ) || 'default' == $settings['shop_type'] ) {
				//show menu cart count
				if( isset( $settings['show_woo_menu_icon_desktop'] ) && 1 == $settings['show_woo_menu_icon_desktop'] && class_exists('Xoo_Wsc_Loader') ) {
					echo do_shortcode('[xoo_wsc_cart]');
					if( function_exists( 'acmthemes_wcmenucart_menu_item' ) ) {
						//acmthemes_wcmenucart_menu_item();
					}
				}
			}

			?>
		</div>
		<?php

		// shown only when enabled
		if( isset( $settings['enable_search_on_menu'] ) && $settings['enable_search_on_menu'] == 1 ) {
			
			if( function_exists('acmthemes_search_box') ) {
				acmthemes_search_box(array());
			}
		}
		?>

		<?php do_action( 'after_nav' ); ?>

	<?php endif;
