<?php
/**
 * Header social menu template part.
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get social options array
$social_options = acmthemes_social_options();

// Return if $social_options array is empty
if ( empty( $social_options ) ) {
	return;
}

// Style
$style = 'simple';

// Classes
$classes = array( 'acmthemes-social-menu', 'clr' );

// Add class if social menu has class
if ( 'simple' != $style ) {
	$classes[] = 'social-with-style';
} else {
	$classes[] = 'simple-social';
}

// Turn classes into space seperated string
$classes = implode( ' ', $classes );

// Inner classes
$inner_classes = array( 'social-menu-inner', 'clr' );
if ( 'simple' != $style ) {
	$inner_classes[] = $style;
}

// Turn classes into space seperated string
$inner_classes = implode( ' ', $inner_classes );

// Get theme mods
$link_target = 'blank'; ?>

<div class="<?php echo esc_attr( $classes ); ?>">

	<div class="<?php echo esc_attr( $inner_classes ); ?>">

			<ul>

				<?php
				// Loop through social options
				foreach ( $social_options as $key => $val ) {

					// Get URL from the theme mods
					$url = isset( $profiles[$key] ) ? $profiles[$key] : '';

					// Display if there is a value defined
					if ( $url ) {

						// Display link
						echo '<li class="acmthemes-'. esc_attr( $key ) .'">';

							if ( in_array( $key, array( 'skype' ) ) ) {
								echo '<a href="skype:'. esc_attr( $url ) .'?call" target="_self">';
							} else if ( in_array( $key, array( 'email' ) ) ) {
								echo '<a href="mailto:'. antispambot( esc_attr( $url ) ) .'" target="_self">';
							} else {
								echo '<a href="'. esc_url( $url ) .'" target="_'. esc_attr( $link_target ) .'">';
							}

								echo '<span class="'. esc_attr( $val['icon_class'] ) .'"></span>';

							echo '</a>';

						echo '</li>';

					} // End url check

				} // End loop ?>

			</ul>

	</div>

</div>
