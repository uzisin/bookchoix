<?php
/**
 * Header custom content
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = acmthemes_settings();

// Header style
$header_style = acmthemes_header_style();

do_action( 'before_header_custom_content' ); ?>

<div id="header-right-col">

  <div id="header-right-col-inner" class="clr">
    <?php echo wp_kses_post( $settings['header_style2_right_content'] ); ?>
  </div>

</div>

<?php do_action( 'after_header_custom_content' );
