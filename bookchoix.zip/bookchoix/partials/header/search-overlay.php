<?php
/**
 * Site header search overlay
 *
 * @package BookChoix WordPress theme
 */

 //get theme settings
$settings = acmthemes_settings();

// Post type
$post_type = ( !empty($settings['header_search_type']) && $settings['header_search_type'] == 'all' ) ? 2 : 1; 
?>

<div class="bkc-search-popup">
    <div class="close-bar">
        <a href="#" class="bkc-search-popup-close-btn">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect class="close-btn-shape" x="0.221825" y="14.364" width="20" height="2" rx="1" transform="rotate(-45 0.221825 14.364)" />
            <rect class="close-btn-shape" x="1.63604" y="0.221825" width="20" height="2" rx="1" transform="rotate(45 1.63604 0.221825)" />
        </svg>
        </a>
    </div>

    <div class="bkc-search-holder">
        <form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="header-searchform">
            <input class="field" type="search" name="s" autocomplete="off" value="" placeholder="<?php echo esc_html_e( 'Search by Title, Category or ISBN', 'bookchoix' ); ?>" />
            <?php if ( 1 == $post_type ) { ?>
                <input type="hidden" name="post_type" value="product">
            <?php } ?>
        </form>
    </div>

</div>