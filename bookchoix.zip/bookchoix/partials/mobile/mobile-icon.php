<?php
/**
 * Mobile Menu icon
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Return if disabled
if ( ! acmthemes_display_navigation() ) {
	return;
}

// Menu Location
$menu_location = apply_filters( 'main_menu_location', 'main_menu' );

// Multisite global menu
$ms_global_menu = apply_filters( 'ms_global_menu', false );

// Display if menu is defined
if ( has_nav_menu( $menu_location ) || $ms_global_menu ) :

	// Get menu icon
	$icon = apply_filters( 'mobile_menu_navbar_open_icon', 'fa fa-bars' );

	if ( ACMTHEMES_WOOCOMMERCE_ACTIVE ) {

		// Get cart icon
		$woo_icon = 'icon-handbag';

		// Cart Icon
		$cart_icon = '<i class="'. esc_attr( $woo_icon ) .'"></i>';
		$cart_icon = apply_filters( 'menu_cart_icon_html', $cart_icon );

	}

	// Classes
	$classes = array( 'acmthemes-mobile-menu-icon', 'clr' );

	// Turn classes into space seperated string
	$classes = implode( ' ', $classes ); ?>

	<div class="<?php echo esc_attr( $classes ); ?>">

		<?php do_action( 'before_mobile_icon' ); ?>

		<?php do_action( 'before_mobile_icon_inner' ); ?>

		<!-- Mobile hamburger icon -->
		<a href="#acm-mobile-menu" class="hamburger-icon">
			<i class="<?php echo esc_attr( $icon ); ?>"></i>
		</a>
		<!-- Mobile hamburger icon -->

		<?php do_action( 'after_mobile_icon_inner' ); ?>

		<?php do_action( 'after_mobile_icon' ); ?>

	</div><!-- #acmthemes-mobile-menu-navbar -->

<?php endif; ?>
