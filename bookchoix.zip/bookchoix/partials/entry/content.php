<?php
/**
 * Displays post entry content
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $post;

//get options framework settings
$settings = acmthemes_settings();
$get_post_format = get_post_format();

//post_excerpt classes
$excerpt_classes = array();

$excerpt_classes[] = 'post-excerpt';
if ( ! has_post_thumbnail() ) {
	$excerpt_classes[] = 'notop-margin';
}

//combine class names with a space
$excerpt_classes = implode( ' ', $excerpt_classes );
?>

<?php do_action( 'before_blog_entry_content' ); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<div class="post-text">
			<header class="entry-header">
				<?php
				if( is_sticky( $post->ID ) ) { ?>
					<div class="featured-post"><?php echo esc_html__('Featured', 'bookchoix'); ?></div>
				<?php
			} ?>

			<span class="post-categories">
				<?php
				$categories = get_the_category();
				if ( ! empty( $categories ) ) {
					 echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
				}
				?>
			</span>

			<?php
				if( $get_post_format != 'quote' ) :
						if ( is_single() ) :
							the_title( '<h1 class="entry-title">', '</h1>' );
						else :
							the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
						endif;
				endif;
						?>

					<div class="post-meta">
							<span class="author"><?php echo esc_html__('By', 'bookchoix'); ?> <?php  the_author_posts_link(); ?></span>
							<?php if( ! empty( get_the_date() ) ) { ?> <?php echo esc_html__('on', 'bookchoix'); ?> <span class="post-date"><?php echo get_the_date(); ?></span> <?php } ?>
							<?php if( has_tag() ){ ?>
							<span class="separator">|</span>
							<span class="tags"><i class="fa fa-tag"></i> <?php the_tags( '', ', ' ); ?></span>
							<?php } ?>
					</div>

		 </header><!-- .entry-header -->

		 <?php
		 //Featured media
		 //show featured div only if condition true
		 if($get_post_format == 'video' || $get_post_format == 'audio' || $get_post_format == 'quote' || has_post_thumbnail()) {
		 ?>
		 <div class="featured-media">
				 <?php
				 if( $get_post_format == 'video' ){
								 $get_video_url = get_post_meta($post->ID, '_post_video_url', true);
								 if( !empty($get_video_url) ){
										 if ( shortcode_exists( 'video' ) ) {
												 echo do_shortcode("[video align='right' aspect_ratio='16:9' width='100' autoplay='0']" . esc_url($get_video_url) . "[/video]");
										 }
										 else {
												 echo esc_url( $get_video_url );
										 }
								 }
				 }
				 if( $get_post_format == 'audio' ){
						 $get_audio_url = get_post_meta($post->ID, '_post_audio_url', true);
						 if( !empty($get_audio_url) && function_exists('acm_get_domain_name') ){
								 $get_domain_name = acm_get_domain_name($get_audio_url);
								 $get_extension = acm_get_file_url_ext($get_audio_url);

								 if($get_domain_name[0] == "soundcloud") {
										 if ( shortcode_exists( 'soundcloud' ) ) {
												 echo do_shortcode("[soundcloud]" . esc_url($get_audio_url) . "[/soundcloud]");
										 }
										 else {
												 echo esc_url($get_audio_url);
										 }
								 }
								 elseif( in_array($get_extension, array('mp3', 'ogg', 'wav')) ){
										 if ( shortcode_exists( 'audio' ) ) {
												 echo do_shortcode('[audio ' . esc_url($get_extension) . '="' . $get_audio_url . '"]');
										 }
										 else {
												 echo esc_url($get_extension);
										 }
								 }
						 }
				 }
				 if( $get_post_format == 'quote' ){
				 ?>
				 <blockquote class="blockquote">
						 <?php if ( has_excerpt( $post->ID ) && isset( $settings['blog_excerpt_length'] ) && $settings['blog_excerpt_length'] < 100 ) {
								 the_excerpt();
						 }
						 else {
								 the_content();
						 }
						 ?>
				 </blockquote>
				 <?php
						 }
						 elseif( $get_post_format != 'video' && $get_post_format != 'audio') {
							 if( has_post_thumbnail() ){
								 ?>
								 <div class="featured-image">
									 <?php
									 the_post_thumbnail('bookchoix_blog_thumb', array('class' => 'img-responsive blog-thumbnail'));
									 ?>
	
								 </div>
								 <?php
							 }
						 }
						 ?>
			 </div>
		 <?php } ?>

		<?php if( $get_post_format != 'quote' ) : ?>

		<div class="entry-content">
			<div class="<?php echo esc_attr( $excerpt_classes ); ?>">
				<?php
				if ( has_excerpt( $post->ID ) ) {
					the_excerpt();
				}
				else{
					if( isset( $settings['blog_excerpt_length'] ) && $settings['blog_excerpt_length'] < 100 ) {
						echo acmthemes_excerpt( $settings['blog_excerpt_length'] );
					}
					else {
						echo acmthemes_excerpt();
					}
				}
				?>
			</div>
		</div><!-- .entry-content -->

		<?php endif; ?>
	</div> <!-- post-text -->


</article>

<?php do_action( 'after_blog_entry_content' ); ?>
