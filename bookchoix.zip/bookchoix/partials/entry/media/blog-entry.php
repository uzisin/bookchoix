<?php
/**
 * Displays the post entry thumbmnail
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Return if there isn't a thumbnail defined
if ( ! has_post_thumbnail() ) {
	return;
}

// Add images size if blog grid
if ( 'grid-entry' == acmthemes_blog_entry_style() ) {
	$size = acmthemes_blog_entry_images_size();
} else {
	$size = 'full';
}

// Overlay class
if ( is_customize_preview()
	&& false == get_theme_mod( 'blog_image_overlay', true ) ) {
	$class = 'no-overlay';
} else {
	$class = 'overlay';
}

// Image args
$img_args = array(
    'alt' => get_the_title(),
);
if ( acmthemes_get_schema_markup( 'image' ) ) {
	$img_args['itemprop'] = 'image';
}

// Caption
$caption = get_the_post_thumbnail_caption(); ?>

<div class="thumbnail">

	<a href="<?php the_permalink(); ?>" class="thumbnail-link">

		<?php
		// Image width
		$img_width  = apply_filters( 'blog_entry_image_width', absint( get_theme_mod( 'blog_entry_image_width' ) ) );
		$img_height = apply_filters( 'blog_entry_image_height', absint( get_theme_mod( 'blog_entry_image_height' ) ) );

    	// Images attr
		$img_id 	= get_post_thumbnail_id( get_the_ID(), 'full' );
		$img_url 	= wp_get_attachment_image_src( $img_id, 'full', true );

			// Display post thumbnail
			the_post_thumbnail( $size, $img_args );

		}
?>

	</a>

	<?php
	// Caption
	if ( $caption ) { ?>
		<div class="thumbnail-caption">
			<?php echo esc_attr( $caption ); ?>
		</div>
	<?php
	} ?>

</div><!-- .thumbnail -->
