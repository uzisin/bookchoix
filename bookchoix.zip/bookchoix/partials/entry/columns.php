<?php
/**
 * Default post entry layout
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get post format
$get_post_format = get_post_format();
$settings = acmthemes_settings();

if ( ! empty( $settings['blog_col_layout'] ) ) {
	if( $settings['blog_col_layout'] < 2 )
		$get_columns = 3;
	else
		$get_columns = $settings['blog_col_layout'];
}

$resp_col_classes = ( function_exists( 'acm_get_custom_col' ) ) ? acm_get_custom_col( $get_columns ) : '';
?>
<div id="blog-entries" class="blog-column multi-columns <?php acmthemes_blog_wrap_classes(); ?>">
	<div class="acm-row multi-column-grid">

	<?php
	$acmthemes_count = 0;
	// Loop through posts
	while ( have_posts() ) : the_post();
	$acmthemes_count++;
	?>

		<div class="acm-col <?php echo esc_attr( $resp_col_classes ) ; ?> match-grids">

			<?php
			//article content
			get_template_part( 'partials/entry/columns-content' );
			?>

		</div>

	<?php
	// Reset counter to clear floats
	if ( acmthemes_blog_entry_columns() == $acmthemes_count ) {
		$acmthemes_count=0;
	}
	endwhile;
	?>

	</div>
</div>
