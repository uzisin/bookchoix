<?php
/**
 * Outputs no posts layout
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
} ?>

<article class="no-posts-template clr">

	<?php
    echo esc_html__( 'No posts found!', 'bookchoix' );
	 ?>

</article>