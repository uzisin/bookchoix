<?php
/**
 * Default post entry layout
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get post format
$get_post_format = get_post_format();
$settings = acmthemes_settings();
?>
<div id="blog-entries" class="blog-column single-column <?php acmthemes_blog_wrap_classes(); ?>">

	<?php
	// Define counter for clearing floats
	$acmthemes_count = 0; ?>

	<?php
	// Loop through posts
	while ( have_posts() ) : the_post();

	//article content
	get_template_part( 'partials/entry/content' );

	endwhile;

	?>

</div><!-- #blog-entries -->
