<?php
/**
 * The template for displaying the scroll top button.
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

//get framework settings
$settings = acmthemes_settings();

// If no scroll top button
if ( ! acmthemes_display_scroll_up_button() ) {
	return;
}


// Position
$position = ( isset( $settings['scroll_top_position'] ) && ! empty( $settings['scroll_top_position'] ) ) ? $settings['scroll_top_position'] : 'right';
$position = apply_filters( 'scroll_top_position', $position );
?>

<a id="scroll-top" class="scroll-top-<?php echo esc_attr( $position ); ?>" href="#"><span class="icon icon-arrow-up"></span></a>
