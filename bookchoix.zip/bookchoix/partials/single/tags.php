<?php
/**
 * Blog single tags
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Display tags ?>
<div class="post-tags clr">
	<?php the_tags( '<span class="owp-tag-text">' . esc_attr( 'Tags: ', 'bookchoix' ) . '</span>', '<span class="owp-sep">,</span> ', '' ); ?>
</div>
