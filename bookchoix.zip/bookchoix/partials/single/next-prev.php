<?php
/**
 * The next/previous links to go to another post.
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Only display for standard posts
if ( 'post' != get_post_type() ) {
	return;
}

// Term
$term_tax = 'post_tag';

// Args
$args = array(
	'prev_text'             => '<span class="title"><i class="fa fa-long-arrow-left"></i>'. esc_html__( 'Previous Post', 'bookchoix' ) .'</span><span class="post-title">%title</span>',
    'next_text'             => '<span class="title"><i class="fa fa-long-arrow-right"></i>'. esc_html__( 'Next Post', 'bookchoix' ) .'</span><span class="post-title">%title</span>',
    'in_same_term'          => true,
    'taxonomy'              => $term_tax,
    'screen_reader_text'    => esc_html__( 'Continue Reading', 'bookchoix' ),
);

// Args
$args = apply_filters( 'single_post_next_prev_args', $args ); ?>

<?php do_action( 'before_single_post_next_prev' ); ?>

<?php the_post_navigation( $args ); ?>

<?php do_action( 'after_single_post_next_prev' ); ?>
