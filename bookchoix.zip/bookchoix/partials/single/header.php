<?php
/**
 * Displays the post header
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Return if quote format
if ( 'quote' == get_post_format() ) {
	return;
}
?>

<?php do_action( 'before_single_post_title' ); ?>

<header class="entry-header clr">
	<h2 class="single-post-title entry-title"<?php acmthemes_schema_markup( 'headline' ); ?>>
    <?php the_title(); ?>
  </h2><!-- .single-post-title -->
</header><!-- .entry-header -->

<?php do_action( 'after_single_post_title' ); ?>
