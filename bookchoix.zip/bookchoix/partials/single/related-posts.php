<?php
/**
 * Single related posts
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Only display for standard posts
if ( 'post' != get_post_type() ) {
	return;
}

//get framework settings
$settings = acmthemes_settings();

// Text
$text = esc_html__( 'You Might Also Like', 'bookchoix' );

// Apply filters for child theming
$text = apply_filters( 'related_posts_title', $text );

// Number of columns for entries
$acmthemes_rel_columns = ( isset( $settings['related_blog_posts_cols'] ) && ! empty( $settings['related_blog_posts_cols'] ) ) ? $settings['related_blog_posts_cols'] : 3;

// Number of posts to show
$acmthemes_rel_posts = ( isset( $settings['related_blog_posts_count'] ) && ! empty( $settings['related_blog_posts_count'] ) ) ? $settings['related_blog_posts_count'] : 3;

// Term
$term_tax = 'category';

// Create an array of current term ID's
$terms     = wp_get_post_terms( get_the_ID(), $term_tax );
$terms_ids = array();
foreach( $terms as $term ) {
	$terms_ids[] = $term->term_id;
}

// Query args
$args = array(
	'posts_per_page' => $acmthemes_rel_posts,
	'orderby'        => 'rand',
	'post__not_in'   => array( get_the_ID() ),
	'no_found_rows'  => true,
	'tax_query'      => array (
		'relation'  => 'AND',
		array (
			'taxonomy' => 'post_format',
			'field'    => 'slug',
			'terms'    => array( 'post-format-quote', 'post-format-link' ),
			'operator' => 'NOT IN',
		),
	),
);

// If category
if ( 'category' == $term_tax ) {
	$args['category__in'] = $terms_ids;
}

// If tags
if ( 'post_tag' == $term_tax ) {
	$args['tag__in'] = $terms_ids;
}

// Args
$args = apply_filters( 'blog_post_related_query_args', $args );

do_action( 'before_single_post_related_posts' );

// Related query arguments
$acmthemes_related_query = new WP_Query( $args );

// If the custom query returns post display related posts section
if ( $acmthemes_related_query->have_posts() ) :

	// Wrapper classes
	$classes = 'clr';
	if ( 'full-screen' == acmthemes_post_layout() ) {
		$classes .= ' container';
	} ?>

	<section id="related-posts" class="<?php echo esc_attr( $classes ); ?>">

		<h3 class="theme-heading related-posts-title">
			<span class="text"><?php echo esc_html( $text ); ?></span>
		</h3>

		<div class="acmthemes-row clr">

			<?php $acmthemes_count = 0; ?>

			<?php foreach( $acmthemes_related_query->posts as $post ) : setup_postdata( $post ); ?>

				<?php $acmthemes_count++;

				// Disable embeds
				$show_embeds = apply_filters( 'related_blog_posts_embeds', false );

				// Get post format
				$format = get_post_format();

				// Add classes
				$classes	= array( 'related-post', 'clr', 'col' );
				$classes[]	= acmthemes_grid_class( $acmthemes_rel_columns );
				$classes[]	= 'col-'. $acmthemes_count; ?>

				<article <?php post_class( $classes ); ?>>

					<?php
					// Display post video
					if ( $show_embeds && 'video' == $format && $video = acmthemes_get_post_video_html() ) : ?>

						<div class="related-post-video">
							<?php echo wp_kses_post ( $video ); ?>
						</div><!-- .related-post-video -->

					<?php
					// Display post audio
					elseif ( $show_embeds && 'audio' == $format && $audio = acmthemes_get_post_audio_html() ) : ?>

						<div class="related-post-video">
							<?php echo wp_kses_post ( $audio ); ?>
						</div><!-- .related-post-audio -->

					<?php
					// Display post thumbnail
					elseif ( has_post_thumbnail() ) : ?>

						<figure class="related-post-media clr">

							<a href="<?php the_permalink(); ?>" class="related-thumb">

								<?php
								// Image width
								$img_width  = apply_filters( 'related_blog_posts_img_width', 300 );
								$img_height = apply_filters( 'related_blog_posts_img_height', 220 );

			                	// Images attr
								$img_id 	= get_post_thumbnail_id( get_the_ID(), 'full' );
								$img_url 	= wp_get_attachment_image_src( $img_id, 'full', true );

								// Images size
								if ( 'full-width' == acmthemes_post_layout()
									|| 'full-screen' == acmthemes_post_layout() ) {
									$size = 'medium_large';
								} else {
									$size = 'medium';
								}

								// Display post thumbnail.
								the_post_thumbnail( $size );

								?>
							</a>

						</figure>

					<?php endif; ?>

					<h3 class="related-post-title">
						<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php the_title(); ?></a>
					</h3><!-- .related-post-title -->

					<span class="author"><?php echo esc_html__('By', 'bookchoix'); ?> <?php esc_url( the_author_posts_link() ); ?></span>

				</article><!-- .related-post -->

				<?php if ( $acmthemes_rel_columns == $acmthemes_count ) $acmthemes_count=0; ?>

			<?php endforeach; ?>

		</div><!-- .acmthemes-row -->

	</section><!-- .related-posts -->

<?php endif; ?>

<?php wp_reset_postdata(); ?>

<?php do_action( 'after_single_post_related_posts' ); ?>
