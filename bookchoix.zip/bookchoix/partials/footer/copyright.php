<?php
/**
 * The default template for displaying the footer copyright
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = acmthemes_settings();

//left column copyright text
$copy = isset($settings['footer_copyright_text']) ? $settings['footer_copyright_text'] :
esc_html__( 'Copyright', 'bookchoix' ) . ' ' . date('Y') . ' ' . get_bloginfo('name')  . '. ' . esc_html__( 'All Rights Reserved.', 'bookchoix' );

//right column
$right_col_content = isset( $settings['right_col_content'] ) ? $settings['right_col_content'] : '';

// Inner classes
$wrap_classes = array( 'clr' );
if( empty( $right_col_content ) )
	$wrap_classes[] = 'no-right-content';

$wrap_classes = implode( ' ', $wrap_classes ); ?>

<?php do_action( 'before_footer_bottom' ); ?>

<div id="footer-bottom" class="<?php echo esc_attr( $wrap_classes ); ?>">

	<?php do_action( 'before_footer_bottom_inner' ); ?>

	<div id="footer-bottom-inner" class="container clr">

		<?php
		// Display footer bottom menu if location is defined
		if ( $right_col_content ) : ?>

			<div id="footer-bottom-menu" class="navigation clr">

				<div class="right-col-content clr" role="contentinfo">
					<?php echo wp_kses_post( do_shortcode( $right_col_content ) ); ?>
				</div><!-- #copyright -->

			</div><!-- #footer-bottom-menu -->

		<?php endif; ?>

		<?php
		// Display copyright info
		if ( $copy ) : ?>

			<div id="copyright" class="clr" role="contentinfo">
				<?php echo wp_kses_post( do_shortcode( $copy ) ); ?>
			</div><!-- #copyright -->

		<?php endif; ?>

	</div><!-- #footer-bottom-inner -->

	<?php do_action( 'after_footer_bottom_inner' ); ?>

</div><!-- #footer-bottom -->

<?php do_action( 'after_footer_bottom' ); ?>
