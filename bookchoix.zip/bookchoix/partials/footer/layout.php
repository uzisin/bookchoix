<?php
/**
 * Footer layout
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
} ?>

<footer id="footer" class="<?php echo esc_attr( acmthemes_footer_classes() ); ?>"<?php acmthemes_schema_markup( 'footer' ); ?>>

    <?php do_action( 'before_footer_inner' ); ?>

    <div id="footer-inner" class="clr">

        <?php
        // Display the footer widgets
        	get_template_part( 'partials/footer/widgets' );

        // Display the footer bottom
        	get_template_part( 'partials/footer/copyright' );
         ?>

    </div><!-- #footer-inner -->

    <?php do_action( 'after_footer_inner' ); ?>

</footer><!-- #footer -->
