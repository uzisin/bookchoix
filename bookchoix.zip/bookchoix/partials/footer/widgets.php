<?php
/**
 * Footer widgets
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get footer widgets columns
$footer_cols = ( isset( $settings['footer_columns'] ) && ! empty( $settings['footer_columns'] ) ) ? $settings['footer_columns'] : 4;
$columns    = apply_filters( 'footer_widgets_columns', $footer_cols );
$grid_class = acmthemes_grid_class( $columns );

// Responsive columns
$tablet_columns    = 3;
$mobile_columns    = 1;

// Classes
$wrap_classes = array( 'acmthemes-row', 'clr' );
if ( ! empty( $tablet_columns ) ) {
	$wrap_classes[] = 'tablet-' . $tablet_columns . '-col';
}
if ( ! empty( $mobile_columns ) ) {
	$wrap_classes[] = 'mobile-' . $mobile_columns . '-col';
}

if ( is_active_sidebar( 'footer-one' ) || is_active_sidebar( 'footer-two' ) || is_active_sidebar( 'footer-three' ) || is_active_sidebar( 'footer-four' )  ) {
	$wrap_classes[] = 'has-padding';
}
else {
	$wrap_classes[] = 'has-no-padding';
}

$wrap_classes = implode( ' ', $wrap_classes );

// Get inner classes
$inner_classes = array( 'footer-widgets-inner' );

// Add container class
$inner_classes[] = 'container';

// Turn inner classes into space seperated string
$inner_classes = implode( ' ', $inner_classes ); ?>

<?php do_action( 'before_footer_widgets' ); ?>

<div id="footer-widgets" class="<?php echo esc_attr( $wrap_classes ); ?>">

	<?php do_action( 'before_footer_widgets_inner' ); ?>

	<div class="<?php echo esc_attr( $inner_classes ); ?>">

		<?php
		// Display widgets

			// Footer box 1 ?>
			<?php if( is_active_sidebar( 'footer-one' ) ) : ?>
			<div class="footer-box <?php echo esc_attr( $grid_class ); ?> col col-1">
				<?php dynamic_sidebar( 'footer-one' ); ?>
			</div><!-- .footer-one-box -->
			<?php endif; ?>

			<?php
			// Footer box 2
			if ( $columns > '1' && is_active_sidebar( 'footer-two' ) ) : ?>
				<div class="footer-box <?php echo esc_attr( $grid_class ); ?> col col-2">
					<?php dynamic_sidebar( 'footer-two' ); ?>
				</div><!-- .footer-one-box -->
			<?php endif; ?>

			<?php
			// Footer box 3
			if ( $columns > '2' && is_active_sidebar( 'footer-three' ) ) : ?>
				<div class="footer-box <?php echo esc_attr( $grid_class ); ?> col col-3 ">
					<?php dynamic_sidebar( 'footer-three' ); ?>
				</div><!-- .footer-one-box -->
			<?php endif; ?>

			<?php
			// Footer box 4
			if ( $columns > '3' && is_active_sidebar( 'footer-four' ) ) : ?>
				<div class="footer-box <?php echo esc_attr( $grid_class ); ?> col col-4">
					<?php dynamic_sidebar( 'footer-four' ); ?>
				</div><!-- .footer-box -->
			<?php endif; ?>

	</div><!-- .container -->

	<?php do_action( 'after_footer_widgets_inner' ); ?>

</div><!-- #footer-widgets -->

<?php do_action( 'after_footer_widgets' ); ?>
