<?php
/**
 * Outputs correct page layout
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
} ?>

<article class="single-page-article clr">

<div class="entry clr"<?php acmthemes_schema_markup( 'entry_content' ); ?>>
	<?php do_action( 'before_page_entry' ); ?>
  <?php if ( ! defined( 'ACMBASE_VERSION' ) ) : ?>
    <h1><?php the_title(); ?></h1>
  <?php endif; ?>
	<?php the_content();

	wp_link_pages( array(
		'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'bookchoix' ),
		'after'  => '</div>',
	) ); ?>
	<?php do_action( 'after_page_entry' ); ?>
</div>

<?php
	// Display comments
	comments_template(); ?>

</article>