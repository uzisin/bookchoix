<?php
/**
 * Topbar social profiles
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

//get Acmthemes settings
$acmthemes_settings = (function_exists('acmthemes_settings')) ? acmthemes_settings() : "";

// Get social options array
$social_options = acmthemes_social_options();

// Return if $social_options array is empty
if ( empty( $social_options ) ) {
	return;
}

$link_target = 'blank'; ?>

<div id="top-bar-social" class="clr">

	<ul class="clr">

		<?php
		// Loop through social options
		foreach ( $social_options as $key => $val ) {

			// Get URL from the theme mods
			$url = isset($acmthemes_settings['topbar_social_'.$key]) ? $acmthemes_settings['topbar_social_'.$key] : '';

			// Display if there is a value defined
			if ( $url ) {

				// Display link
				echo '<li class="acmthemes-'. esc_attr( $key ) .'">';

					if ( in_array( $key, array( 'skype' ) ) ) {
						echo '<a href="skype:'. esc_attr( $url ) .'?call" title="'. esc_attr( $val['label'] ) .'" target="_self">';
					} else if ( in_array( $key, array( 'email' ) ) ) {
						echo '<a href="mailto:'. antispambot( esc_attr( $url ) ) .'" title="'. esc_attr( $val['label'] ) .'" target="_self">';
					} else {
						echo '<a href="'. esc_url( $url ) .'" title="'. esc_attr( $val['label'] ) .'" target="_'. esc_attr( $link_target ) .'">';
					}

						echo '<span class="'. esc_attr( $val['icon_class'] ) .'"></span>';

					echo '</a>';

				echo '</li>';

			} // End url check

		} // End loop ?>

	</ul>

</div><!-- #top-bar-social -->
