<?php
/**
 * Topbar custom content
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

//get Acmthemes settings
$acmthemes_settings = (function_exists('acmthemes_settings')) ? acmthemes_settings() : "";

?>
<div id="top-bar-custom-content" class="clr">
	<?php
		if(!empty($acmthemes_settings['topbar_custom_content']))
			echo wp_kses_post($acmthemes_settings['topbar_custom_content']);
	 ?>
</div><!-- #top-bar-custom-content -->
