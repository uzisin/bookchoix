<?php
/**
 * Topbar layout
 *
 * @package BookChoix WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

//don't shop topbar if the core plugin is deactivated
if( ! defined ( 'ACMBASE_VERSION' ) )
	return;

$settings = ( function_exists('acmthemes_settings') ) ? acmthemes_settings() : "";

// Default elements
$topbar_elements = array('topbar_social' => 'Social Icons', 'topbar_custom_content' => 'Topbar Custom Content', 'topbar_nav' => 'Topbar Navigation');

// Get elements from settings
$topbar_elements = ( !empty( $settings['topbar_elements_order'] ) ) ? $settings['topbar_elements_order'] : $topbar_elements;

// Apply filters for easy modification
$topbar_elements = apply_filters( 'topbar_elements_positioning', $topbar_elements );

// Classes
$classes = array( 'clr' );

// Add container class if the top bar is not full width
if ( isset( $settings['fullwidth_topbar'] ) && true == $settings['fullwidth_topbar'] )  {
	$classes[] = 'full-width-topbar';
}
else {
	$classes[] = 'container';
}

// Turn classes into space seperated string
$classes = implode( ' ', $classes ); ?>

<div id="top-bar-wrap" class="<?php echo esc_attr( acmthemes_topbar_classes() ); ?>">

	<div id="top-bar" class="<?php echo esc_attr( $classes ); ?>">

		<?php do_action( 'before_top_bar_inner' ); ?>

		<div id="top-bar-inner" class="clr">

			<?php

			foreach ( $topbar_elements as $topbar_element => $display ) {
				//show social content
				if( 'topbar_social' == $topbar_element && !empty($display) ) {
					get_template_part( 'partials/topbar/social' );
				}

				//show topbar custom content
				if( 'topbar_custom_content' == $topbar_element && !empty($display) ) {
					get_template_part( 'partials/topbar/custom-content' );
				}

				//show topbar custom content
				if( 'topbar_nav' == $topbar_element && has_nav_menu( 'topbar_menu' ) && !empty($display) ) {
	        get_template_part( 'partials/topbar/nav' );
				}
			}

			 ?>

		</div><!-- #top-bar-inner -->

		<?php do_action( 'after_top_bar_inner' ); ?>

	</div><!-- #top-bar -->

</div><!-- #top-bar-wrap -->

<?php do_action( 'after_top_bar' ); ?>
