jQuery(document).ready(function($) {
    "use strict";

  $('#preloader-wrap').fadeOut();

  var $obj = $('#site-header');
  var $wpbar = $('#wpadminbar');
  var $headerHeight = $('#site-header').height();

  $('.siteheader-holder').css('height', $headerHeight);

  $(window).scroll(function (event) {
    // what the y position of the scroll is
    var y = $(this).scrollTop();

    const offsetheight = 50;
    const scrollheight = $headerHeight + offsetheight;

    // whether that's below the form
    if (y >= scrollheight) {
      // if so, add the sticky class and display .siteheader-holder
      $obj.addClass('sticky');
      $('.siteheader-holder').css('display','block');
    } else {
      // otherwise remove it
      $obj.removeClass('sticky');
      $('.siteheader-holder').css('display','none');
    }
    //for adminbar
    if (y >= 47) {
      $wpbar.addClass('hidebar');
    }
    else {
      $wpbar.removeClass('hidebar');
    }

  });

  $('.add_to_wishlist').on('click', function(event){
    $(this).parent().addClass('loading');
  });

  $("#acm-mobile-menu").mmenu(
    {
      position: "left",
      zposition: "front",
      header: {add: true, title: "Menu", update: "true"},
      counters: true,
      slidingSubmenus: true,
      searchfield: false
    });

    $('.acm-search-replace').on('click', function(event){

      event.preventDefault();

      $('#searchform-header-replace').removeClass("hide");
      $('#searchform-header-replace').addClass("show");
      $('#site-navigation').removeClass("show");
      $('#site-navigation').addClass("hide");

    });

    $('#searchform-header-replace-close').on('click', function(event){

      event.preventDefault();

      $('#searchform-header-replace').removeClass("show");
      $('#searchform-header-replace').addClass("hide");
      $('#site-navigation').removeClass("hide");
      $('#site-navigation').addClass("show");

    });

    $('.mobile-search-toggle').on('click', function(event){

      event.preventDefault();

      $('#mobile-menu-search').fadeToggle(600);

    });

    $('.nav-menu-search .site-search-toggle').on('click', function(event){

      event.preventDefault();

      $('.bkc-search-popup').removeClass("hide");
      $('.bkc-search-popup').addClass("show");

    });

    $('.bkc-search-popup-close-btn').on('click', function(event){

      event.preventDefault();

      $('.bkc-search-popup').removeClass("show");
      $('.bkc-search-popup').addClass("hide");

    });

    $('.ajax_add_to_cart').on('click', function(event) {
        event.preventDefault();
        $(this).parent().parent().addClass("product-added");
    });

    $('#wpadminbar').css('position','fixed');

});
