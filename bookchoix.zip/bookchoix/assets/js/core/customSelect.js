var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
	// Custom select
	acmthemesCustomSelects();
} );

/* ==============================================
CUSTOM SELECT
============================================== */
function acmthemesCustomSelects() {
	"use strict"

	$j( acmthemesLocalize.customSelects ).customSelect( {
		customClass: 'theme-select'
	} );

}