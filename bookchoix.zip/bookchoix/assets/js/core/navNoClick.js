var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
	// Nav no click
	acmthemesNavNoClick();
} );

/* ==============================================
NAV NO CLICK
============================================== */
function acmthemesNavNoClick() {
	"use strict"

	$j( 'li.nav-no-click > a' ).on( 'click', function() {
		return false;
	} );

}