<?php
/**
 * This file includes helper functions used throughout the theme.
 *
 * @package BookChoix WordPress theme
 */

/*-------------------------------------------------------------------------------*/
/* [ Table of contents ]
/*-------------------------------------------------------------------------------*

	# General
	# Top Bar
	# Header
	# Page Header
	# Blog
	# Footer
	# WooCommerce
	# Other

/*-------------------------------------------------------------------------------*/
/* [ General ]
/*-------------------------------------------------------------------------------*/

/**
 * get theme framework settings
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_settings' ) ) {

   function acmthemes_settings($option_name = '') {
       global $bookchoix_settings;

       if( empty( $bookchoix_settings ) ) {
         $bookchoix_settings = get_option( 'bookchoix_settings' );
       }

       if(empty($option_name))
        return $bookchoix_settings;

       else {

         if(isset($bookchoix_settings[$option_name]))
           return $bookchoix_settings[$option_name];
         else return NULL;

       }

   }

}

/**
 * Adds classes to the html tag
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_html_classes' ) ) {

	function acmthemes_html_classes() {

		// Setup classes array
		$classes = array();

		// Main class
		$classes[] = 'html';

    //add bookchoix theme class
    $classes[] = 'bkchtml';

		// Set keys equal to vals
		$classes = array_combine( $classes, $classes );

		// Apply filters for child theming
		$classes = apply_filters( 'html_classes', $classes );

		// Turn classes into space seperated string
		$classes = implode( ' ', $classes );

		// Return classes
		return $classes;

	}

}

/**
 * Adds classes to the body tag
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_body_classes' ) ) {

	function acmthemes_body_classes( $classes ) {

    //get theme Options
    $settings = acmthemes_settings();

		// Vars
		$post_layout  = acmthemes_post_layout();
		$layout_style = 'wide';
		$post_id      = acmthemes_post_id();
		$mobile_style = acmthemes_mobile_menu_style();

		// RTL
		if ( is_rtl() ) {
			$classes[] = 'rtl';
		}

		// Main class
		$classes[] = 'acmthemes-theme';

		// Mobile menu style
		$classes[] = $mobile_style . '-mobile';

		// If video header
		if ( function_exists( 'has_header_video' )
			&& has_header_video() ) {
			$classes[] = 'has-header-video';
		}

		// Boxed layout
		if ( 'boxed' == $layout_style ) {
			$classes[] = 'boxed-layout';

      if( isset( $settings['boxed_drop_shadow'] ) && $settings['boxed_drop_shadow'] === true ) {
				$classes[] = 'wrap-boxshadow';
			}
		}

		// If is not custom header created with Elementor Pro 2.0
		if ( ! function_exists( 'elementor_location_exits' ) || ! elementor_location_exits( 'header', true ) ) {

			// Top menu header style to control the responsive
			if ( 'header-default' == acmthemes_header_style() ) {
				$classes[] = 'header-default-style';
			}

			// Medium header style to control the responsive
			if ( 'header-fullwidth-navi' == acmthemes_header_style() ) {
				$classes[] = 'header-fullwidth-navi-style';
			}

			// Add transparent class for header styles
			if ( 'header-transparent' == acmthemes_header_style() ) {
				$classes[] = 'has-transparent-header';
			}

		}

		//mobile breakpoint
		$classes[] = 'default-breakpoint';

		// Sidebar enabled
		if ( 'left-sidebar' == $post_layout
			|| 'right-sidebar' == $post_layout
			|| 'both-sidebars' == $post_layout ) {
			$classes[] = 'has-sidebar';
		}

		// Mobile sidebar order
		if ( 'sidebar-content' == acmthemes_sidebar_order() ) {
			$classes[] = 'sidebar-content';
		}

		// Content layout
		if ( $post_layout ) {
			$classes[] = 'content-'. $post_layout;
		}

		// If full width and has content width
		if ( 'full-width' == $post_layout ) {
			$classes[] = 'content-max-width';
		}

		// Single Post cagegories
		if ( is_singular( 'post' ) ) {
			$cats = get_the_category( $post_id );
			foreach ( $cats as $cat ) {
				$classes[] = 'post-in-category-'. $cat->category_nicename;
			}
		}

		// If landing page template
		if ( is_page_template( 'templates/landing.php' ) ) {
			$classes[] = 'landing-page';
		}

		// Topbar
		if ( acmthemes_display_topbar() ) {
			$classes[] = 'has-topbar';
		}

		// Title with Background Image
		if ( 'background-image' == acmthemes_page_header_style() ) {
			$classes[] = 'page-with-background-title';
		}

		// Disabled header
		if ( ! acmthemes_has_page_header() && ! is_front_page() ) {
			$classes[] = 'page-header-disabled';
		}

    //page header status
    $page_header_status = get_post_meta( $post_id, 'show_page_header', true );

    $show_page_header = false;
  	if ( isset( $settings['enable_page_header'] ) && !empty( $settings['enable_page_header'] )) {
  		$show_page_header = true;
  	}
  	if( !empty( $page_header_status ) && $page_header_status == 'show' ) {
  		$show_page_header = true;
  	}
  	elseif( !empty( $page_header_status ) && $page_header_status == 'hide' ) {
  		$show_page_header = false;
  	}
    if ( ! is_front_page() && $show_page_header ) {
      $classes[] = 'has-page-header';
    }
    elseif( ! is_front_page() ) {
      $classes[] = 'page-header-disbled';
    }

		// Breadcrumbs
		if ( acmthemes_has_breadcrumbs() ) {
			$classes[] = 'has-breadcrumbs';
		}

		// If WooCommerce is active
		if ( ACMTHEMES_WOOCOMMERCE_ACTIVE ) {

			//grid/list buttons
			$classes[] = 'has-grid-list';

		}

    //add core plugin status to body class
    if ( ! function_exists ( 'acmthemes_settings_css' ) ) {
      $classes[] = 'core-plugin-deactivated';
    }
    else {
      $classes[] = 'core-plugin-activated';
    }

		// Return classes
		return $classes;

	}

	add_filter( 'body_class', 'acmthemes_body_classes' );

}

/**
 * Add classes to the blog content area
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_content_area_class' ) ) {

	function acmthemes_blog_content_area_class() {

    //get settings data
		$settings = acmthemes_settings();

    //set content area default position
    $content_area_class = 'content-area-full';

    //set position if sidebar is active
    if ( is_active_sidebar( 'sidebar' ) ) {
    	$content_area_class = 'content-area';
    }

    //set content area position
    if( !empty( $settings['blog_layout'] ) && $settings['blog_layout'] == 'left' ) {
    	$content_area_class = 'content-area-right';
    }
    elseif( !empty( $settings['blog_layout'] ) && $settings['blog_layout'] == 'right' ) {
    	$content_area_class = 'content-area';
    }
    elseif( !empty( $settings['blog_layout'] ) && $settings['blog_layout'] == 'fullwidth' ) {
    	$content_area_class = 'content-area-full';
    }

    //post list content area class filter
    $content_area_class = apply_filters( 'post_list_content_area_class', $content_area_class );

		// return classes
		return $content_area_class;

	}

}

/**
 * Add classes to the single post content area
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_singular_content_area_class' ) ) {

	function acmthemes_singular_content_area_class() {

    //get settings data
		$settings = acmthemes_settings();

    //get post id
    $post_id = get_the_ID();

    //set content area default position
    $content_area_class = 'content-area-full';

    //set position if sidebar is active
    if ( is_active_sidebar( 'sidebar' ) ) {
    	$content_area_class = 'content-area';
    }

    //set content area position
    if( !empty( $settings['blog_layout'] ) && $settings['blog_layout'] == 'left' ) {
    	$content_area_class = 'content-area-right';
    }
    elseif( !empty( $settings['blog_layout'] ) && $settings['blog_layout'] == 'right' ) {
    	$content_area_class = 'content-area';
    }
    elseif( !empty( $settings['blog_layout'] ) && $settings['blog_layout'] == 'fullwidth' ) {
    	$content_area_class = 'content-area-full';
    }

    //set content area position for invidual post
    $indv_post_layout = get_post_meta( $post_id, 'this_post_layout', true );

    if( !empty( $indv_post_layout ) && $indv_post_layout == 'left' ) {
    	$content_area_class = 'content-area-right';
    }
    elseif( !empty( $indv_post_layout ) && $indv_post_layout == 'right' ) {
    	$content_area_class = 'content-area';
    }
    elseif( !empty( $indv_post_layout ) && $indv_post_layout == 'fullwidth' ) {
    	$content_area_class = 'content-area-full';
    }

    $content_area_class = apply_filters( 'blog_single_content_area_class', $content_area_class );

		// return classes
		return $content_area_class;

	}

}

/**
 * Add classes to the page content area
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_page_content_area_class' ) ) {

	function acmthemes_page_content_area_class() {

    //get settings data
		$settings = acmthemes_settings();

    //set content area position
    if( !empty( $settings['page_layout'] ) && $settings['page_layout'] == 'left' ) {
    	$content_area_class = 'content-area-right';
    }
    elseif( !empty( $settings['page_layout'] ) && $settings['page_layout'] == 'right' ) {
    	$content_area_class = 'content-area';
    }
    elseif( !empty( $settings['page_layout'] ) && $settings['page_layout'] == 'fullwidth' ) {
    	$content_area_class = 'content-area-full';
    }
    $hide_sidebar = acmthemes_is_fullscreen_page();

    //if account page
    if( ACMTHEMES_WOOCOMMERCE_ACTIVE && is_account_page() ) {
      $content_area_class = 'content-area-full';
    }
    $content_area_class = ( $hide_sidebar ) ? 'content-area-full' : $content_area_class;

    //page content area class filter
    $content_area_class = apply_filters( 'page_content_area_class', $content_area_class );

		// return classes
		return $content_area_class;

	}

}

/**
 * Add classes to the shop content area
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_shop_content_area_class' ) ) {

	function acmthemes_shop_content_area_class() {

    	//get settings data
		$settings = acmthemes_settings();

		//set content area position
		$content_area_class = 'content-area-full';

		//get sidebar settings from theme settings
		if( !empty( $settings['shop_layout'] ) && $settings['shop_layout'] == 'left' ) {
			$content_area_class = 'content-area-right';
		}
		elseif( !empty( $settings['shop_layout'] ) && $settings['shop_layout'] == 'right' ) {
			$content_area_class = 'content-area';
		}
		elseif( !empty( $settings['shop_layout'] ) && $settings['shop_layout'] == 'fullwidth' ) {
			$content_area_class = 'content-area-full';
		}

		//set fullwidth for single product page
		if( is_product() )
			$content_area_class = 'content-area-full';

		if( is_product_category() && !empty( $settings['shop_archive_layout'] ) && $settings['shop_archive_layout'] == 'left' ) {
			$content_area_class = 'content-area-right';
		}
		elseif( is_product_category() && !empty( $settings['shop_archive_layout'] ) && $settings['shop_archive_layout'] == 'right' ) {
			$content_area_class = 'content-area';
		}
		elseif( is_product_category() && !empty( $settings['shop_archive_layout'] ) && $settings['shop_archive_layout'] == 'fullwidth' ) {
			$content_area_class = 'content-area-full';
		}	

		//shop content area class filter for both archive and single pages
		$content_area_class = apply_filters( 'shop_content_area_class', $content_area_class );

		// return classes
		return $content_area_class;

	}

}

/**
 * Store current post ID
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_post_id' ) ) {

	function acmthemes_post_id() {

		// Default value
		$id = '';

		// If singular get_the_ID
		if ( is_singular() ) {
			$id = get_the_ID();
		}

		// Get ID of WooCommerce product archive
		elseif ( ACMTHEMES_WOOCOMMERCE_ACTIVE && is_shop() ) {
			$shop_id = wc_get_page_id( 'shop' );
			if ( isset( $shop_id ) ) {
				$id = $shop_id;
			}
		}

		// Posts page
		elseif ( is_home() && $page_for_posts = get_option( 'page_for_posts' ) ) {
			$id = $page_for_posts;
		}

		// Apply filters
		$id = apply_filters( 'post_id', $id );

		// Sanitize
		$id = $id ? $id : '';

		// Return ID
		return $id;

	}

}

/**
 * Show custom product meta on single product page
 *
 * @since 1.0.0
 */
function acmthemes_show_single_product_meta() {
   global $product;
   ?>
   <div class="product_meta">
   <?php if ( wc_product_sku_enabled() && ( $product->get_sku() || $product->is_type( 'variable' ) ) ) : ?>
      <div class="product_meta_wrap single_sku_wrapper">
        <span class="product_meta_label"><?php esc_html_e( 'SKU:', 'bookchoix' ); ?></span>
        <span class="single_sku product_meta_value"><?php echo esc_attr( $sku = $product->get_sku() ) ? $sku : esc_html__( 'N/A', 'bookchoix' ); ?></span>
      </div>
   <?php endif; ?>

   <?php if ( count( $product->get_category_ids() ) > 0 ) : ?>
   <div class="product_meta_wrap single_cat_wrapper">
     <span class="product_meta_label">
       <?php echo _n( 'Category: ', 'Categories: ', count( $product->get_category_ids() ), 'bookchoix' ); ?>
     </span>
     <span class="product_meta_value">
     <?php echo wc_get_product_category_list( $product->get_id(), ', ' ); ?>
     </span>
   </div>
  <?php endif; ?>

  <?php if ( count( $product->get_tag_ids() ) > 0 ) : ?>
  <div class="product_meta_wrap single_tag_wrapper">
    <span class="product_meta_label">
      <?php echo _n( 'Tag: ', 'Tags: ', count( $product->get_tag_ids() ), 'bookchoix' ); ?>
    </span>
    <span class="product_meta_value">
    <?php echo wc_get_product_tag_list( $product->get_id(), ', ' ); ?>
    </span>
  </div>
 <?php endif; ?>

   </div>
   <?php
}

/**
 * Returns correct post layout
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_post_layout' ) ) {

	function acmthemes_post_layout() {

		// Define variables
		$class  = 'full-width';
		$meta   = get_post_meta( acmthemes_post_id(), 'post_layout', true );

		// Check meta first to override and return (prevents filters from overriding meta)
		if ( $meta ) {
			return $meta;
		}

		// Singular Page
		if ( is_page() ) {

			// Landing template
			if ( is_page_template( 'templates/landing.php' ) ) {
				$class = 'full-width';
			}

			// Attachment
			elseif ( is_attachment() ) {
				$class = 'full-width';
			}

		}

		// Library and Elementor template
		elseif ( is_singular( 'acmthemes_library' )
    			|| is_singular( 'elementor_library' ) ) {
			$class = 'full-width';
		}

		// 404 page
		elseif ( is_404() ) {
			$class = 'full-width';
		}

		// Class should never be empty
		if ( empty( $class ) ) {
			$class = 'full-width';
		}

		// Apply filters and return
		return apply_filters( 'post_layout_class', $class );

	}

}

/**
 * Returns correct both sidebars style layout
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_both_sidebars_style' ) ) {

	function acmthemes_both_sidebars_style() {

		// Meta
		$meta = get_post_meta( acmthemes_post_id(), 'both_sidebars_style', true );

		// Check meta first to override and return (prevents filters from overriding meta)
		if ( $meta ) {
			return $meta;
		}

		// Class should never be empty
		if ( empty( $class ) ) {
			$class = 'scs-style';
		}

		// Apply filters and return
		return apply_filters( 'both_sidebars_style', $class );

	}

}

/**
 * Mobile sidebar order
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_sidebar_order' ) ) {

	function acmthemes_sidebar_order() {

		// Define variables
		$order  = 'content-sidebar';

		// Apply filters and return
		return apply_filters( 'sidebar_order', $order );

	}

}

/**
 * Get the sidebar
 *
 * @since  1.0.0
 */
if ( ! function_exists( 'acmthemes_display_sidebar' ) ) {

	function acmthemes_display_sidebar() {

		// Retunr if full width or full screen
		if ( in_array( acmthemes_post_layout(), array( 'full-screen', 'full-width' ) ) ) {
			return;
		}

		// Add the second sidebar
		if ( 'both-sidebars' == acmthemes_post_layout() ) {
			get_sidebar( 'left' );
		}

		// Add the default sidebar
		get_sidebar();

	}

}

/**
 * Returns the sidebar
 *
 * @since  1.0.0
 */
if ( ! function_exists( 'acmthemes_sidebar_action' ) ) {

	function acmthemes_sidebar_action() {

		if ( 'sidebar-content' == acmthemes_sidebar_order()
			&& 'both-sidebars' != acmthemes_post_layout() ) {
			$action = 'before_primary';
		} else {
			$action = 'after_primary';
		}

		add_action( $action, 'acmthemes_display_sidebar' );

	}

	add_action( 'wp', 'acmthemes_sidebar_action', 20 );

}

/**
 * Returns the correct sidebar ID
 *
 * @since  1.0.0
 */
if ( ! function_exists( 'acmthemes_get_sidebar' ) ) {

	function acmthemes_get_sidebar( $sidebar = 'sidebar' ) {

		//get theme settings
		$settings = acmthemes_settings();
    $is_woo_active = acmthemes_is_woocommerce_activated();

    //default sidebar
    $sidebar = 'sidebar';

		// Search
		if ( is_search()
			&& isset( $settings[ 'product_search_custom_sidebar' ] ) && $settings[ 'product_search_custom_sidebar' ] ) {
			$sidebar = 'search_sidebar';
		}

    // Search
		if ( $is_woo_active === true ) {
			if( is_shop() || is_product() || is_product_category() || is_product_tag() || is_account_page() || is_tax('authors') ) {
  			$sidebar = 'shop_sidebar';
      }
		}

		// Add filter for tweaking the sidebar display via child theme's
		$sidebar = apply_filters( 'get_sidebar', $sidebar );

		// Return the correct sidebar
		return $sidebar;

	}

}

/**
 * Returns the correct second sidebar ID
 *
 * @since  1.0.0
 */
if ( ! function_exists( 'acmthemes_get_second_sidebar' ) ) {

	function acmthemes_get_second_sidebar( $sidebar = 'sidebar-2' ) {

		// Add filter for tweaking the left sidebar display via child theme's
		$sidebar = apply_filters( 'get_second_sidebar', $sidebar );

		// Never show empty sidebar
		if ( ! is_active_sidebar( $sidebar ) ) {
			$sidebar = 'sidebar-2';
		}

		// Return the correct sidebar
		return $sidebar;

	}

}

/**
 * Returns offcanvas sidebar
 *
 * @since  1.4.0
 */
if ( ! function_exists( 'acmthemes_offcanvas_sidebar' ) ) {

	function acmthemes_offcanvas_sidebar() {

		get_template_part( 'woocommerce/content', 'offcanvas-sidebar' );

	}
	add_action('before_top_bar', 'acmthemes_offcanvas_sidebar', 0);

}

/**
 * Returns the correct classname for any specific column grid
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_grid_class' ) ) {

	function acmthemes_grid_class( $col = '4' ) {
		return esc_attr( apply_filters( 'grid_class', 'span_1_of_'. $col ) );
	}

}

/**
 * Removes the scheme of the passed URL to fit the current page.
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_correct_url_scheme' ) ) {

	function acmthemes_correct_url_scheme( $url ) {

		$url = str_replace( 'http://', '//', str_replace( 'https://', '//', $url ) );

		return $url;
	}

}

/**
 * Gets the attachment ID from the url
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_attachment_id_from_url' ) ) {

	function acmthemes_get_attachment_id_from_url( $attachment_url = '' ) {

		global $wpdb;
		$attachment_id = false;

		if ( '' == $attachment_url || ! is_string( $attachment_url ) ) {
			return '';
		}

		$upload_dir_paths = wp_upload_dir();
		$upload_dir_paths_baseurl = $upload_dir_paths['baseurl'];

		if ( substr( $attachment_url, 0, 2 ) == '//' ) {
			$upload_dir_paths_baseurl = acmthemes_correct_url_scheme( $upload_dir_paths_baseurl );
		}

		// Make sure the upload path base directory exists in the attachment URL, to verify that we're working with a media library image.
		if ( false !== strpos( $attachment_url, $upload_dir_paths_baseurl ) ) {

			// If this is the URL of an auto-generated thumbnail, get the URL of the original image.
			$attachment_url = preg_replace( '/-\d+x\d+(?=\.(jpg|jpeg|png|gif|tiff|svg)$)/i', '', $attachment_url );

			// Remove the upload path base directory from the attachment URL.
			$attachment_url = str_replace( $upload_dir_paths_baseurl . '/', '', $attachment_url );

			// Run a custom database query to get the attachment ID from the modified attachment URL.
			$attachment_id = $wpdb->get_var( $wpdb->prepare( "SELECT wposts.ID FROM $wpdb->posts wposts, $wpdb->postmeta wpostmeta WHERE wposts.ID = wpostmeta.post_id AND wpostmeta.meta_key = '_wp_attached_file' AND wpostmeta.meta_value = '%s' AND wposts.post_type = 'attachment'", $attachment_url ) );
			$attachment_id = apply_filters( 'wpml_object_id', $attachment_id, 'attachment' );
		}

		return $attachment_id;

	}

}

/**
 * Gets the most important attachment data from the url
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_attachment_data_from_url' ) ) {

	function acmthemes_get_attachment_data_from_url( $attachment_url = '' ) {

		if ( '' == $attachment_url ) {
			return false;
		}

		$attachment_data['url'] = preg_replace( '/-\d+x\d+(?=\.(jpg|jpeg|png|gif)$)/i', '', $attachment_url );
		$attachment_data['id'] = acmthemes_get_attachment_id_from_url( $attachment_data['url'] );

		if ( ! $attachment_data['id'] ) {
			return false;
		}

		preg_match( '/\d+x\d+(?=\.(jpg|jpeg|png|gif)$)/i', $attachment_url, $matches );
		if ( count( $matches ) > 0 ) {
			$dimensions 				= explode( 'x', $matches[0] );
			$attachment_data['width'] 	= $dimensions[0];
			$attachment_data['height'] 	= $dimensions[1];
		} else {
			$attachment_src 			= wp_get_attachment_image_src( $attachment_data['id'], 'full' );
			$attachment_data['width'] 	= $attachment_src[1];
			$attachment_data['height'] 	= $attachment_src[2];
		}

		$attachment_data['alt'] 	= get_post_field( '_wp_attachment_image_alt', $attachment_data['id'] );
		$attachment_data['caption'] = get_post_field( 'post_excerpt', $attachment_data['id'] );
		$attachment_data['title'] 	= get_post_field( 'post_title', $attachment_data['id'] );

		return $attachment_data;
	}

}

/**
 * Pre-loader template
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_preloader_template' ) ) {

	function acmthemes_preloader_template() {

		get_template_part( 'templates/loader' );

	}

	add_action( 'before_outer_wrap', 'acmthemes_preloader_template', 1 );

}

/**
 * Add classes to the header wrap
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_wrap_class' ) ) {

	function acmthemes_wrap_class() {

    //get settings data
		$settings = acmthemes_settings();

		// Setup classes array
		$classes = array();

    if( isset( $settings['layout_style'] ) && $settings['layout_style'] == 'boxed' ) {
      $classes[] = 'boxed-layout';
    }

    if( isset( $settings['enable_boxed_shadow'] ) && $settings['enable_boxed_shadow'] == '1' ) {
      $classes[] = 'wrap-boxshadow';
    }

    $classes[] = 'site';
    $classes[] = 'clr';

		// Apply filters for child theme
		$classes = apply_filters( 'acmthemes_wrap_class', $classes );

		// combine class names to a string
		$classes = implode( ' ', $classes );

		// return classes
		return $classes;

	}

}


function acmthemes_siteheader_holder() {
  ?>
  <div class="siteheader-holder"></div>
  <?php
}
add_action( 'before_top_bar', 'acmthemes_siteheader_holder' );

/**
 * Display top bar
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_display_topbar' ) ) {

	function acmthemes_display_topbar() {

		//get theme settings
		$settings = acmthemes_settings();

		// Return true by default
		$return = true;

		// Return false if disabled via Customizer
		if ( !empty($settings['']) && 1 != $settings[''] ) {
			$return = false;
		}

		// Apply filters and return
		return apply_filters( 'display_top_bar', $return );

	}

}

/**
 * Top bar template
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_top_bar_template' ) ) {

	function acmthemes_top_bar_template() {

		//get theme settings
		$settings = acmthemes_settings();

		// Return true by default
		$return = true;

		if ( isset ( $settings['hide_topbar'] ) && 1 == $settings['hide_topbar'] ) {
			$return = false;
		}

		// Apply filters and return
		apply_filters( 'display_top_bar', $return );

		if ( $return )
			get_template_part( 'partials/topbar/layout' );

	}

	add_action( 'top_bar', 'acmthemes_top_bar_template' );

}

/**
 * Add classes to the top bar wrap
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_topbar_classes' ) ) {

	function acmthemes_topbar_classes() {

		// Setup classes array
		$classes = array();

		// Clearfix class
		$classes[] = 'clr';

		// Visibility
		$visibility = 'all-devices';
		if ( 'all-devices' != $visibility ) {
			$classes[] = $visibility;
		}

		// Set keys equal to vals
		$classes = array_combine( $classes, $classes );

		// Apply filters for child theming
		$classes = apply_filters( 'topbar_classes', $classes );

		// Turn classes into space seperated string
		$classes = implode( ' ', $classes );

		// return classes
		return $classes;

	}

}

/**
 * Topbar Content classes
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_topbar_content_classes' ) ) {

	function acmthemes_topbar_content_classes() {

		// Define classes
		$classes = array( 'clr' );

		// Apply filters for child theming
		$classes = apply_filters( 'top_bar_classes', $classes );

		// Turn classes array into space seperated string
		$classes = implode( ' ', $classes );

		// Return classes
		return esc_attr( $classes );

	}

}

/*-------------------------------------------------------------------------------*/
/* [ Header ]
/*-------------------------------------------------------------------------------*/

/**
 * Display header
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_display_header' ) ) {

	function acmthemes_display_header() {

		// Return true by default
		$return = true;

		// Apply filters and return
		return apply_filters( 'display_header', $return );

	}

}

/**
 * Header template
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_template' ) ) {

	function acmthemes_header_template() {

		// Return if no header
		if ( ! acmthemes_display_header() ) {
			return;
		}

		get_template_part( 'partials/header/layout' );

	}

	add_action( 'header', 'acmthemes_header_template' );

}

/**
 * Header style
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_style' ) ) {

	function acmthemes_header_style() {

		// Get header style settings
		$settings = acmthemes_settings();

    //get individual page header style
    $indv_page_header_style = get_post_meta( get_the_ID(), 'indv_page_header_style', true );
    if( isset( $indv_page_header_style ) && ! empty( $indv_page_header_style ) ) {
      $header_style = $indv_page_header_style;
    }
    elseif( is_page() ) {
      $header_style = ( isset( $settings['header_style'] ) ) ? $settings['header_style'] : 'header-default';
    }
    else {
      $header_style = 'header-default';
    }

		// Apply filters and return
		return apply_filters( 'header_style', $header_style );

	}

}

/**
 * Custom header style template
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_custom_header_template' ) ) {

	function acmthemes_custom_header_template() {

		// Get template from customizer setting
		$template = 'header_template';

		// Apply filters and return
		return apply_filters( 'custom_header_template', $template );

	}

}

/**
 * Add classes to the header wrap
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_classes' ) ) {

	function acmthemes_header_classes() {

		// Header style
		$header_style = acmthemes_header_style();

		// Setup classes array
		$classes = array();

		// If is not custom header created with Elementor Pro 2.0
		if ( ! function_exists( 'elementor_location_exits' ) || ! elementor_location_exits( 'header', true ) ) {

			// Add header style class
			$classes[] = $header_style . '-style';

			// Search overlay
			if ( 'overlay' == acmthemes_menu_search_style() ) {
				$classes[] = 'search-overlay';
			}

			// If the search header replace
			if ( 'header_replace' == acmthemes_menu_search_style() ) {
				$classes[] = 'header-replace';
			}

			// If has header media
			if ( has_header_image() ) {
				$classes[] = 'has-header-media';
			}

		}

		// Clearfix class
		$classes[] = 'clr';

		// Set keys equal to vals
		$classes = array_combine( $classes, $classes );

		// Apply filters for child theming
		$classes = apply_filters( 'header_classes', $classes );

		// Turn classes into space seperated string
		$classes = implode( ' ', $classes );

		// return classes
		return $classes;

	}

}

/**
 * Add classes to the top header style wrap
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_top_header_classes' ) ) {

	function acmthemes_top_header_classes() {

		// Header style
		$header_style = acmthemes_header_style();

		// Return if is not the top header style
		if ( 'top' != $header_style ) {
			return;
		}

		// Setup classes array
		$classes = array();

		// Add classes
		$classes[] = 'header-top';

		// Clearfix class
		$classes[] = 'clr';

		// Set keys equal to vals
		$classes = array_combine( $classes, $classes );

		// Apply filters for child theming
		$classes = apply_filters( 'top_header_classes', $classes );

		// Turn classes into space seperated string
		$classes = implode( ' ', $classes );

		// return classes
		return $classes;

	}

}

/**
 * Add srcset for retina header logo
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_retina_logo' ) ) {

	function acmthemes_header_retina_logo( $attr, $attachment, $size ) {

		$attr['srcset'] = '';

		// Get logo
		$custom_logo 	= acmthemes_header_logo_setting();

		// Get retina logo
		$retina_logo 	= acmthemes_header_retina_logo_setting();

		if ( $custom_logo && $retina_logo ) {

			$cutom_logo_src = wp_get_attachment_image_src( $custom_logo , 'full' );
			$cutom_logo_url = $cutom_logo_src[0];

			$attr['srcset'] = $cutom_logo_url . ' 1x, ' . $retina_logo . ' 2x';

			// Remove the size attr
			unset( $attr['sizes'] );

		}

		// Return attr
		return $attr;

	}

}

/**
 * Returns full screen header logo
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_full_screen_logo' ) ) {

	function acmthemes_header_full_screen_logo() {

    //get framework settings
		$settings = acmthemes_settings();

		$html = '';

		// Get logo
		$logo_url 		= $settings['full_screen_header_logo']['url'];
		$retina_url 	= $settings['full_screen_header_retina_logo']['url'];
		$srcset 		= '';

		// Logo data
		$logo_data = array(
			'url'    	=> '',
			'width'  	=> '',
			'height' 	=> '',
			'alt' 		=> '',
		);

		if ( $logo_url ) {

			// Logo url
			$logo_data['url'] 			= $logo_url;

			// Logo data
			$logo_attachment_data 		= acmthemes_get_attachment_data_from_url( $logo_url );

			// Get logo data
			if ( $logo_attachment_data ) {
				$logo_data['width']  	= $logo_attachment_data['width'];
				$logo_data['height'] 	= $logo_attachment_data['height'];
				$logo_data['alt'] 		= $logo_attachment_data['alt'];
			}

			// Add srcset attr
			if ( $retina_url ) {
				$srcset = $logo_url . ' 1x, ' . $retina_url . ' 2x';
				$srcset = 'srcset="'. $srcset .'"';
			}

			// Output image
			if( isset( $settings['logo_link_type'] ) && 'none' == $settings['logo_link_type'] ) {
				$html = sprintf( '<img src="%1$s" class="full-screen-logo" width="160" height="auto" alt="%2$s" %3$s />',
				esc_url( $logo_data['url'] ),
				esc_attr( $logo_data['alt'] ),
				$srcset
			);
			}
			else {

				$home_link = ( isset( $settings['logo_link_type'] ) && 'custom' == $settings['logo_link_type'] && ! empty( $settings['logo_custom_link'] ) ) ? $settings['logo_custom_link'] : home_url( '/' );

				$html = sprintf( '<a href="%1$s" class="full-screen-logo-link" rel="home"'. acmthemes_get_schema_markup( 'url' ) .'><img src="%2$s" class="full-screen-logo" width="%3$s" height="%4$s" alt="%5$s" %6$s /></a>',
				esc_url( $home_link ),
				esc_url( $logo_data['url'] ),
				esc_attr( $logo_data['width'] ),
				esc_attr( $logo_data['height'] ),
				esc_attr( $logo_data['alt'] ),
				$srcset
			);
			
		  }

		}

		// Return logo
		return apply_filters( 'full_screen_header_logo', $html );

	}

}

/**
 * Echo full_screen header logo
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_custom_full_screen_logo' ) ) {

	function acmthemes_custom_full_screen_logo() {
		echo acmthemes_header_full_screen_logo();
	}

}


/**
 * Returns AcmThemes default logo
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_default_logo' ) ) {

	function acmthemes_header_default_logo() {
		
		$settings = acmthemes_settings();
		
		$html = '';

		// Get logo
		$logo_url = ACMTHEMES_THEME_URI . '/assets/img/bookchoix-logo.svg';

		if ( $logo_url && isset( $settings['logo_link_type'] ) && 'none' == $settings['logo_link_type'] ) {

			// Output image
			$html = sprintf( '<img src="%1$s" class="responsive-logo" alt="%2$s" width="150" height="auto" />',
				esc_url( $logo_url ),
				esc_attr( get_bloginfo('name') )
			);

		}
		elseif( $logo_url ) {
			// Output image
			$html = sprintf( '<a href="%1$s" class="default-logo-link" rel="home"'. acmthemes_get_schema_markup( 'url' ) .'><img src="%2$s" class="responsive-logo" alt="%3$s" /></a>',
				esc_url( home_url( '/' ) ),
				esc_url( $logo_url ),
				esc_attr( get_bloginfo('name') )
			);
		}

		// Return logo
		return apply_filters( 'header_default_logo', $html );

	}

}

/**
 * Echo full_screen header logo
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_default_logo' ) ) {

	function acmthemes_default_logo() {
		echo acmthemes_header_default_logo();
	}

}

/**
 * Returns AcmThemes default logo
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_mobile_logo' ) ) {

	function acmthemes_header_mobile_logo() {

    //get framework settings
		$settings = acmthemes_settings();

		$html = '';

		// Get logo
		$logo_url 		= $settings['mob_screen_header_logo']['url'];
		$srcset 		= '';

		// Logo data
		$logo_data = array(
			'url'    	=> '',
			'width'  	=> '',
			'height' 	=> '',
			'alt' 		=> '',
		);

		if ( $logo_url ) {

			// Logo url
			$logo_data['url'] 			= $logo_url;

			// Logo data
			$logo_attachment_data 		= acmthemes_get_attachment_data_from_url( $logo_url );

			// Get logo data
			if ( $logo_attachment_data ) {
				$logo_data['width']  	= $logo_attachment_data['width'];
				$logo_data['height'] 	= $logo_attachment_data['height'];
				$logo_data['alt'] 		= $logo_attachment_data['alt'];
			}

			// Output image
			if( isset( $settings['logo_link_type'] ) && 'none' == $settings['logo_link_type'] ) {
				$html = sprintf( '<img src="%1$s" class="mobile-screen-logo" width="140" height="auto" alt="%2$s" />',
				esc_url( $logo_data['url'] ),
				esc_attr( $logo_data['alt'] )
			);
			}
			else {

				$home_link = ( isset( $settings['logo_link_type'] ) && 'custom' == $settings['logo_link_type'] && ! empty( $settings['logo_custom_link'] ) ) ? $settings['logo_custom_link'] : home_url( '/' );

				$html = sprintf( '<a href="%1$s" class="mobile-screen-logo-link" rel="home"'. acmthemes_get_schema_markup( 'url' ) .'><img src="%2$s" class="mobile-screen-logo" width="%3$s" height="%4$s" alt="%5$s" /></a>',
					esc_url( $home_link ),
					esc_url( $logo_data['url'] ),
					esc_attr( $logo_data['width'] ),
					esc_attr( $logo_data['height'] ),
					esc_attr( $logo_data['alt'] )
				);
			}
			

		}

		// Return logo
		return apply_filters( 'header_mobile_logo', $html );

	}

}

/**
 * Echo full_screen header logo
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_mobile_logo' ) ) {

	function acmthemes_mobile_logo() {
		echo acmthemes_header_mobile_logo();
	}

}

/**
 * Returns social sharing template part
 */
if ( ! function_exists( 'acmthemes_medium_header_elements' ) ) {

	function acmthemes_medium_header_elements() {

		// Default array
		$array = array( 'searchfrom', 'logo', 'social' );

		// Turn into array if string
		if ( $array && ! is_array( $array ) ) {
			$array = explode( ',', $array );
		}

		// Apply filters for easy modification
		$array = apply_filters( 'medium_header_elements_filter', $array );

		// Return array
		return $array;

	}

}

/**
 * Display navigation
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_display_navigation' ) ) {

	function acmthemes_display_navigation() {

		// Return true by default
		$return = true;

		// Apply filters and return
		return apply_filters( 'display_navigation', $return );

	}

}

/**
 * Returns correct menu classes
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_menu_classes' ) ) {

	function acmthemes_header_menu_classes( $return ) {

		// Header style
		$header_style = acmthemes_header_style();

		// Define classes array
		$classes = array();

		// Return wrapper classes
		if ( 'wrapper' == $return ) {

			// Add clearfix
			$classes[] = 'clr';

      if( ! defined( 'ACMBASE_VERSION' ) ) {
        $classes[] = 'menu-text-left';
      }

			// Set keys equal to vals
			$classes = array_combine( $classes, $classes );

			// Apply filters
			$classes = apply_filters( 'header_menu_wrap_classes', $classes );

		}

		// Inner Classes
		elseif ( 'inner' == $return ) {

			// Core
			$classes[] = 'navigation';
			$classes[] = 'main-navigation';
			$classes[] = 'clr';

			//if fullwidth navigation header
			if( $header_style == 'header-fullwidth-navi' ) {
				$classes[] = 'container';
			}

			// Set keys equal to vals
			$classes = array_combine( $classes, $classes );

			// Apply filters
			$classes = apply_filters( 'header_menu_classes', $classes );

		}

		// Return
		if ( is_array( $classes ) ) {
			return implode( ' ', $classes );
		} else {
			return $return;
		}

	}

}

/**
 * Returns custom menu
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_custom_menu' ) ) {

	function acmthemes_header_custom_menu() {

		$menu = '';
		return apply_filters( 'custom_menu', $menu );

	}

}

/**
 * Header logo classes
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_logo_classes' ) ) {

	function acmthemes_header_logo_classes() {

		// Header style
		$header_style = acmthemes_header_style();

		// Define classes array
		$classes = array( 'clr' );

		// Get custom full screen logo
		if ( 'full_screen' == acmthemes_header_style()
			&& acmthemes_header_full_screen_logo() ) {
			$classes[] = 'has-full-screen-logo';
		}

		// Apply filters for child theming
		$classes = apply_filters( 'header_logo_classes', $classes );

		// Turn classes into space seperated string
		$classes = implode( ' ', $classes );

		// Return classes
		return $classes;

	}

}

/**
 * Returns menu search style
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_menu_search_style' ) ) {

	function acmthemes_menu_search_style() {

		//search style
		$style = 'drop_down';

		// Apply filters for advanced edits
		$style = apply_filters( 'menu_search_style', $style );

		// Sanitize output so it's not empty and return
		$style = $style ? $style : 'drop_down';

		// Return style
		return $style;

	}

}

/**
 * Outputs the search for the top header style
 *
 * @since 1.6.0
 */
if ( ! function_exists( 'acmthemes_product_search_box' ) ) {

	function acmthemes_search_box($atts) {
		//get framework settings
		$settings = acmthemes_settings();
		
		$action_toggle_class = ( isset( $settings['header_search_style'] ) && 'search_replace' == $settings['header_search_style'] ) ?
			'acm-search-replace' : 'site-search-toggle';
			?>
			<div class="nav-menu-search">
				<a href="#" class="<?php echo esc_attr( $action_toggle_class ) ?>">
					<span class="icon-magnifier"></span>
				</a>
			</div>
		
		<?php 
	}
	add_shortcode( 'bookchoix_search_box', 'acmthemes_search_box' );

}

/**
 * Returns header search style
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_menu_cart_style' ) ) {

	function acmthemes_menu_cart_style() {

    //get framework settings
    $settings = acmthemes_settings();
    $show_woo_menu_icon_desktop = ( isset( $settings['show_woo_menu_icon_desktop'] ) ) ? $settings['show_woo_menu_icon_desktop'] : 1;

		// Return if WooCommerce isn't enabled or icon is disabled
		if ( ! ACMTHEMES_WOOCOMMERCE_ACTIVE || empty( $show_woo_menu_icon_desktop ) ) {
			return;
		}

		//Menu Icon Style
		$style = 'drop_down';

		// Return click style for these pages
		if ( is_cart()
			|| is_checkout() ) {
			$style = 'custom_link';
		}

		// Apply filters for advanced edits
		$style = apply_filters( 'menu_cart_style', $style );

		// Sanitize output so it's not empty
		if ( 'drop_down' == $style
			|| ! $style ) {
			$style = 'drop_down';
		}

		// Return style
		return $style;

	}

}

/**
 * Mobile menu style
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_mobile_menu_style' ) ) {

	function acmthemes_mobile_menu_style() {

		// Get style from customizer setting
		$style = 'sidebar';

		// Sanitize style to make sure it isn't empty
		$style = $style ? $style : 'sidebar';

		// Apply filters and return
		return apply_filters( 'mobile_menu_style', $style );

	}

}

/*-------------------------------------------------------------------------------*/
/* [ Page Header ]
/*-------------------------------------------------------------------------------*/

/**
 * Page header template
 * I make a function to be able to remove it for the Beaver Themer plugin
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_page_header_template' ) ) {

	function acmthemes_page_header_template() {

		get_template_part( 'partials/page-header' );

	}

	add_action( 'page_header', 'acmthemes_page_header_template' );

}

/**
 * Checks if the page header is enabled
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_has_page_header' ) ) {

	function acmthemes_has_page_header() {

		// Define vars
		$return = true;
		$style  = acmthemes_page_header_style();

		// Check if page header style is set to hidden
		if ( 'hidden' == $style || is_page_template( 'templates/landing.php' ) ) {
			$return = false;
		}

		// Apply filters and return
		return apply_filters( 'display_page_header', $return );

	}

}

/**
 * Checks if the page header heading is enabled
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_has_page_header_heading' ) ) {

	function acmthemes_has_page_header_heading() {

		// Define vars
		$return = true;

		// Apply filters and return
		return apply_filters( 'display_page_header_heading', $return );

	}

}

/**
 * Returns page header style
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_page_header_style' ) ) {

	function acmthemes_page_header_style() {

    //get framework settings
		$settings = acmthemes_settings();

		// Get default page header style
		$style = ( isset( $settings['page_header_style'] ) ) ? $settings['page_header_style'] : '';

		// Apply filters and return
		return apply_filters( 'page_header_style', $style );

	}

}

/**
 * Return the title
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_title' ) ) {

	function acmthemes_title() {

    //get framework settings
    $settings = acmthemes_settings();

		// Default title is null
		$title = NULL;

		// Get post ID
		$post_id = acmthemes_post_id();

		// Homepage - display blog description if not a static page
		if ( is_front_page() && ! is_singular( 'page' ) ) {

			if ( get_bloginfo( 'description' ) ) {
				$title = get_bloginfo( 'description' );
			} else {
				return esc_html__( 'Recent Posts', 'bookchoix' );
			}

		// Homepage posts page
		} elseif ( is_home() && ! is_singular( 'page' ) ) {

			$title = get_the_title( get_option( 'page_for_posts', true ) );

		}

		// Search needs to go before archives
		elseif ( is_search() ) {
			global $wp_query;
			$title = '<span id="search-results-count">'. $wp_query->found_posts .'</span> '. esc_html__( 'Search Results Found', 'bookchoix' );
		}

		// Archives
		elseif ( is_archive() ) {

			// Author
			if ( is_author() ) {
				$title = get_the_archive_title();
			}

			// Post Type archive title
			elseif ( is_post_type_archive() ) {
				$title = post_type_archive_title( '', false );
			}

			// Daily archive title
			elseif ( is_day() ) {
				$title = sprintf( esc_html__( 'Daily Archives: %s', 'bookchoix' ), get_the_date() );
			}

			// Monthly archive title
			elseif ( is_month() ) {
				$title = sprintf( esc_html__( 'Monthly Archives: %s', 'bookchoix' ), get_the_date( esc_html_x( 'F Y', 'Page title monthly archives date format', 'bookchoix' ) ) );
			}

			// Yearly archive title
			elseif ( is_year() ) {
				$title = sprintf( esc_html__( 'Yearly Archives: %s', 'bookchoix' ), get_the_date( esc_html_x( 'Y', 'Page title yearly archives date format', 'bookchoix' ) ) );
			}

			// Categories/Tags/Other
			else {

				// Get term title
				$title = single_term_title( '', false );

				// Fix for plugins that are archives but use pages
				if ( ! $title ) {
					global $post;
					$title = get_the_title( $post_id );
				}

			}

		} // End is archive check

		// 404 Page
		elseif ( is_404() ) {

			$title = esc_html__( '404: Page Not Found', 'bookchoix' );

		}

		// Fix for WooCommerce My Accounts pages
		elseif( function_exists('is_wc_endpoint_url') && is_wc_endpoint_url() ) {
			$endpoint       = WC()->query->get_current_endpoint();
			$endpoint_title = WC()->query->get_endpoint_title( $endpoint );
			$title          = $endpoint_title ? $endpoint_title : $title;
		}

		// Anything else with a post_id defined
		elseif ( $post_id ) {

			// Single Pages
			if ( is_singular( 'page' ) || is_singular( 'attachment' ) ) {
				$title = get_the_title( $post_id );
			}

			// Single blog posts
			elseif ( is_singular( 'post' ) ) {

				if ( isset ( $settings['blog_header_title'] ) && 'post-title' == $settings['blog_header_title'] ) {
					$title = get_the_title();
				} else {
					$title = esc_html__( 'Blog', 'bookchoix' );
				}

			}

			// Other posts
			else {

				$title = get_the_title( $post_id );

			}

		}

		// Last check if title is empty
		$title = $title ? $title : get_the_title();

		// Apply filters and return title
		return apply_filters( 'title', $title );

	}

}

/**
 * Returns page subheading
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_page_subheading' ) ) {

	function acmthemes_get_page_subheading() {

		// Subheading is NULL by default
		$subheading = NULL;

		// Search
		if ( is_search() ) {
			$subheading = esc_html__( 'You searched for:', 'bookchoix' ) .' &quot;'. esc_html( get_search_query( false ) ) .'&quot;';
		}

		// Author
		elseif ( is_author() ) {
			$subheading = esc_html__( 'This author has written', 'bookchoix' ) .' '. get_the_author_posts() .' '. esc_html__( 'articles', 'bookchoix' );
		}

		// Apply filters and return
		return apply_filters( 'post_subheading', $subheading );

	}

}

/**
 * Get taxonomy description
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_tax_description' ) ) {

	function acmthemes_get_tax_description() {

		// Subheading is NULL by default
		$desc = NULL;

		// All other Taxonomies
		if ( is_category() || is_tag() ) {
			$desc = term_description();
		}

		// Apply filters and return
		return apply_filters( 'tax_description', $desc );

	}

}

/**
 * Add taxonomy description
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_tax_description' ) ) {

	function acmthemes_tax_description() {

		if ( $desc = acmthemes_get_tax_description() ) : ?>

			<div class="clr tax-desc">
				<?php echo do_shortcode( $desc ); ?>
			</div>

		<?php endif;

	}

	add_action( 'before_content_inner', 'acmthemes_tax_description' );

}

/**
 * Display breadcrumbs
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_has_breadcrumbs' ) ) {

	function acmthemes_has_breadcrumbs() {

    //get framework settings
    $settings = acmthemes_settings();

		// Return true by default
		$return = true;

		// Return false if disabled
		if ( isset( $settings['show_header_breadcrumb'] ) && $settings['show_header_breadcrumb'] != 1 ) {
			$return = false;
		}

		// Apply filters and return
		return apply_filters( 'display_breadcrumbs', $return );

	}

}

/**
 * Outputs Custom CSS for the page title
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_page_header_overlay' ) ) {

	function acmthemes_page_header_overlay() {

		// Define return
		$return = '';

		// Only needed for the background-image style so return otherwise
		if ( 'background-image' != acmthemes_page_header_style() ) {
			return;
		}

		// Return overlay element
		$return = '<span class="background-image-page-header-overlay"></span>';

		// Apply filters for child theming
		$return = apply_filters( 'page_header_overlay', $return );

		// Return
		echo wp_kses_post( $return );
	}

}

/**
 * Returns search overlay
 *
 * @since  1.6.0
 */
if ( ! function_exists( 'acmthemes_search_overlay' ) ) {

	function acmthemes_search_overlay() {

		get_template_part( 'partials/header/search-overlay' );

	}
	add_action('above_wp_footer', 'acmthemes_search_overlay', 0);

}

/*-------------------------------------------------------------------------------*/
/* [ Blog ]
/*-------------------------------------------------------------------------------*/

/**
 * Adds post classes
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_wrap_classes' ) ) {

	function acmthemes_blog_wrap_classes( $classes = NULL ) {

		// Return custom class if set
		if ( $classes ) {
			return $classes;
		}

		// Admin defaults
		$style   = acmthemes_blog_entry_style();
		$classes = array( 'entries', 'clr' );

		// Isotope classes
		if ( $style == 'grid-entry' ) {
			$classes[] = 'acmthemes-row';
			if ( 'masonry' == acmthemes_blog_grid_style() ) {
				$classes[] = 'blog-masonry-grid';
			} else {
				if ( 'infinite_scroll' == acmthemes_blog_pagination_style() ) {
					$classes[] = 'blog-masonry-grid';
				} else {
					$classes[] = 'blog-grid';
				}
			}
		}

		// Infinite scroll class
		if ( 'infinite_scroll' == acmthemes_blog_pagination_style() ) {
			$classes[] = 'infinite-scroll-wrap';
		}

		// Add filter for child theming
		$classes = apply_filters( 'blog_wrap_classes', $classes );

		// Turn classes into space seperated string
		if ( is_array( $classes ) ) {
			$classes = implode( ' ', $classes );
		}

		// Echo classes
		echo esc_attr( $classes );

	}

}

/**
 * Adds entry classes
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_post_entry_classes' ) ) {

	function acmthemes_post_entry_classes() {

		// Define classes array
		$classes = array();

		// Entry Style
		$entry_style = acmthemes_blog_entry_style();

		// Core classes
		$classes[] = 'blog-entry';
		$classes[] = 'clr';

		// Masonry classes
		if ( 'masonry' == acmthemes_blog_grid_style() ) {
			$classes[] = 'isotope-entry';
		}

		// Add columns for grid style entries
		if ( $entry_style == 'grid-entry' ) {
			$classes[] = 'col';
				$classes[] = acmthemes_grid_class( acmthemes_blog_entry_columns() );

			// Counter
			global $acmthemes_count;
			if ( $acmthemes_count ) {
				$classes[] = 'col-'. $acmthemes_count;
			}
		}

		// No Featured Image Class, don't add if oembed or self hosted meta are defined
		if ( ! has_post_thumbnail()
			&& '' == get_post_meta( get_the_ID(), 'post_self_hosted_shortcode', true )
			&& '' == get_post_meta( get_the_ID(), 'post_oembed', true ) ) {
			$classes[] = 'no-featured-image';
		}

		// Infinite scroll class
		if ( 'infinite_scroll' == acmthemes_blog_pagination_style() ) {
			$classes[] = 'item-entry';
		}

		// Blog entry style
		$classes[] = $entry_style;

		// Apply filters to entry post class for child theming
		$classes = apply_filters( 'blog_entry_classes', $classes );

		// Rturn classes array
		return $classes;

	}

}

/**
 * Returns correct style for the blog entry based on the customizer
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_entry_style' ) ) {

	function acmthemes_blog_entry_style() {

		// Apply filters for child theming
		$style = apply_filters( 'blog_entry_style', 'large-entry' );

		// Return style
		return $style;

	}

}

/**
 * Returns correct images size
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_entry_images_size' ) ) {

	function acmthemes_blog_entry_images_size() {

		// Apply filters for child theming
		$size = apply_filters( 'blog_entry_images_size', 'medium' );

		// Return size
		return $size;

	}

}

/**
 * Returns correct columns for the blog entries
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_entry_columns' ) ) {

	function acmthemes_blog_entry_columns() {

		// Get columns
		$columns = '2';

		// Apply filters for child theming
		$columns = apply_filters( 'blog_entry_columns', $columns );

		// Return columns
		return $columns;

	}

}

/**
 * Check if the post has a gallery
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_post_has_gallery' ) ) {

	function acmthemes_post_has_gallery( $post_id = '' ) {

		$post_id = $post_id ? $post_id : get_the_ID();

		if ( get_post_meta( $post_id, 'gallery_id', true ) ) {
			return true;
		}

	}

}

/**
 * Retrieve attachment IDs
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_gallery_ids' ) ) {

	function acmthemes_get_gallery_ids( $post_id = '' ) {

		$post_id = $post_id ? $post_id : get_the_ID();
		$attachment_ids = get_post_meta( $post_id, 'gallery_id', true );

		if ( $attachment_ids ) {
			return $attachment_ids;
		}

	}

}

/**
 * Retrieve attachment data
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_attachment' ) ) {

	function acmthemes_get_attachment( $id ) {

		$attachment = get_post( $id );

		return array(
			'alt'         => get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true ),
			'caption'     => $attachment->post_excerpt,
			'description' => $attachment->post_content,
			'href'        => get_permalink( $attachment->ID ),
			'src'         => $attachment->guid,
			'title'       => $attachment->post_title,
		);

	}

}

/**
 * Return gallery count
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_gallery_count' ) ) {

	function acmthemes_gallery_count() {

		$ids = acmthemes_get_gallery_ids();
		return count( $ids );

	}

}

/**
 * Check if lightbox is enabled
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_gallery_is_lightbox_enabled' ) ) {

	function acmthemes_gallery_is_lightbox_enabled() {

		if ( 'on' == get_post_meta( get_the_ID(), 'gallery_link_images', true ) ) {
			return true;
		}

	}

}

/**
 * Returns post media
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_post_media' ) ) {

	function acmthemes_get_post_media( $post_id = '' ) {

		// Define video variable
		$video = '';

		// Get correct ID
		$post_id = $post_id ? $post_id : get_the_ID();

		// Embed
		if ( $meta = get_post_meta( $post_id, 'post_video_embed', true ) ) {
			$video = $meta;
		}

		// Check for self-hosted first
		elseif ( $meta = get_post_meta( $post_id, 'post_self_hosted_media', true ) ) {
			$video = $meta;
		}

		// Check for post oembed
		elseif ( $meta = get_post_meta( $post_id, 'post_oembed', true ) ) {
			$video = $meta;
		}

		// Apply filters for child theming
		$video = apply_filters( 'get_post_video', $video );

		// Return data
		return $video;

	}

}

/**
 * Returns post video HTML
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_post_video_html' ) ) {

	function acmthemes_get_post_video_html( $video = '' ) {

		// Get video
		$video = $video ? $video : acmthemes_get_post_media();

		// Return if video is empty
		if ( empty( $video ) ) {
			return;
		}

		// Check post format for standard post type
		if ( 'post' == get_post_type() && 'video' != get_post_format() ) {
			return;
		}

		// Get oembed code and return
		if ( ! is_wp_error( $oembed = wp_oembed_get( $video ) ) && $oembed ) {
			return '<div class="responsive-video-wrap">'. $oembed .'</div>';
		}

		// Display using apply_filters if it's self-hosted
		else {

			$video = apply_filters( 'the_content', $video );

			// Add responsive video wrap for youtube/vimeo embeds
			if ( strpos( $video, 'youtube' ) || strpos( $video, 'vimeo' ) ) {
				return '<div class="responsive-video-wrap">'. $video .'</div>';
			}

			// Else return without responsive wrap
			else {
				return $video;
			}

		}

	}

}

/**
 * Returns post audio
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_post_audio_html' ) ) {

	function acmthemes_get_post_audio_html( $audio = '' ) {

		// Get audio
		$audio = $audio ? $audio : acmthemes_get_post_media();

		// Return if audio is empty
		if ( empty( $audio ) ) {
			return;
		}

		// Check post format for standard post type
		if ( 'post' == get_post_type() && 'audio' != get_post_format() ) {
			return;
		}

		// Get oembed code and return
		if ( ! is_wp_error( $oembed = wp_oembed_get( $audio ) ) && $oembed ) {
			return '<div class="responsive-video-wrap">'. $oembed .'</div>';
		}

		// Display using apply_filters if it's self-hosted
		else {

			$audio = apply_filters( 'the_content', $audio );

			// Add responsive audio wrap for youtube/vimeo embeds
			if ( strpos( $audio, 'youtube' ) || strpos( $audio, 'vimeo' ) ) {
				return '<div class="responsive-video-wrap">'. $audio .'</div>';
			}

			// Else return without responsive wrap
			else {
				return $audio;
			}

		}

	}

}

/**
 * Returns blog entry meta
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_entry_meta' ) ) {

	function acmthemes_blog_entry_meta() {

		// Default sections
		$sections = array( 'author', 'date', 'categories', 'comments' );

		// Turn into array if string
		if ( $sections && ! is_array( $sections ) ) {
			$sections = explode( ',', $sections );
		}

		// Apply filters for easy modification
		$sections = apply_filters( 'blog_entry_meta', $sections );

		// Return sections
		return $sections;

	}

}

/**
 * Returns blog single elements for the customizer
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_single_elements' ) ) {

	function acmthemes_blog_single_elements() {

		// Default elements
		$elements = apply_filters( 'blog_single_elements', array(
			'featured_image'    => esc_html__( 'Featured Image', 'bookchoix' ),
			'title'       		=> esc_html__( 'Title', 'bookchoix' ),
			'meta' 				=> esc_html__( 'Meta', 'bookchoix' ),
			'content' 			=> esc_html__( 'Content', 'bookchoix' ),
			'tags' 				=> esc_html__( 'Tags', 'bookchoix' ),
			'social_share'   	=> esc_html__( 'Social Share', 'bookchoix' ),
			'next_prev'     	=> esc_html__( 'Next/Prev Links', 'bookchoix' ),
			'author_box'       	=> esc_html__( 'Author Box', 'bookchoix' ),
			'related_posts' 	=> esc_html__( 'Related Posts', 'bookchoix' ),
			'single_comments'   => esc_html__( 'Comments', 'bookchoix' ),
		) );

		// Return elements
		return $elements;

	}

}

/**
 * Returns blog single elements positioning
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_single_elements_positioning' ) ) {

	function acmthemes_blog_single_elements_positioning() {

		// Default sections
		$sections = array( 'featured_image', 'title', 'meta', 'content', 'tags', 'social_share', 'next_prev', 'author_box', 'related_posts', 'single_comments' );

		// Turn into array if string
		if ( $sections && ! is_array( $sections ) ) {
			$sections = explode( ',', $sections );
		}

		// Apply filters for easy modification
		$sections = apply_filters( 'blog_single_elements_positioning', $sections );

		// Return sections
		return $sections;

	}

}

/**
 * Returns blog single meta
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_single_meta' ) ) {

	function acmthemes_blog_single_meta() {

		// Default sections
		$sections = array( 'author', 'date', 'categories', 'comments' );

		// Turn into array if string
		if ( $sections && ! is_array( $sections ) ) {
			$sections = explode( ',', $sections );
		}

		// Apply filters for easy modification
		$sections = apply_filters( 'blog_single_meta', $sections );

		// Return sections
		return $sections;

	}

}

/**
 * Numbered Pagination
 *
 * @since	1.0.0
 * @link	https://codex.wordpress.org/Function_Reference/paginate_links
 */
if ( ! function_exists( 'acmthemes_pagination') ) {

	function acmthemes_pagination( $query = '', $echo = true ) {

		// Arrows with RTL support
		$prev_arrow = is_rtl() ? 'fa fa-angle-right' : 'fa fa-angle-left';
		$next_arrow = is_rtl() ? 'fa fa-angle-left' : 'fa fa-angle-right';

		// Get global $query
		if ( ! $query ) {
			global $wp_query;
			$query = $wp_query;
		}

		// Set vars
		$total  = $query->max_num_pages;
		$big    = 999999999;

		// Display pagination if total var is greater then 1 ( current query is paginated )
		if ( $total > 1 ) {

			// Get current page
			if ( $current_page = get_query_var( 'paged' ) ) {
				$current_page = $current_page;
			} elseif ( $current_page = get_query_var( 'page' ) ) {
				$current_page = $current_page;
			} else {
				$current_page = 1;
			}

			// Get permalink structure
			if ( get_option( 'permalink_structure' ) ) {
				if ( is_page() ) {
					$format = 'page/%#%/';
				} else {
					$format = '/%#%/';
				}
			} else {
				$format = '&paged=%#%';
			}

			$args = apply_filters( 'pagination_args', array(
				'base'      => str_replace( $big, '%#%', html_entity_decode( get_pagenum_link( $big ) ) ),
				'format'    => $format,
				'current'   => max( 1, $current_page ),
				'total'     => $total,
				'mid_size'  => 3,
				'type'      => 'list',
				'prev_text' => '<i class="'. $prev_arrow .'"></i>',
				'next_text' => '<i class="'. $next_arrow .'"></i>',
			) );

			// Output pagination
			if ( $echo ) {
				echo '<div class="acmthemes-pagination clr">'. wp_kses_post( paginate_links( $args ) ) .'</div>';
			} else {
				return '<div class="acmthemes-pagination clr">'. wp_kses_post( paginate_links( $args ) ) .'</div>';
			}
		}
	}

}

/**
 * Next and previous pagination
 *
 * @since	1.0.0
 */
if ( ! function_exists( 'acmthemes_pagejump' ) ) {

	function acmthemes_pagejump( $pages = '', $range = 4, $echo = true ) {

		// Vars
		global $wp_query;
		$output = '';

		// Display next/previous pagination
		if ( $wp_query->max_num_pages > 1 ) {

			$output .= '<div class="page-jump clr">';
				$output .= '<div class="alignleft newer-posts">';
					$output .= get_previous_posts_link( '&larr; '. esc_html__( 'Newer Posts', 'bookchoix' ) );
				$output .= '</div>';
				$output .= '<div class="alignright older-posts">';
					$output .= get_next_posts_link( esc_html__( 'Older Posts', 'bookchoix' ) .' &rarr;' );
				$output .= '</div>';
			$output .= '</div>';

			if ( $echo ) {
				echo wp_kses_post( $output );
			} else {
				return $output;
			}

		}

	}

}

/**
 * Infinite Scroll Pagination
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_infinite_scroll' ) ) {

	function acmthemes_infinite_scroll( $type = 'standard' ) {

		// Load infinite scroll script
		wp_enqueue_script( 'infinitescroll' );

		// Last text
		$last = esc_html__( 'End of content', 'bookchoix' );

		// Error text
		$error = esc_html__( 'No more pages to load', 'bookchoix' );

		// Output pagination HTML
		$output = '';
		$output .= '<div class="scroller-status">';
			$output .= '<div class="loader-ellips infinite-scroll-request">';
				$output .= '<span class="loader-ellips__dot"></span>';
				$output .= '<span class="loader-ellips__dot"></span>';
				$output .= '<span class="loader-ellips__dot"></span>';
				$output .= '<span class="loader-ellips__dot"></span>';
			$output .= '</div>';
			$output .= '<p class="scroller-status__message infinite-scroll-last">'. $last .'</p>';
			$output .= '<p class="scroller-status__message infinite-scroll-error">'. $error .'</p>';
		$output .= '</div>';
		$output .= '<div class="infinite-scroll-nav clr">';
			$output .= '<div class="alignleft newer-posts">'. get_previous_posts_link('&larr; '. esc_html__( 'Newer Posts', 'bookchoix' ) ) .'</div>';
			$output .= '<div class="alignright older-posts">'. get_next_posts_link( esc_html__( 'Older Posts', 'bookchoix' ) .' &rarr;') .'</div>';
		$output .= '</div>';

		echo wp_kses_post( $output );

	}

}

/**
 * Blog Pagination
 * Used to load the correct pagination function for blog archives
 * Execute the correct pagination function based on the theme settings
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_pagination' ) ) {

	function acmthemes_blog_pagination() {

		// Admin Options
		$blog_style       = 'large-entry';
		$pagination_style = 'standard';

		// Category based settings
		if ( is_category() ) {

			// Get taxonomy meta
			$term       = get_query_var( 'cat' );
			$term_data  = get_option( 'category_'. $term );
			$term_style = $term_pagination = '';

			if ( isset( $term_data['acmthemes_term_style'] ) ) {
				$term_style = '' != $term_data['acmthemes_term_style'] ? $term_data['acmthemes_term_style'] .'' : $term_style;
			}

			if ( isset( $term_data['acmthemes_term_pagination'] ) ) {
				$term_pagination = '' != $term_data['acmthemes_term_pagination'] ? $term_data['acmthemes_term_pagination'] .'' : '';
			}

			if ( $term_pagination ) {
				$pagination_style = $term_pagination;
			}

		}

		// Set default $type for infnite scroll
		if ( 'grid-entry' == $blog_style ) {
			$infinite_type = 'standard-grid';
		} else {
			$infinite_type = 'standard';
		}

		// Execute the correct pagination function
		if ( 'infinite_scroll' == $pagination_style ) {
			acmthemes_infinite_scroll( $infinite_type );
		} else if ( $pagination_style == 'next_prev' ) {
			acmthemes_pagejump();
		} else {
			acmthemes_pagination();
		}

	}

}

/**
 * Returns the correct pagination style
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_blog_pagination_style' ) ) {

	function acmthemes_blog_pagination_style() {

		// Apply filters for child theming
		$style = apply_filters( 'blog_pagination_style', 'standard' );

		// Return style
		return $style;
	}

}

/**
 * Get excerpt
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_excerpt' ) ) {

	function acmthemes_excerpt( $length = 30 ) {
		global $post;

		// Check for custom excerpt
		if ( has_excerpt( $post->ID ) ) {
			$output = $post->post_excerpt;
		}
		// if no custom excerpt
		else {

      $excerpt = apply_filters( 'the_excerpt', get_the_excerpt() );
      $output = wp_trim_words( strip_shortcodes( $excerpt ), $length );

		}

		return $output;

	}

}

/**
 * Get previous post link
 *
 * @since 1.0.0
 */
if( !function_exists('acmthemes_prev_post')) {

  function acmthemes_prev_post ($title = true) {
    $previous_post = get_previous_post();
    if (!empty( $previous_post )) {
      echo '<i class="fa fa-angle-left"></i> <a href="' . get_permalink( $previous_post->ID ) . '">';
      echo '<span class="post-link-text">' . esc_html__('Previous', 'bookchoix') . '</span>';
      if($title)
        echo '<span class="post-link">' . $previous_post->post_title . '</span>';
      echo '</a>';

    }
  }

}

/**
 * Get next post link
 *
 * @since 1.0.0
 */
if( !function_exists('acmthemes_next_post')) {

  function acmthemes_next_post ($title = true) {
    $next_post = get_next_post();
    if (!empty( $next_post )) {
      echo '<a href="' . get_permalink( $next_post->ID ) . '">';
      echo '<span class="post-link-text">' . esc_html__('Next', 'bookchoix') . '</span>';
      if($title)
        echo '<span class="post-link">'. $next_post->post_title . '</span>';
      echo '</a> <i class="fa fa-angle-right"></i>';
    }
  }

}

/**
 * Get list comments
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'bookchoix_list_blog_comments' ) ) {
    function bookchoix_list_blog_comments() {
        wp_list_comments( array(
					'style'       => 'ol',
					'type'				=> 'all',
					'short_ping'  => true,
					'avatar_size' => 100,
					'callback' 		=> 'bookchoix_blog_comment'
				) );
    }
}

/**
 * Get list comments
 *
 * @since 1.0.0
 */
function bookchoix_blog_comment($comment, $args, $depth) {
    if ( 'div' === $args['style'] ) {
        $tag       = 'div';
        $add_below = 'comment';
    } else {
        $tag       = 'li';
        $add_below = 'div-comment';
    }?>
    <<?php echo wp_kses_post( $tag ); ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?> id="comment-<?php comment_ID() ?>"><?php
    if ( 'div' != $args['style'] ) { ?>
        <div id="div-comment-<?php comment_ID() ?>" class="comment-body"><?php
    } ?>
        <div class="comment-author vcard"><?php
            if ( $args['avatar_size'] != 0 ) {
                echo get_avatar( $comment, $args['avatar_size'] );
            }
            printf( '<cite class="fn">%s</cite>', get_comment_author_link() ); ?>

						<div class="comment-meta commentmetadata">
		            <a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>"><?php
		                /* translators: 1: date, 2: time */
		                printf(
		                    '%1$s',
		                    get_comment_date()
		                ); ?>
		            </a><?php
		            edit_comment_link( esc_html__( '(Edit)', 'bookchoix' ), '  ', '' ); ?>
		        </div>

						<?php comment_text(); ?>

        </div>

        <div class="reply"><?php
                comment_reply_link(
                    array_merge(
                        $args,
                        array(
                            'add_below' => $add_below,
                            'depth'     => $depth,
                            'max_depth' => $args['max_depth']
                        )
                    )
                ); ?>
        </div>
        <?php
    if ( 'div' != $args['style'] ) : ?>
        </div>
        <?php
        if ( $comment->comment_approved == '0' ) { ?>
            <em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'bookchoix' ); ?></em><br/><?php
        } ?>
        <?php
    endif;
}

/**
 * Display scrool up button
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_display_scroll_up_button' ) ) {

	function acmthemes_display_scroll_up_button() {

    //get framework settings
		$settings = acmthemes_settings();

		// Return true by default
		$return = true;

		// Return false if disabled
		if ( isset( $settings['disable_scroll_top'] ) && true == $settings['disable_scroll_top'] ) {
			$return = false;
		}

		// Apply filters and return
		return apply_filters( 'display_scroll_up_button', $return );

	}

}

/**
 * Footer template
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_footer_template' ) ) {

	function acmthemes_footer_template() {
      get_template_part( 'partials/footer/layout' );
	}

	add_action( 'footer', 'acmthemes_footer_template' );

}

/**
 * Add classes to the footer wrap
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_footer_classes' ) ) {

	function acmthemes_footer_classes() {

		// Setup classes array
		$classes = array();

		// Default class
		$classes[] = 'footer';

		// Set keys equal to vals
		$classes = array_combine( $classes, $classes );

		// Apply filters for child theming
		$classes = apply_filters( 'footer_classes', $classes );

		// Turn classes into space seperated string
		$classes = implode( ' ', $classes );

		// return classes
		return $classes;

	}

}

/*-------------------------------------------------------------------------------*/
/* [ WooCommerce ]
/*-------------------------------------------------------------------------------*/

/**
 * Check if WooCommerce is activated
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_is_woocommerce_activated' ) ) {
	function acmthemes_is_woocommerce_activated() {
		if ( class_exists( 'woocommerce' ) ) { return true; } else { return false; }
	}
}

/**
 * Checks if on the WooCommerce shop page.
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_is_woo_shop' ) ) {

	function acmthemes_is_woo_shop() {
		if ( ! ACMTHEMES_WOOCOMMERCE_ACTIVE ) {
			return false;
		} elseif ( function_exists( 'is_shop' ) && is_shop() ) {
			return true;
		}
	}

}

/**
 * Checks if on a WooCommerce tax.
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_is_woo_tax' ) ) {

	function acmthemes_is_woo_tax() {
		if ( ! ACMTHEMES_WOOCOMMERCE_ACTIVE ) {
			return false;
		} elseif ( ! is_tax() ) {
			return false;
		} elseif ( function_exists( 'is_product_taxonomy' ) ) {
			if ( is_product_taxonomy() ) {
				return true;
			}
		}
	}

}

/**
 * Checks if on singular WooCommerce product post.
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_is_woo_single' ) ) {

	function acmthemes_is_woo_single() {
		if ( ! ACMTHEMES_WOOCOMMERCE_ACTIVE ) {
			return false;
		} elseif ( is_woocommerce() && is_product() ) {
			return true;
		}
	}

}

/**
 * Returns placeholder image.
 *
 * @since 1.0.0
 */
 function acmthemes_get_placeholder( $image = '' ) {
     if( !empty( $image ) ) {
         $output = "<img src='" . get_template_directory_uri() . "/assets/img/" . $image . "' alt='placeholder' />" ;
         return wp_kses_post( $output );
     }
 }

/*-------------------------------------------------------------------------------*/
/* [ Other ]
/*-------------------------------------------------------------------------------*/

/**
 * is full screen page
 * @since 1.0.0
 */
 if ( ! function_exists( 'acmthemes_is_fullscreen_page' ) ) {

 	function acmthemes_is_fullscreen_page() {

		$is_woo_active = acmthemes_is_woocommerce_activated();
		if ( $is_woo_active ) {
			if( is_cart() || is_checkout() || is_product() )
				return true;
		}
		else return false;

 	}

 }

/**
 * Theme Branding
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_theme_branding' ) ) {

	function acmthemes_theme_branding() {

		$return = esc_html__( 'bookchoix', 'bookchoix' );

		// Return and apply filters for child theming
		return apply_filters( 'theme_branding', $return );
	}

}

/**
 * Return padding/margin values for customizer
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_spacing_css' ) ) {

	function acmthemes_spacing_css( $top, $right, $bottom, $left ) {

		// Add px and 0 if no value
		$s_top 		= ( isset( $top ) && '' !== $top ) ? intval( $top ) . 'px ' : '0px ';
		$s_right	= ( isset( $right ) && '' !== $right ) ? intval( $right ) . 'px ' : '0px ';
		$s_bottom 	= ( isset( $bottom ) && '' !== $bottom ) ? intval( $bottom ) . 'px ' : '0px ';
		$s_left 	= ( isset( $left ) && '' !== $left ) ? intval( $left ) . 'px' : '0px';

		// Return one value if it is the same on every inputs
		if ( ( intval( $s_top ) === intval( $s_right ) )
			&& ( intval( $s_right ) === intval( $s_bottom ) )
			&& ( intval( $s_bottom ) === intval( $s_left ) ) ) {
			return $s_left;
		}

		// Return
		return $s_top . $s_right . $s_bottom . $s_left;
	}

}

/**
 * Returns array of Social Options
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_social_options' ) ) {

	function acmthemes_social_options() {
		return apply_filters( 'social_options', array(
			'twitter' => array(
				'label' => esc_html__( 'Twitter', 'bookchoix' ),
				'icon_class' => 'fab fa-twitter',
			),
			'facebook' => array(
				'label' => esc_html__( 'Facebook', 'bookchoix' ),
				'icon_class' => 'fab fa-facebook',
			),
			'googleplus' => array(
				'label' => esc_html__( 'Google Plus', 'bookchoix' ),
				'icon_class' => 'fab fa-google-plus',
			),
			'pinterest'  => array(
				'label' => esc_html__( 'Pinterest', 'bookchoix' ),
				'icon_class' => 'fab fa-pinterest-p',
			),
			'dribbble' => array(
				'label' => esc_html__( 'Dribbble', 'bookchoix' ),
				'icon_class' => 'fab fa-dribbble',
			),
			'vk' => array(
				'label' => esc_html__( 'VK', 'bookchoix' ),
				'icon_class' => 'fab fa-vk',
			),
			'instagram'  => array(
				'label' => esc_html__( 'Instagram', 'bookchoix' ),
				'icon_class' => 'fab fa-instagram',
			),
			'linkedin' => array(
				'label' => esc_html__( 'LinkedIn', 'bookchoix' ),
				'icon_class' => 'fab fa-linkedin',
			),
			'tumblr'  => array(
				'label' => esc_html__( 'Tumblr', 'bookchoix' ),
				'icon_class' => 'fab fa-tumblr',
			),
			'github'  => array(
				'label' => esc_html__( 'Github', 'bookchoix' ),
				'icon_class' => 'fab fa-github-alt',
			),
			'flickr'  => array(
				'label' => esc_html__( 'Flickr', 'bookchoix' ),
				'icon_class' => 'fab fa-flickr',
			),
			'skype' => array(
				'label' => esc_html__( 'Skype', 'bookchoix' ),
				'icon_class' => 'fab fa-skype',
			),
			'youtube' => array(
				'label' => esc_html__( 'Youtube', 'bookchoix' ),
				'icon_class' => 'fab fa-youtube',
			),
			'vimeo' => array(
				'label' => esc_html__( 'Vimeo', 'bookchoix' ),
				'icon_class' => 'fab fa-vimeo-square',
			),
			'vine' => array(
				'label' => esc_html__( 'Vine', 'bookchoix' ),
				'icon_class' => 'fab fa-vine',
			),
			'xing' => array(
				'label' => esc_html__( 'Xing', 'bookchoix' ),
				'icon_class' => 'fab fa-xing',
			),
			'yelp' => array(
				'label' => esc_html__( 'Yelp', 'bookchoix' ),
				'icon_class' => 'fab fa-yelp',
			),
			'tripadvisor' => array(
				'label' => esc_html__( 'Tripadvisor', 'bookchoix' ),
				'icon_class' => 'fab fa-tripadvisor',
			),
			'rss'  => array(
				'label' => esc_html__( 'RSS', 'bookchoix' ),
				'icon_class' => 'fab fa-rss',
			),
			'email' => array(
				'label' => esc_html__( 'Email', 'bookchoix' ),
				'icon_class' => 'fab fa-envelope',
			),
			'snapchat' => array(
				'label' => esc_html__( 'Snapchat', 'bookchoix' ),
				'icon_class' => 'fab fa-snapchat',
			),
			'tiktok' => array(
				'label' => esc_html__( 'Tiktok', 'bookchoix' ),
				'icon_class' => 'fab fa-tiktok',
			),
			'quora' => array(
				'label' => esc_html__( 'Quora', 'bookchoix' ),
				'icon_class' => 'fab fa-quora',
			),
			'reddit' => array(
				'label' => esc_html__( 'Reddit', 'bookchoix' ),
				'icon_class' => 'fab fa-reddit',
			),
			'spotify' => array(
				'label' => esc_html__( 'Spotify', 'bookchoix' ),
				'icon_class' => 'fab fa-spotify',
			),
		) );
	}

}

/**
 * Grid Columns
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_grid_columns' ) ) {

	function acmthemes_grid_columns() {
		return apply_filters( 'grid_columns', array(
			'1' => '1',
			'2' => '2',
			'3' => '3',
			'4' => '4',
			'5' => '5',
			'6' => '6',
			'7' => '7',
		) );
	}

}

/**
 * Minify CSS
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_minify_css' ) ) {

	function acmthemes_minify_css( $css = '' ) {

		// Return if no CSS
		if ( ! $css ) return;

		// Normalize whitespace
		$css = preg_replace( '/\s+/', ' ', $css );

		// Remove ; before }
		$css = preg_replace( '/;(?=\s*})/', '', $css );

		// Remove space after , : ; { } */ >
		$css = preg_replace( '/(,|:|;|\{|}|\*\/|>) /', '$1', $css );

		// Remove space before , ; { }
		$css = preg_replace( '/ (,|;|\{|})/', '$1', $css );

		// Strips leading 0 on decimal values (converts 0.5px into .5px)
		$css = preg_replace( '/(:| )0\.([0-9]+)(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}.${2}${3}', $css );

		// Strips units if value is 0 (converts 0px to 0)
		$css = preg_replace( '/(:| )(\.?)0(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}0', $css );

		// Trim
		$css = trim( $css );

		// Return minified CSS
		return $css;

	}

}

/**
 * clean and add unit px properly
 *
 * @since 1.0.1
 */
function acmthemes_clean_font_size( $size ) {
	$size = preg_replace('/[^0-9]/', '', $size);
  return $size . 'px';
}

/**
 * Array of Font Awesome Icons for the scroll up button
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_awesome_icons' ) ) {

	function acmthemes_get_awesome_icons( $return = 'up_arrows', $default = 'none' ) {

		// Add none to top of array
		$icons_array = array(
			'none' =>''
		);

		// Define return icons
		$return_icons = array();

		// Returns up arrows only
		if ( 'up_arrows' == $return ) {
			$return_icons = array('fa fa-chevron-up','fa fa-caret-up','fa fa-angle-up','fa fa-angle-double-up','fa fa-long-arrow-up','fa fa-arrow-circle-o-up','fa fa-arrow-up','fa fa-level-up','fa fa-toggle-up');
			$return_icons = array_combine($return_icons, $return_icons);
		}

		return apply_filters( 'get_awesome_icons', array_merge( $icons_array, $return_icons ) );

	}

}

/**
 * Array of Icons for the WooCommerce cart
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_cart_icons' ) ) {

	function acmthemes_get_cart_icons( $default = 'icon-handbag' ) {

		// Returns icons
		$return_icons = array('icon-basket','icon-handbag','fa fa-shopping-basket','fa fa-shopping-bag','fa fa-shopping-cart');
		$return_icons = array_combine( $return_icons, $return_icons );

		return apply_filters( 'get_cart_icons', array_merge( $return_icons ) );

	}

}

/**
 * Returns sidr menu source
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_sidr_menu_source' ) ) {

	function acmthemes_sidr_menu_source() {

		// Return if is not sidebar mobile style
		if ( 'sidebar' != acmthemes_mobile_menu_style() ) {
			return;
		}

		// Define array of items
		$items = array();

		// Add close button
		$items['sidrclose'] = '#sidr-close';

		// If has mobile menu
		if ( has_nav_menu( 'mobile_menu' ) ) {
			$items['mobile-nav'] = '#mobile-nav';
		}

		// Add main navigation
		else {

			// Navigation
			$items['nav'] = '#site-navigation';

			// Add top bar menu
			if ( has_nav_menu( 'topbar_menu' ) ) {
				$items['top-nav'] = '#top-bar-nav';
			}

		}

		// Apply filters for child theming
		$items = apply_filters( 'mobile_menu_source', $items );

		// Turn items into comma seperated list
		$items = implode( ', ', $items );

		// Return
		return $items;

	}

}

/**
 * Query Autoptimize activation - check required if using a page builder
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_is_autoptimize_activated' ) ) {

	function acmthemes_is_autoptimize_activated() {

		return class_exists( 'autoptimizeBase' ) ? true : false;

	}

}

/**
 * Returns header template content
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_template_content' ) ) {

	function acmthemes_header_template_content() {

		// Return false if custom header is not selected
		if ( 'custom' != acmthemes_header_style() ) {
			return false;
		}

		// Get the template ID
		$content = acmthemes_custom_header_template();

		// Get template content
		if ( ! empty( $content ) ) {

			$template = get_post( $content );

			if ( $template && ! is_wp_error( $template ) ) {
				$content = $template->post_content;
			}

		}

		// Apply filters and return content
		return apply_filters( 'header_template_content', $content );

	}

}

/**
 * Return correct schema markup
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_get_schema_markup' ) ) {

	function acmthemes_get_schema_markup( $location ) {

		// Default
		$schema = $itemprop = $itemtype = '';

		// HTML
		if ( 'html' == $location ) {
			$schema = 'itemscope itemtype="http://schema.org/WebPage"';
		}

		// Header
		elseif ( 'header' == $location ) {
			$schema = 'itemscope="itemscope" itemtype="http://schema.org/WPHeader"';
		}

		// Logo
		elseif ( 'logo' == $location ) {
			$schema = 'itemscope itemtype="http://schema.org/Brand"';
		}

		// Navigation
		elseif ( 'site_navigation' == $location ) {
			$schema = 'itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement"';
		}

		// Main
		elseif ( 'main' == $location ) {
			$itemtype = 'http://schema.org/WebPageElement';
			$itemprop = 'mainContentOfPage';
			if ( is_singular( 'post' ) ) {
				$itemprop = '';
				$itemtype = 'http://schema.org/Blog';
			}
		}

		// Sidebar
		elseif ( 'sidebar' == $location ) {
			$schema = 'itemscope="itemscope" itemtype="http://schema.org/WPSideBar"';
		}

		// Footer widgets
		elseif ( 'footer' == $location ) {
			$schema = 'itemscope="itemscope" itemtype="http://schema.org/WPFooter"';
		}

		// Headings
		elseif ( 'headline' == $location ) {
			$schema = 'itemprop="headline"';
		}

		// Posts
		elseif ( 'entry_content' == $location ) {
			$schema = 'itemprop="text"';
		}

		// Publish date
		elseif ( 'publish_date' == $location ) {
			$schema = 'itemprop="datePublished"';
		}

		// Author name
		elseif ( 'author_name' == $location ) {
			$schema = 'itemprop="name"';
		}

		// Author link
		elseif ( 'author_link' == $location ) {
			$schema = 'itemprop="author" itemscope="itemscope" itemtype="http://schema.org/Person"';
		}

		// Item
		elseif ( 'item' == $location ) {
			$schema = 'itemprop="item"';
		}

		// Url
		elseif ( 'url' == $location ) {
			$schema = 'itemprop="url"';
		}

		// Position
		elseif ( 'position' == $location ) {
			$schema = 'itemprop="position"';
		}

		// Image
		elseif ( 'image' == $location ) {
			$schema = 'itemprop="image"';
		}

		return ' ' . apply_filters( 'schema_markup', $schema );

	}

}

/**
 * Outputs correct schema markup
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_schema_markup' ) ) {

	function acmthemes_schema_markup( $location ) {

		echo acmthemes_get_schema_markup( $location );

	}

}

/**
 * Default color picker palettes
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_default_color_palettes' ) ) {

	function acmthemes_default_color_palettes() {

		$palettes = array(
			'#000000',
			'#ffffff',
			'#dd3333',
			'#dd9933',
			'#eeee22',
			'#81d742',
			'#1e73be',
			'#8224e3',
		);

		// Apply filters and return
		return apply_filters( 'default_color_palettes', $palettes );

	}

}


/**
 * get woocommerce excerpt with character limit
 *
 * @since 1.0.0
 */
function acmthemes_woo_product_excerpt(){

	$excerpt = get_the_excerpt();
	$excerpt = preg_replace(" ([.*?])",'',$excerpt);
	$excerpt = strip_shortcodes($excerpt);
	$excerpt = strip_tags($excerpt);
	$excerpt = substr($excerpt, 0, 100);
	$excerpt = substr($excerpt, 0, strripos($excerpt, " "));
	$excerpt = trim(preg_replace( '/s+/', ' ', $excerpt));

	return $excerpt;

}
