<?php
/**
 * Recommends plugins for use with the theme via the TGMA Script
 *
 * @package BookChoix WordPress theme
 */

function acmthemes_tgmpa_register() {

	// Get array of recommended plugins
	$plugins = array(
		array(
			'name'				=> 'Classic Editor',
			'slug'				=> 'classic-editor',
			'required'			=> true,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'Elementor',
			'slug'				=> 'elementor',
			'required'			=> true,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'WooCommerce',
			'slug'				=> 'woocommerce',
			'required'			=> true,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'               => 'BookChoix core',
			'slug'               => 'bookchoix-core',
			'source'             => 'https://hostacmee.space/plugins-dir/bookchoix/bookchoix-core.zip',
			'required'           => true,
			'force_activation'   => false,
			'force_deactivation' => false,
		),
		array(
			'name'               => 'Slider Revolution',
			'slug'               => 'revslider',
			'source'             => 'https://hostacmee.space/plugins-dir/bookchoix/revslider.zip',
			'required'           => true,
			'force_activation'   => false,
			'force_deactivation' => false,
		),
		array(
			'name'				=> 'Meta Box – WordPress Custom Fields Framework',
			'slug'				=> 'meta-box',
			'required'			=> true,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'Contact Form by WPForms – Drag & Drop Form Builder for WordPress',
			'slug'				=> 'wpforms-lite',
			'required'			=> true,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'Side Cart WooCommerce',
			'slug'				=> 'side-cart-woocommerce',
			'required'			=> true,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'Classic Widgets',
			'slug'				=> 'classic-widgets',
			'required'			=> true,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'YITH WooCommerce Wishlist',
			'slug'				=> 'yith-woocommerce-wishlist',
			'required'			=> false,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'MC4WP: Mailchimp for WordPress',
			'slug'				=> 'mailchimp-for-wp',
			'required'			=> false,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'Wonder PDF Embed',
			'slug'				=> 'wonderplugin-pdf-embed',
			'required'			=> false,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'Variation Swatches for WooCommerce',
			'slug'				=> 'woo-variation-swatches',
			'required'			=> false,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'WPC Smart Compare for WooCommerce',
			'slug'				=> 'woo-smart-compare',
			'required'			=> false,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),
		array(
			'name'				=> 'WPC Smart Notification for WooCommerce',
			'slug'				=> 'wpc-smart-notification',
			'required'			=> false,
			'force_activation'   => false,
			'force_deactivation'	=> false,
		),

	);

	// Register notice
	tgmpa( $plugins, array(
		'id'           => 'acmthemes_theme',
		'domain'       => 'bookchoix',
		'menu'         => 'install-required-plugins',
		'has_notices'  => true,
		'is_automatic' => true,
		'dismissable'  => true,
	) );

}
add_action( 'tgmpa_register', 'acmthemes_tgmpa_register' );
