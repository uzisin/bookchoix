<?php
/*
 * BookChoix Theme configurations
 * @author    AcmeeDesign
 * @link      https://acmeedesign.com
 * @since     1.0
 */

function bookchoix_label_to_slug( $label ) {
  if( !empty( $label ) ) {
    $label = preg_replace("/[\s-]/", "_", $label);
    $label = preg_replace('/[^a-zA-Z0-9_]/', '', $label);
    return strtolower( $label );
  }
}

function bookchoix_saved_custom_fields() {
  return get_option ('bookchoix_book_fields');
}

add_action( 'init', 'acm_register_post_type' );
function acm_register_post_type() {
	$args = [
		'label'  => esc_html__( 'BookChoix Headers', 'acmthemes' ),
		'labels' => [
			'menu_name'          => esc_html__( 'BookChoix Headers', 'acmthemes' ),
			'name_admin_bar'     => esc_html__( 'BookChoix Header', 'acmthemes' ),
			'add_new'            => esc_html__( 'Add BookChoix Header', 'acmthemes' ),
			'add_new_item'       => esc_html__( 'Add new BookChoix Header', 'acmthemes' ),
			'new_item'           => esc_html__( 'New BookChoix Header', 'acmthemes' ),
			'edit_item'          => esc_html__( 'Edit BookChoix Header', 'acmthemes' ),
			'view_item'          => esc_html__( 'View BookChoix Header', 'acmthemes' ),
			'update_item'        => esc_html__( 'View BookChoix Header', 'acmthemes' ),
			'all_items'          => esc_html__( 'All BookChoix Headers', 'acmthemes' ),
			'search_items'       => esc_html__( 'Search BookChoix Headers', 'acmthemes' ),
			'parent_item_colon'  => esc_html__( 'Parent BookChoix Header', 'acmthemes' ),
			'not_found'          => esc_html__( 'No BookChoix Headers found', 'acmthemes' ),
			'not_found_in_trash' => esc_html__( 'No BookChoix Headers found in Trash', 'acmthemes' ),
			'name'               => esc_html__( 'BookChoix Headers', 'acmthemes' ),
			'singular_name'      => esc_html__( 'BookChoix Header', 'acmthemes' ),
		],
		'public'              => true,
		'exclude_from_search' => true,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'capability_type'     => 'post',
		'hierarchical'        => false,
		'has_archive'         => true,
		'query_var'           => true,
		'can_export'          => true,
		'rewrite_no_front'    => false,
		'show_in_menu'        => false,
		'supports' => [
			'title',
			'editor',
			'revisions',
			'page-attributes',
		],
		
		'rewrite' => true
	];

	register_post_type( 'bookchoix-header', $args );
}

/**
 * Meta boxes for Authors taxonamy
 *
 */
add_filter( 'rwmb_meta_boxes', 'bookchoix_authors_meta_boxes' );
function bookchoix_authors_meta_boxes( $meta_boxes ){
    $meta_boxes[] = array(
        'title'      => esc_html__('AUTHOR FIELDS', 'bookchoix'),
        'taxonomies' => 'authors',

        'fields' => array(
						array(
								'name' => esc_html__('Author Profile Picture', 'bookchoix'),
								'id'   => 'author_picture',
								'type' => 'image_advanced',
						),
            array(
                'name' => esc_html__('Author Biography', 'bookchoix'),
                'id'   => 'bks_author_bio',
                'type' => 'wysiwyg',
            ),
            array(
								'name' => esc_html__('Twitter Profile', 'bookchoix'),
								'id'   => 'author_twitter_link',
								'type' => 'text',
						),
            array(
								'name' => esc_html__('Facebook Profile', 'bookchoix'),
								'id'   => 'author_facebook_link',
								'type' => 'text',
						),
            array(
								'name' => esc_html__('Instagram Profile', 'bookchoix'),
								'id'   => 'author_instagram_link',
								'type' => 'text',
						),
            array(
								'name' => esc_html__('LinkedIn Profile', 'bookchoix'),
								'id'   => 'author_linkedin_link',
								'type' => 'text',
						),
            array(
								'name' => esc_html__('Pinterest Profile', 'bookchoix'),
								'id'   => 'author_pinterest_link',
								'type' => 'text',
						),
            array(
								'name' => esc_html__('Youtube Profile', 'bookchoix'),
								'id'   => 'author_youtube_link',
								'type' => 'text',
						),
            array(
								'name' => esc_html__('Tumbler Profile', 'bookchoix'),
								'id'   => 'author_tumbler_link',
								'type' => 'text',
						),
            array(
								'name' => esc_html__('Spotify Profile', 'bookchoix'),
								'id'   => 'author_spotify_link',
								'type' => 'text',
						),
        ),
    );
    return $meta_boxes;
}

/**
 * Meta boxes for Publishers taxonamy
 *
 */
if( function_exists( 'rwmb_meta' ) ) {

  add_filter( 'rwmb_meta_boxes', 'bookchoix_publisher_tax_meta_boxes' );
  function bookchoix_publisher_tax_meta_boxes( $meta_boxes ){
      $meta_boxes[] = array(
          'title'      => esc_html__('PUBLISHER FIELDS', 'bookchoix'),
          'taxonomies' => 'publishers',

          'fields' => array(
  						array(
  								'name' => esc_html__('Publisher Profile Picture', 'bookchoix'),
  								'id'   => 'publisher_picture',
  								'type' => 'image_advanced',
  						),
              array(
                  'name' => esc_html__('Publisher Biography', 'bookchoix'),
                  'id'   => 'bks_publisher_bio',
                  'type' => 'wysiwyg',
              ),
              array(
  								'name' => esc_html__('Twitter Profile', 'bookchoix'),
  								'id'   => 'publisher_twitter_link',
  								'type' => 'text',
  						),
              array(
  								'name' => esc_html__('Facebook Profile', 'bookchoix'),
  								'id'   => 'publisher_facebook_link',
  								'type' => 'text',
  						),
              array(
  								'name' => esc_html__('Instagram Profile', 'bookchoix'),
  								'id'   => 'publisher_instagram_link',
  								'type' => 'text',
  						),
              array(
  								'name' => esc_html__('LinkedIn Profile', 'bookchoix'),
  								'id'   => 'publisher_linkedin_link',
  								'type' => 'text',
  						),
              array(
  								'name' => esc_html__('Pinterest Profile', 'bookchoix'),
  								'id'   => 'publisher_pinterest_link',
  								'type' => 'text',
  						),
              array(
  								'name' => esc_html__('Youtube Profile', 'bookchoix'),
  								'id'   => 'publisher_youtube_link',
  								'type' => 'text',
  						),
              array(
  								'name' => esc_html__('Tumbler Profile', 'bookchoix'),
  								'id'   => 'publisher_tumbler_link',
  								'type' => 'text',
  						),
              array(
  								'name' => esc_html__('Spotify Profile', 'bookchoix'),
  								'id'   => 'publisher_spotify_link',
  								'type' => 'text',
  						),
          ),
      );
      return $meta_boxes;
  }

}

/**
 * Hooks With WPMetabox / Metbaox.io and registers a new metabox
 *
 * @param $meta_boxes
 *
 * @return array
 */
function bookchoix_product_extra_fields( $meta_boxes ) {
	$meta_boxes[] = array(
		'title'       => esc_html__('Book data', 'bookchoix'),
		'id'          => 'bkc-product-extra-fields',
		'post_types'  => array( 'product' ),
		'context'     => 'after_editor',
		'priority'    => 'high',
		'tabs'        => bookchoix_extra_product_tabs(),
		'tab_style'   => 'left',
		'tab_wrapper' => true,
		'fields'      => bookchoix_book_fields_data(),
	);
	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'bookchoix_product_extra_fields' );

/**
 * Populates Custom Tabs
 *
 * @return array
 */
function bookchoix_extra_product_tabs() {
	// Custom Hook To Provide Option To Add Custom Tabs
	return apply_filters( 'woo_product_extra_tabs', array(
		'bkc_product_fields' => array(
			'label' => 'Book Details',
			'icon' => 'dashicons-admin-site',
		),
    'bkc_product_information' => array(
			'label' => 'Product information',
			'icon' => 'dashicons-admin-site',
		),
	) );
}

/**
* Populates Custom Fields
*
* @return array
*/
function bookchoix_book_fields_data() {

  //get framework settings
  $settings = acmthemes_settings();

	// Custom Hook To Provide Option To Add Custom Fields.
  $bookchoix_book_fields = bookchoix_saved_custom_fields();

  $field_data = array();

  if ( !empty( $bookchoix_book_fields ) && is_array( $bookchoix_book_fields ) && count ( $bookchoix_book_fields ) > 0 ) {

    $field_data = array();

    if( isset( $settings['enable_publish_date_field'] ) && 1 == $settings['enable_publish_date_field'] ) {
      //publication date
      $field_data[] = array (
        'name'        => esc_html__( 'Publication date',  'bookchoix' ),
        'id' => 'bks_publish_date',
        'type' => 'date',
        'js_options' => [
            'dateFormat'      => 'yy-mm-dd',
            'showButtonPanel' => true,
        ],
        'timestamp'   => true,
        'tab' => 'bkc_product_fields',
      );

    }

    foreach ( $bookchoix_book_fields['book_custom_fields'] as $key => $label ) {

      $field_meta = 'bks_' . bookchoix_label_to_slug( $label );

      $field_data[] = array (
        'name'        => $label,
  			'id' => $field_meta,
        'type' => 'text',
  			'tab' => 'bkc_product_fields',
  		);

    }

    $field_data[] = array (
      'name'        => esc_html__( 'Extra information 1',  'bookchoix' ),
      'id' => 'bks_single_product_info_1',
      'type' => 'wysiwyg',
      'options' => [
        'textarea_rows' => 4,
       ],
      'tab' => 'bkc_product_information',
    );

    $field_data[] = array (
      'name'        => esc_html__( 'Extra information 2',  'bookchoix' ),
      'id' => 'bks_single_product_info_2',
      'type' => 'wysiwyg',
      'options' => [
        'textarea_rows' => 4,
       ],
      'tab' => 'bkc_product_information',
    );


  }

  return apply_filters( 'woo_product_custom_fields', $field_data );

}

/**
 * Book specifications fields builder
 * @since 1.0
*/
add_filter( 'mb_settings_pages', function ( $settings_pages ) {

    $settings_pages[] = array(
        'id'          => 'bookchoix-book-fields',
        'option_name' => 'bookchoix_book_fields',
        'menu_title'  => esc_html__( 'Book details', 'bookchoix' ),
        'icon_url'    => 'dashicons-edit',
        'style'       => 'no-boxes',
        'columns'     => 1,
        'parent'      => 'edit.php?post_type=product',
    );

    return $settings_pages;

} );

//Register meta boxes and fields for settings page
add_filter( 'rwmb_meta_boxes', 'bookchoix_book_custom_fields' );
function bookchoix_book_custom_fields ( $meta_boxes ) {
    $meta_boxes[] = array(
        'id'             => 'bookchoix-custom-fields',
        'title'          => esc_html__( 'Book specification details', 'bookchoix' ),
        'settings_pages' => 'bookchoix-book-fields',
        'customizer'  => false,
        'fields' => array(
          array (
      			'id' => 'book_custom_fields',
      			'type' => 'text',
            'name'        => esc_html__( 'Add field', 'bookchoix' ),
            'label_description' => 'Label description',
      			'desc' => esc_html__( 'To add your own specification, just type in the label by not selecting the select option.', 'bookchoix' ),
            'clone' => true,
            'placeholder' => esc_html__( 'Enter field label', 'bookchoix' ),
            'size'        => 30,
            'datalist'    => array(
                'id'      => 'book_default_fields',
                // List of predefined options
                'options' => array(
                    esc_html__( 'ISBN 10', 'bookchoix' ),
                    esc_html__( 'ISBN 13', 'bookchoix' ),
                    esc_html__( 'Release date', 'bookchoix' ),
                    esc_html__( 'Number of pages', 'bookchoix' ),
                    esc_html__( 'Edition', 'bookchoix' ),
                    esc_html__( 'Format', 'bookchoix' ),
                    esc_html__( 'Language', 'bookchoix' ),
                    esc_html__( 'Book Publisher', 'bookchoix' ),
                ),
            ),
      		),
        ),
    );

    return $meta_boxes;

}

/**
 * Product details wrapper and get values of the fields
 *
 * @return html markup
 */
function bookchoix_product_details_wrapper( $field, $custom_field = false ) {
	//return if no function declared
	if( !function_exists( 'rwmb_meta' ) )
		return;

  $field_meta_key = 'bks_' . bookchoix_label_to_slug( $field );
  if( $custom_field === false )
	 $field_data = rwmb_meta( $field_meta_key );
  else
    $field_data = $field;

	if( !empty( $field_data ) ) {

		$output = '<div class="detail-wrap">';
		$output .= '<div class="detail-label">';
		$output .= $field;
		$output .= '</div>';

		$output .= '<div class="detail-content">';
		$output .= $field_data;
		$output .= '</div>';
		$output .= '</div>';
    return $output;
	}
	else return NULL;

}

function bookchoix_book_data() {

  $book_data = array();

  //get custom fields
  $custom_fields = bookchoix_saved_custom_fields();
  if( !empty( $custom_fields['book_custom_fields'] ) && is_array( $custom_fields['book_custom_fields'] ) ) {
    foreach ( $custom_fields['book_custom_fields'] as $field ) {
      $field_data = bookchoix_product_details_wrapper($field, false);
      if(!empty($field_data)) {
        $book_data[] = $field_data;
      }
    }
  }

  return $book_data;

}

/**
 * Hooks With WPMetabox and registers a new metabox
 *
 * @param $meta_boxes
 *
 * @return array
 */
if( ! function_exists( 'bookchoix_page_settings' ) ) {

  function bookchoix_page_settings( $meta_boxes ) {
  	$meta_boxes[] = array(
  		'title'       => esc_html__( 'BookChoix page settings', 'bookchoix' ),
  		'id'          => 'bkc-page-settings',
  		'post_types'  => array( 'page' ),
  		'context'     => 'after_editor',
  		'priority'    => 'low',
  		'tabs'        => array(
          'header' => array(
              'label' => 'Header',
              'icon'  => 'dashicons-table-row-after', // Dashicon
          ),
          'footer'  => array(
              'label' => 'Footer',
              'icon'  => 'dashicons-table-row-before', // Dashicon
          ),
       ),
  		'tab_style'   => 'default',
  		'tab_wrapper' => true,
  		'fields'      => array(
          array(
              'name' => esc_html__( 'Header syle', 'bookchoix' ),
              'id'   => 'indv_page_header_style',
              'type'            => 'select',
              'options'         => array(
                  ''       => esc_html__( 'Default to Theme options', 'bookchoix' ),
                  'header-default' => esc_html__( 'Default Header', 'bookchoix' ),
                  'header-transparent' => esc_html__( 'Transparent Header', 'bookchoix' ),
                  'header-fullwidth-navi' => esc_html__( 'Full Width Navigation', 'bookchoix' ),
              ),
              'tab'  => 'header',
          ),
          array(
              'name' => esc_html__( 'Show page header', 'bookchoix' ),
              'id'   => 'show_page_header',
              'type'            => 'select',
              'options'         => array(
                  'default'       => esc_html__( 'Default to Theme options', 'bookchoix' ),
                  'show' => esc_html__( 'Show', 'bookchoix' ),
                  'hide' => esc_html__( 'Hide', 'bookchoix' ),
              ),
              'tab'  => 'header',
          ),
          array(
              'name' => esc_html__( 'Enable custom footer colors', 'bookchoix' ),
              'id'   => 'indv_page_footer_colors',
              'type' => 'checkbox',
              'std'  => 0,
              'tab'  => 'footer',
          ),
  				array(
  				    'name'          => 'Footer top background',
  				    'id'            => 'page_footer_top_bg',
  				    'type'          => 'color',
  				    'alpha_channel' => true,
  				    // Color picker options. See here: https://automattic.github.io/Iris/.
  				    'js_options'    => array(
  				       'palettes' => array( '#293132', '#474044', '#4F5165', '#DFF8EB', '#7692FF', '#EFE9E7' )
  				    ),
              'std' => '#121823',
  						'tab'  => 'footer',
  				),
  				array(
  				    'name'          => 'Footer top heading color',
  				    'id'            => 'page_footer_top_heading_color',
  				    'type'          => 'color',
  				    'alpha_channel' => true,
  				    'js_options'    => array(
  				       'palettes' => array( '#ffffff', '#00A5E0', '#262626', '#CA3CFF', '#FF6B6B', '#58355E' )
  				    ),
              'std' => '#ffffff',
  						'tab'  => 'footer',
  				),
  				array(
  				    'name'          => 'Footer top text color',
  				    'id'            => 'page_footer_top_text_color',
  				    'type'          => 'color',
  				    'alpha_channel' => true,
  				    'js_options'    => array(
  				       'palettes' => array( '#ffffff', '#00A5E0', '#262626', '#CA3CFF', '#FF6B6B', '#58355E' )
  				    ),
              'std' => '#cbcfd6',
  						'tab'  => 'footer',
  				),
  				array(
  				    'name'          => 'Footer top link color',
  				    'id'            => 'page_footer_top_link_color',
  				    'type'          => 'color',
  				    'alpha_channel' => true,
  				    'js_options'    => array(
  				       'palettes' => array( '#ffffff', '#00A5E0', '#262626', '#CA3CFF', '#FF6B6B', '#58355E' )
  				    ),
              'std' => '#cbcfd6',
  						'tab'  => 'footer',
  				),
  				array(
  				    'name'          => 'Footer bottom background',
  				    'id'            => 'page_footer_btm_bg',
  				    'type'          => 'color',
  				    'alpha_channel' => true,
  				    'js_options'    => array(
  				       'palettes' => array( '#3C1642', '#0A0908', '#4F5165', '#DFF8EB', '#7692FF', '#EFE9E7' )
  				    ),
  						'tab'  => 'footer',
  				),
  				array(
  				    'name'          => 'Footer bottom text color',
  				    'id'            => 'page_footer_btm_text_color',
  				    'type'          => 'color',
  				    'alpha_channel' => true,
  				    'js_options'    => array(
  				       'palettes' => array( '#ffffff', '#00A5E0', '#262626', '#CA3CFF', '#FF6B6B', '#58355E' )
  				    ),
              'std' => '#1d2530',
  						'tab'  => 'footer',
  				),
  				array(
  				    'name'          => 'Footer bottom link color',
  				    'id'            => 'page_footer_btm_link_color',
  				    'type'          => 'color',
  				    'alpha_channel' => true,
  				    'js_options'    => array(
  				       'palettes' => array( '#ffffff', '#00A5E0', '#262626', '#CA3CFF', '#FF6B6B', '#58355E' )
  				    ),
              'std' => '#ffffff',
  						'tab'  => 'footer',
  				),
      ),
  	);

  	return $meta_boxes;

  }
  add_filter( 'rwmb_meta_boxes', 'bookchoix_page_settings' );

}

/**
 * Hooks With WPMetabox and registers a new metabox
 *
 * @param $meta_boxes
 *
 * @return array
 */
if ( ! function_exists( 'bookchoix_post_settings' ) ) {

  function bookchoix_post_settings( $meta_boxes ) {
  	$meta_boxes[] = array(
  		'title'       => esc_html__( 'BookChoix post settings', 'bookchoix' ),
  		'id'          => 'bkc-post-settings',
  		'post_types'  => array( 'post' ),
  		'context'     => 'after_editor',
  		'priority'    => 'low',
  		'tabs'        => array(
          'layout' => array(
              'label' => 'Layout',
              'icon'  => 'dashicons-table-row-after', // Dashicon
          ),
       ),
  		'tab_style'   => 'default',
  		'tab_wrapper' => true,
  		'fields'      => array(
          array(
              'name' => esc_html__( 'Post layout', 'bookchoix' ),
              'id'   => 'this_post_layout',
              'type'            => 'select',
              'options'         => array(
                ''       => esc_html__( 'Default to theme options', 'bookchoix' ),
                'fullwidth'       => esc_html__( 'Full width', 'bookchoix' ),
                'left' => esc_html__( 'Left sidebar', 'bookchoix' ),
                'right' => esc_html__( 'Right sidebar', 'bookchoix' ),
              ),
              'tab'  => 'layout',
          ),
          array(
              'name' => esc_html__( 'Text content side padding (Desktop and Tab Landscape)', 'bookchoix' ),
              'id'   => 'post_content_padding',
              'type' => 'slider',
              'prefix' => '',
              'suffix' => ' px',
              'js_options' => array(
                  'min'   => 0,
                  'max'   => 250,
                  'step'  => 5,
              ),
              'std' => 0,
              'tab'  => 'layout',
          ),
          array(
              'name' => esc_html__( 'Content side padding (Tab Portrait)', 'bookchoix' ),
              'id'   => 'post_content_padding_tab',
              'type' => 'slider',
              'prefix' => '',
              'suffix' => ' px',
              'js_options' => array(
                  'min'   => 0,
                  'max'   => 250,
                  'step'  => 5,
              ),
              'std' => 0,
              'tab'  => 'layout',
          ),
      ),
  	);

  	return $meta_boxes;

  }
  add_filter( 'rwmb_meta_boxes', 'bookchoix_post_settings' );

}

/**
 * Populates Custom Tabs
 *
 * @return array
 */
function bookchoix_page_settings_tabs() {
	// Custom Hook To Provide Option To Add Custom Tabs
	return apply_filters( 'woo_product_extra_tabs', array(
		'bkc_product_fields' => array(
			'label' => esc_html__('Book Details', 'bookchoix'),
			'icon' => 'dashicons-admin-site',
		),
	) );
}

/**
* Populates Custom Fields
*
* @return array
*/
function bookchoix_page_settings_fields() {
	// Custom Hook To Provide Option To Add Custom Fields.

  $bookchoix_book_fields = bookchoix_saved_custom_fields();

  if ( !empty( $bookchoix_book_fields ) && is_array( $bookchoix_book_fields ) ) {

    $field_data = array();

    foreach ($bookchoix_book_fields['book_custom_fields'] as $key => $label) {

      $field_meta = 'bks_' . bookchoix_label_to_slug($label);

      $field_data[] = array (
        'name'        => $label,
  			'id' => $field_meta,
        'type' => 'text',
  			'tab' => 'bkc_product_fields',
  		);

    }

    return apply_filters( 'woo_product_extra_fields', $field_data );

  }

}


//change wcwl buttons to custom location
function bookchoix_yith_single_positions() {

	$wishlist_position = get_option( 'yith_wcwl_button_position' );
	if(!empty($wishlist_position) && 'shortcode' != $wishlist_position)
		update_option('yith_wcwl_button_position', 'shortcode');

	$compare_position = get_option( 'yith_woocompare_compare_button_in_product_page' );
	if(empty($compare_position) || 0 == $compare_position)
		update_option('yith_woocompare_compare_button_in_product_page', '0');
}
add_action('after_setup_theme', 'bookchoix_yith_single_positions');

/**
 * Show YITH buttons before gallery images
 */
 function bookchoix_show_yith_buttons_singlepage() {
	 global $product;

	 echo '<div class="yith-buttons">';
	 /*
	 ** show yith compare button
	 */
	 if( shortcode_exists( 'yith_compare_button' ) ) {
		 echo '<div class="yith_compare_btn">';
		 echo '<span class="info-balloon">'. esc_html__('Compare', 'bookchoix') . '</span>';
		 echo '<a href="'. get_site_url() .'?action=yith-woocompare-add-product&id='. $product->get_id() .'"
		 class="compare" data-product_id="'. $product->get_id() .'" rel="nofollow"></a>';
		 echo '</div>';
	 }
	 ?>

	 <?php
	 /*
	 ** show yith wishlist button
	 */
	 if(shortcode_exists( 'yith_wcwl_add_to_wishlist' ) ) {
		 echo '<div class="yith-wish-list">';
		 echo '<span class="info-balloon">'. esc_html__('Add to Wishlist', 'bookchoix') . '</span>';
		 echo do_shortcode('[yith_wcwl_add_to_wishlist]');
		 echo '</div>';
		}

		echo '</div>';
 }
 add_action('woocommerce_before_single_product_summary', 'bookchoix_show_yith_buttons_singlepage', 5);

 add_filter( 'acmthemes_breadcrumb_separator', 'bookchoix_breadcrumb_separator' );
 function bookchoix_breadcrumb_separator() {
	 return '';
 }


 /**
  * add author link to book product
  * @since 1.0.0
  */
 function bookchoix_add_authors_link() {

    global $post;
    $settings = acmthemes_settings();

      if ( defined( 'ACMBASE_VERSION' ) && 'product' === get_post_type() ) {
				$authors = get_the_term_list( $post->ID, 'authors', '', ', ', '' );
        if( isset( $settings['show_author_link_single_product'] ) && $settings['show_author_link_single_product'] == 1 && !empty( $authors ) ) {
					echo '<div class="authors-list">' . esc_html__('By', 'bookchoix') . ' ' . $authors . '</div>';
        }
        else {
          return false;
        }
      }
      else {
        return false;
      }

}

/**
 * add publisher link to book product
 * @since 1.3
 */
function bookchoix_add_publisher_link() {

   global $post;
   $settings = acmthemes_settings();

     if ( defined( 'ACMBASE_VERSION' ) && 'product' === get_post_type() ) {
       $publishers = get_the_term_list( $post->ID, 'publishers', '', ', ', '' );
       if( isset( $settings['show_publisher_link_single_product'] ) && $settings['show_publisher_link_single_product'] == 1 && !empty( $publishers ) ) {
         echo '<div class="authors-list">' . esc_html__('Publisher:', 'bookchoix') . ' ' . $publishers . '</div>';
       }
       else {
         return false;
       }
     }
     else {
       return false;
     }

}

/**
 * add publish date to product grid
 * @since 1.3
 */
function bookchoix_book_publish_date() {

   $settings = acmthemes_settings();

   if( isset( $settings['catalog_hide_publication_date'] ) && 1  == $settings['catalog_hide_publication_date'] )
    return;

   if( function_exists( 'rwmb_meta' ) ) {

     $pb_date = rwmb_meta( 'bks_publish_date' );

     if( !empty( $pb_date ) ) {

       //input saved as timestamp format
       if( is_numeric( $pb_date ) )
        $formated_date = date( 'Y-m-d', $pb_date );
        //input saved as date format or other format
       else
        $formated_date = $pb_date;

       $pd_label = ( isset( $settings[ 'publication_date_text' ] ) && ! empty( $settings[ 'publication_date_text' ] ) ) ? $settings[ 'publication_date_text' ] :
        esc_html__( 'Published on', 'bookchoix' );
       echo '<div class="publication-date">';
       echo esc_attr( $pd_label );

       $sep = ( isset( $settings[ 'publication_date_separator' ] ) && ! empty( $settings[ 'publication_date_separator' ] ) ) ? $settings[ 'publication_date_separator' ] : " ";
       $formated_date = explode( '-', $formated_date );
       
       if( isset( $settings[ 'publish_date_format' ] ) && 2 == $settings[ 'publish_date_format' ] ) {

         echo ' ' . esc_html( bookchoix_num_to_month_conversion( $formated_date[1] ) ) . wp_kses_post( $sep ) . esc_html( $formated_date[0] );

         //show error notice if not saved in timestamp format
         if( ! is_numeric( $pb_date ) )
          echo '[E]';
       }
       else
        echo ' ' . esc_html( $formated_date[0] );

       echo '</div>';
     }

   }

}

/**
 * add publish date to product grid
 * @since 1.3
 */
if( ! function_exists( 'bookchoix_num_to_month_conversion' ) ) {
  function bookchoix_num_to_month_conversion( $month ) {

    $months = array();
    $months['01'] = esc_html__( 'Jan', 'bookchoix' );
    $months['02'] = esc_html__( 'Feb', 'bookchoix' );
    $months['03'] = esc_html__( 'Mar', 'bookchoix' );
    $months['04'] = esc_html__( 'Apr', 'bookchoix' );
    $months['05'] = esc_html__( 'May', 'bookchoix' );
    $months['06'] = esc_html__( 'Jun', 'bookchoix' );
    $months['07'] = esc_html__( 'July', 'bookchoix' );
    $months['08'] = esc_html__( 'Aug', 'bookchoix' );
    $months['09'] = esc_html__( 'Sep', 'bookchoix' );
    $months['10'] = esc_html__( 'Oct', 'bookchoix' );
    $months['11'] = esc_html__( 'Nov', 'bookchoix' );
    $months['12'] = esc_html__( 'Dec', 'bookchoix' );

    if( is_numeric( $month ) ) {
      return $months[$month];
    }
    else return false;

  }

}

function bookchoix_list_searcheable_acf(){
  $bookchoix_list_searcheable_acf = array('bks_isbn_10', 'bks_isbn_13', 'bks_book_publisher');
  return $bookchoix_list_searcheable_acf;
}

/**
 * search field to search woo products only
 * @since 1.0.0
 */
function bookchoix_header_advanced_search( $where ) {

    $settings = acmthemes_settings();
    $post_type = ( !empty( $settings['header_search_type']) && $settings['header_search_type'] == 'all' ) ? 2 : 1;

    if ( $post_type == 2 ) {
      return $where;
    }

    global $wpdb, $wp;

    if ( empty( $where ) && !isset($wp->query_vars['s']) )
        return $where;

    // get search expression
    $terms = $wp->query_vars[ 's' ];

    // explode search expression to get search terms
    $exploded = explode( ' ', $terms );
    if( $exploded === FALSE || count( $exploded ) == 0 )
        $exploded = array( 0 => $terms );

    // reset search in order to rebuilt it as we whish
    $where = '';

    // get searcheable_acf, a list of advanced custom fields you want to search content in
    $bookchoix_list_searcheable_acf = bookchoix_list_searcheable_acf();
    foreach( $exploded as $tag ) :
        $where .= "
          AND (
            ({$wpdb->prefix}posts.post_title LIKE '%$tag%')
            OR ({$wpdb->prefix}posts.post_content LIKE '%$tag%')
            OR EXISTS (
              SELECT * FROM {$wpdb->prefix}postmeta
	              WHERE post_id = {$wpdb->prefix}posts.ID
	                AND (";
        foreach ($bookchoix_list_searcheable_acf as $searcheable_acf) :
          if ($searcheable_acf == $bookchoix_list_searcheable_acf[0]):
            $where .= " (meta_key LIKE '%" . $searcheable_acf . "%' AND meta_value LIKE '%$tag%') ";
          else :
            $where .= " OR (meta_key LIKE '%" . $searcheable_acf . "%' AND meta_value LIKE '%$tag%') ";
          endif;
        endforeach;
	        $where .= ")
            )
            OR EXISTS (
              SELECT * FROM {$wpdb->prefix}comments
              WHERE comment_post_ID = {$wpdb->prefix}posts.ID
                AND comment_content LIKE '%$tag%'
            )
            OR EXISTS (
              SELECT * FROM {$wpdb->prefix}terms
              INNER JOIN {$wpdb->prefix}term_taxonomy
                ON {$wpdb->prefix}term_taxonomy.term_id = {$wpdb->prefix}terms.term_id
              INNER JOIN {$wpdb->prefix}term_relationships
                ON {$wpdb->prefix}term_relationships.term_taxonomy_id = {$wpdb->prefix}term_taxonomy.term_taxonomy_id
              WHERE (
          		taxonomy = 'post_tag'
            		OR taxonomy = 'category'
            		OR taxonomy = 'authors'
          		)
              	AND object_id = {$wpdb->prefix}posts.ID
              	AND {$wpdb->prefix}terms.name LIKE '%$tag%'
            )
        ) AND post_type = 'product'";
    endforeach;
    return $where;
}

if( isset( $_GET['post_type'] ) && $_GET['post_type'] == 'product' )
  add_filter( 'posts_search', 'bookchoix_header_advanced_search', 500, 2 );


if ( isset($_GET['page']) && $_GET['page'] == 'acmthemes-setup-wizard' ) {
  add_filter( 'woocommerce_enable_setup_wizard', 'disable_woo_setup_wizard' );
  function disable_woo_setup_wizard( $true ) {
    return false;
  }
}

//functions for customization
//add round brackets to category count
add_filter('wp_list_categories', 'bookchoix_add_span_cat_count');
if ( ! function_exists( 'bookchoix_add_span_cat_count' ) ) {
    function bookchoix_add_span_cat_count($links) {
        $links = str_replace('</a> (', '</a> <span class="post-count">(', $links);
        $links = str_replace(')', ')</span>', $links);
        return $links;
    }
}

/**
* create books tab under woo accounts page
* @since 1.2.3
* Register New Endpoint.
*/

add_action( 'init', 'bookchoix_register_my_books_endpoint');
function bookchoix_register_my_books_endpoint() {
	add_rewrite_endpoint( 'my-books', EP_ROOT | EP_PAGES );
}

/**
* Adding new query var
*
* @return array
*/
add_filter( 'query_vars', 'bookchoix_books_query_vars' );
function bookchoix_books_query_vars( $vars ) {

	$vars[] = 'my-books';
	return $vars;
}

/**
* adding my books tab
*
* @return array
*/
add_filter( 'woocommerce_account_menu_items', 'bookchoix_my_books_tab' );
function bookchoix_my_books_tab( $items ) {

	$items['my-books'] = esc_html__( 'My Books', 'bookchoix' );
	return $items;
}

/**
* adding content to the my books tab
*
* @return string
*/
add_action( 'woocommerce_account_my-books_endpoint', 'bookchoix_my_books_tab_content' );
function bookchoix_my_books_tab_content() {

  //get framework settings
  $settings = acmthemes_settings();

  $current_user = get_current_user_id();

  if( isset( $_GET['order_id'] ) && $current_user > 0  ) {

    $order = esc_html( $_GET['order_id'] );
    $book_id = esc_html( $_GET['book_id'] );
    $orders = wc_get_order( $_GET['order_id'] );
    $customer_id = $orders->get_user_id();

    $allow_read = false;
    foreach ( $orders->get_items() as $item_id => $item ) {
      //getting the product id
      $product_id = $item->get_product_id();

      //check if the user purchased the product
      if( $customer_id == $current_user && $product_id == $book_id ) {
        $allow_read = true;
      }
    }

    //allow read only if the customer bought the book
    if( true === $allow_read ) {
      ?>
      <a class="backto-myaccount-btn" href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ) . 'my-books'; ?>"><?php echo esc_html__( 'Back to My Books', 'bookchoix' ); ?></a>
      <?php
      //pdf attachment
      $pdf_attachment_id = get_post_meta( $book_id, '_bookchoix_bookpdf_attachment_id', true );
      $book_url = wp_get_attachment_url( $pdf_attachment_id );

      //embedded code
      $embed_code = get_post_meta( $book_id, '_bookchoix_main_pdf_embed_code', true );

      /**
       * get viewser type setting
       * 1. Wondershare PDF viewer
       * 2. Custom embed code
       * 3. Use action hook "bookchoix_main_pdf_single"
       **/
      $select_viewer_type = ( isset( $settings['select_viewer_type'] ) ) ? $settings['select_viewer_type'] : 1;

      if( isset( $embed_code ) && ! empty( $embed_code ) && 2 == $select_viewer_type ) {
        $allowed_html_iframe = array(
          'iframe' => array(
            'width' => array(),
            'height'	=> array(),
            'src'	=> array(),
            'title'	=> array(),
            'frameborder'	=> array(),
            'allow'	=> array(),
          )
        );
        $custom_code = wp_kses( $embed_code, $allowed_html_iframe );
        echo do_shortcode( $custom_code, false );
      }
      //show wonderplugin pdf
      elseif( $book_url && shortcode_exists( 'wonderplugin_pdf' ) ) {
        //get display method
        $method = ( isset( $settings['pdf_display_method'] ) ) ? $settings['pdf_display_method'] : 1;

        if( $method == 1 )
          echo do_shortcode('[wonderplugin_pdf src="'. esc_url( $book_url ) .'" width="100%" height="700px" style="border:0;"]');
        elseif( function_exists( 'acm_base64_pdf_format' ) )
          acm_base64_pdf_format( $book_url, $pdf_attachment_id );

      }
      elseif( 3 == $select_viewer_type ) {

        /**
        * action hook for embedding custom pdf viewer
        * @since 1.2.5
        */
        do_action( 'bookchoix_main_pdf_my_accounts', $book_url, $pdf_attachment_id );

      }

      //show notification when pdf viewer is defined
      if( ! shortcode_exists( 'wonderplugin_pdf' ) && ! defined( 'BKC_CUSTOM_PDFVIEWER' ) ) {
        echo esc_html__( 'In order to read the PDF, Wonder embed pdf plugin needs to be installed.', 'bookchoix' );
      }

    }

  }
  else {
    // Get all customer orders
    $customer_orders = wc_get_orders(array(
      'customer' => get_current_user_id(),
      'status'   => array('completed'),
    ));

    ?>
    <table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
      <thead>
        <tr>
          <th>
            <span class="nobr"><?php echo esc_html__( 'Order ID', 'bookchoix' ); ?></span>
          </th>
          <th>
          </th>
          <th>
            <span class="nobr"><?php echo esc_html__( 'Book name', 'bookchoix' ); ?></span>
          </th>
          <th>
            <span class="nobr"><?php echo esc_html__( 'Action', 'bookchoix' ); ?></span>
          </th>
        </tr>
      </thead>
      <tbody>
  <?php

    foreach ( $customer_orders as $customer_order ) {
      ?>
      <?php
        //get all product orders per transaction
        $orders = wc_get_order( $customer_order->get_id() );
        foreach ( $orders->get_items() as $item_id => $item ) {
          $allowed_html_iframe = array(
            'iframe' => array(
              'width' => array(),
              'height'	=> array(),
              'src'	=> array(),
              'title'	=> array(),
              'frameborder'	=> array(),
              'allow'	=> array(),
            )
          );
        ?>
        <tr>
        <?php
         $product_id = $item->get_product_id();
         $product_name = $item->get_name();
         $pdf_attachment = get_post_meta( $product_id, '_bookchoix_bookpdf_attachment_id', true );
         $embed_code = get_post_meta( $product_id, '_bookchoix_main_pdf_embed_code', true );
         $custom_code = wp_kses( $embed_code, $allowed_html_iframe );
         ?>
         <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number">
         <?php echo '#'. $customer_order->get_id(); ?>
         </td>
         <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number">
         <img class="account-order-book-thumb" src="<?php echo get_the_post_thumbnail_url( $product_id );?>" alt="<?php echo esc_attr( $product_name ); ?>" />
         </td>
         <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number">
         <?php echo esc_html( $product_name ); ?>
         </td>
         <td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number">
           <?php if( isset( $pdf_attachment ) && $pdf_attachment > 0 || ! empty( $custom_code ) ) { ?>
             <a href="?order_id=<?php echo esc_attr( $customer_order->get_id() ); ?>&book_id=<?php echo esc_attr( $product_id ); ?>" class="woocommerce-button button view"><?php echo esc_html__( 'Read Book', 'bookchoix' ); ?></a>
           <?php } ?>
         </td>

         </tr>
      <?php
        }

    }

	?>

    </tbody>
  </table>
  <?php

} //else

}

/**
* reorder account tabs
*
* @return array
*/
add_filter ( 'woocommerce_account_menu_items', 'bookchoix_reorder_woo_account_menus' );
function bookchoix_reorder_woo_account_menus( $items ) {
    return array(
        'dashboard'          => esc_html__( 'Dashboard', 'bookchoix' ),
        'edit-account'       => esc_html__( 'Edit Account', 'bookchoix' ),
        'orders'             => esc_html__( 'Orders', 'bookchoix' ),
        'my-books'           => esc_html__( 'My Books', 'bookchoix' ),
        'downloads'          => esc_html__( 'Downloads', 'bookchoix' ),
        'edit-address'       => esc_html__( 'Addresses', 'bookchoix' ),
        'customer-logout'    => esc_html__( 'Logout', 'bookchoix' ),
    );

}

/**
* remove account tabs
*
* @return array
*/
add_filter ( 'woocommerce_account_menu_items', 'bookchoix_remove_woo_account_menus' );
function bookchoix_remove_woo_account_menus( $items ) {

  //get theme settings
  $settings = acmthemes_settings();

  //hide downloads if set
  if( isset( $settings['hide_downloads'] ) && $settings['hide_downloads'] == 1 ) {
    unset( $items['downloads'] );
  }

  //hide my books if set
  if( isset( $settings['hide_my_books'] ) && $settings['hide_my_books'] == 1 ) {
    unset( $items['my-books'] );
  }

  return $items;

}

/**
 * Add custom sorting options (asc/desc)
 * @since 1.3
 */
add_filter( 'woocommerce_get_catalog_ordering_args', 'bookchoix_woocommerce_get_catalog_ordering_args', 20 );
function bookchoix_woocommerce_get_catalog_ordering_args( $args ) {
  //get theme settings
  $settings = acmthemes_settings();

  if( ! isset( $settings['enable_publish_date_sort_order'] ) || 0 == $settings['enable_publish_date_sort_order'] )
    return $args;

  $orderby_value = isset( $_GET['orderby'] ) ? wc_clean( $_GET['orderby'] ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );
	if ( 'date_asc' == $orderby_value ) {
		$args['orderby'] = 'meta_value_num';
		$args['order'] = 'ASC';
		$args['meta_key'] = 'bks_publish_date';
	}
  elseif ( 'date_desc' == $orderby_value ) {
		$args['orderby'] = 'meta_value_num';
		$args['order'] = 'DESC';
		$args['meta_key'] = 'bks_publish_date';
	}
	return $args;
}

add_filter( 'woocommerce_default_catalog_orderby_options', 'bookchoix_woocommerce_catalog_orderby' );
add_filter( 'woocommerce_catalog_orderby', 'bookchoix_woocommerce_catalog_orderby' );
function bookchoix_woocommerce_catalog_orderby( $sortby ) {
  //get theme settings
  $settings = acmthemes_settings();

  if( ! isset( $settings['enable_publish_date_sort_order'] ) || 0 == $settings['enable_publish_date_sort_order'] )
    return $sortby;

	$sortby['date_asc'] = esc_html__( 'Publication date ascending', 'bookchoix' );
  $sortby['date_desc'] = esc_html__( 'Publication date descending', 'bookchoix' );
	return $sortby;
}

/**
 * show all products on the author taxonomy template
 * @since 1.6.0
 */
function bookchoix_tax_show_all_posts ( $query ) {
  if ( ($query->is_tax(array('authors')) ) )      
    $query->set( 'posts_per_page', -1 );

  if ( ($query->is_tax(array('publishers')) ) )      
    $query->set( 'posts_per_page', -1 );
}
add_action( 'pre_get_posts', 'bookchoix_tax_show_all_posts' );