<?php
/**
 * Perform all main WooCommerce configurations for this theme
 *
 * @package BookChoix WordPress theme
 */

// Start and run class
if ( ! class_exists( 'ACMTHEMES_WOOCOMMERCE_CONFIG' ) ) {

	class ACMTHEMES_WOOCOMMERCE_CONFIG {

		/**
		 * Main Class Constructor
		 *
		 * @since 1.0.0
		 */
		public function __construct() {

			// Include helper functions
			require_once( ACMTHEMES_INC_DIR .'woocommerce/woocommerce-helpers.php' );

			//get framework settings
			$settings = acmthemes_settings();

			// Move default WooCommerce customizer sections to the theme section
			add_action( 'customize_register', array( $this, 'woo_section' ), 11 );


			if ( ! is_admin() ) {

				// Remove default wrappers and add new ones
				remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
				remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
				add_action( 'woocommerce_before_main_content', array( $this, 'content_wrapper' ), 10 );
				add_action( 'woocommerce_after_main_content', array( $this, 'content_wrapper_end' ), 10 );

				remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );

			}

			// Custom WooCommerce features
			// These filters/actions must run on init
			add_action( 'init', array( $this, 'init' ) );

			// Body classes
			add_filter( 'body_class', array( $this, 'body_class' ) );

			// Define accents
			add_filter( 'primary_texts', array( $this, 'primary_texts' ) );
			add_filter( 'primary_borders', array( $this, 'primary_borders' ) );
			add_filter( 'primary_backgrounds', array( $this, 'primary_backgrounds' ) );
			add_filter( 'hover_primary_backgrounds', array( $this, 'hover_primary_backgrounds' ) );

			/*-------------------------------------------------------------------------------*/
			/* -  Front-End only actions/filters
			/*-------------------------------------------------------------------------------*/
			if ( ! is_admin() ) {

				// Disable WooCommerce main page title
				add_filter( 'woocommerce_show_page_title', '__return_false' );

				// Disable WooCommerce css
				add_filter( 'woocommerce_enqueue_styles', '__return_false' );

				// Remove the category description under the page title on taxonomy
				add_filter( 'post_subheading', array( $this, 'post_subheading' ) );

				// Show/hide next/prev on products
				add_filter( 'has_next_prev', array( $this, 'next_prev' ) );

				// Border colors
				add_filter( 'border_color_elements', array( $this, 'border_color_elements' ) );

			}

			// Main Woo Actions
			add_action( 'wp_enqueue_scripts', array( $this, 'add_custom_scripts' ) );
			add_filter( 'localize_array', array( $this, 'localize_array' ) );
			add_action( 'woocommerce_before_shop_loop', array( $this, 'add_shop_loop_div' ) );

			if( isset( $settings['shop_grid_list'] ) && ! empty( $settings['shop_grid_list'] ) ) {
				add_action( 'woocommerce_before_shop_loop', array( $this, 'grid_list_buttons' ), 10 );
			}
			add_action( 'woocommerce_before_shop_loop', array( $this, 'off_canvas_filter_button' ), 10 );

			add_action( 'woocommerce_before_shop_loop', array( $this, 'close_shop_loop_div' ), 40 );

			add_action( 'woocommerce_before_shop_loop_item', array( $this, 'add_shop_loop_item_inner_div' ) );
			add_action( 'woocommerce_after_shop_loop_item', array( $this, 'archive_product_content' ), 10 );
			add_action( 'woocommerce_after_shop_loop_item', array( $this, 'close_shop_loop_item_inner_div' ) );
			add_action( 'woocommerce_before_subcategory_title', array( $this, 'add_container_wrap_category' ), 8 );
			add_action( 'woocommerce_before_subcategory_title', array( $this, 'add_div_before_category_thumbnail' ), 9 );
			add_action( 'woocommerce_before_subcategory_title', array( $this, 'close_div_after_category_thumbnail' ), 11 );
			add_action( 'woocommerce_shop_loop_subcategory_title', array( $this, 'add_div_before_category_title' ), 9 );
			add_action( 'woocommerce_shop_loop_subcategory_title', array( $this, 'add_category_description' ), 11 );
			add_action( 'woocommerce_shop_loop_subcategory_title', array( $this, 'close_div_after_category_title' ), 12 );
			add_action( 'woocommerce_shop_loop_subcategory_title', array( $this, 'close_container_wrap_category' ), 13 );

			add_action( 'woocommerce_after_single_product_summary', array( $this, 'clear_summary_floats' ), 1 );
			add_action( 'woocommerce_before_account_navigation', array( $this, 'acmthemes_before_account_navigation' ) );
			add_action( 'woocommerce_after_account_navigation', array( $this, 'acmthemes_after_account_navigation' ) );
			if ( get_option( 'woocommerce_enable_myaccount_registration' ) !== 'yes' ) {
				add_action('woocommerce_before_customer_login_form', array( $this, 'acmthemes_login_wrap_before' ) );
				add_action('woocommerce_after_customer_login_form', array( $this, 'acmthemes_login_wrap_after' ) );
			}
			if ( isset( $settings[ 'woo_category_header' ] ) && $settings[ 'woo_category_header' ] == 1 ) {
				add_action( 'woocommerce_archive_description', array( $this, 'woocommerce_category_image' ), 2 );
			}
			else {
				remove_action( 'woocommerce_archive_description', 'woocommerce_taxonomy_archive_description', 10, 2 );
			}

			// Quick view
			if( empty( $settings['woo_quick_view'] ) ) {
				add_action( 'wp_ajax_acmthemes_product_quick_view', array( $this, 'product_quick_view_ajax' ) );
				add_action( 'wp_ajax_nopriv_acmthemes_product_quick_view', array( $this, 'product_quick_view_ajax' ) );
				add_action( 'wp_footer', array( $this, 'quick_view_template' ) );
				add_action( 'woo_quick_view_product_image', 'woocommerce_show_product_sale_flash', 10 );
				add_action( 'woo_quick_view_product_image', array( $this, 'quick_view_image' ), 20 );
				add_action( 'woo_quick_view_product_content', array( $this, 'single_product_content' ), 10 );
			}

			// Ajax single product add to cart
			add_action( 'wp_ajax_oceanwp_add_cart_single_product', array( $this, 'add_cart_single_product_ajax' ) );
			add_action( 'wp_ajax_nopriv_oceanwp_add_cart_single_product', array( $this, 'add_cart_single_product_ajax' ) );

			// Remove default elements
			remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
			add_action( 'woocommerce_before_template_part', array( $this, 'before_template_part' ), 10, 4 );
			self::remove_elements();

			// Remove the single product summary content to add the sortable control
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
			add_action( 'bookchoix_woo_single_add_to_cart', 'woocommerce_template_single_add_to_cart', 10 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
			add_action( 'woocommerce_single_product_summary', array( $this, 'single_product_content' ), 10 );

			// Main Woo Filters
			add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'menu_cart_icon_fragments' ) );
			
			add_filter( 'woocommerce_general_settings', array( $this, 'remove_general_settings' ) );
			add_filter( 'woocommerce_product_settings', array( $this, 'remove_product_settings' ) );
			add_filter( 'loop_shop_per_page', array( $this, 'loop_shop_per_page' ), 20 );
			add_filter( 'loop_shop_columns', array( $this, 'loop_shop_columns' ) );
			add_filter( 'woocommerce_output_related_products_args', array( $this, 'related_product_args' ) );
			add_filter( 'woocommerce_pagination_args', array( $this, 'pagination_args' ) );
			add_filter( 'woocommerce_continue_shopping_redirect', array( $this, 'continue_shopping_redirect' ) );
			add_filter( 'post_class', array( $this, 'add_product_classes' ), 40, 3 );
			add_filter( 'post_class', array( $this, 'add_product_class_for_elementor' ) );
			add_filter( 'product_cat_class', array( $this, 'product_cat_class' ) );


			// Add links Login/Register on the my account page
			add_action( 'woocommerce_before_customer_login_form', array( $this, 'login_register_links' ) );

			// WooCommerce Match Box extension single product layout support.
			add_action( 'woocommerce_match_box_single_product_layout', array( $this, 'remove_wc_match_box_single_product_summary' ), 10 );

			//remove woosc buttons from all places to add it only in the product grids
			add_filter( 'woosc_button_position_archive', '__return_false' );
			add_filter( 'woosc_button_position_single', '__return_false' );

			//set minimum columns for woosc table
			add_filter( 'woosc_get_table_minimum_columns', function () {
				return 5;
			} );


		} // End __construct

		/*-------------------------------------------------------------------------------*/
		/* -  Start Class Functions
		/*-------------------------------------------------------------------------------*/

		/**
		 * Move default WooCommerce customizer sections to the theme section.
		 *
		 * @since 1.0.0
		 */
		public static function woo_section( $wp_customize ) {
			return; //currently disabled
			$wp_customize->get_section( 'woocommerce_checkout' )->panel = 'woocommerce_panel';
			$wp_customize->get_section( 'woocommerce_store_notice' )->panel = 'woocommerce_panel';
			$wp_customize->get_section( 'woocommerce_product_images' )->panel = 'woocommerce_panel';
			$wp_customize->get_section( 'woocommerce_product_images' )->priority = 999;
			$wp_customize->get_control( 'woocommerce_shop_page_display' )->section = 'woocommerce_archives';
			$wp_customize->get_control( 'woocommerce_category_archive_display' )->section = 'woocommerce_archives';
			$wp_customize->get_control( 'woocommerce_default_catalog_orderby' )->section = 'woocommerce_archives';
			$wp_customize->get_control( 'woocommerce_checkout_company_field' )->section = 'woocommerce_checkout';
			$wp_customize->get_control( 'woocommerce_checkout_address_2_field' )->section = 'woocommerce_checkout';
			$wp_customize->get_control( 'woocommerce_checkout_phone_field' )->section = 'woocommerce_checkout';
			$wp_customize->get_control( 'woocommerce_checkout_highlight_required_fields' )->section = 'woocommerce_checkout';
			$wp_customize->get_control( 'wp_page_for_privacy_policy' )->section = 'woocommerce_checkout';
			$wp_customize->get_control( 'woocommerce_terms_page_id' )->section = 'woocommerce_checkout';
			$wp_customize->get_control( 'woocommerce_checkout_privacy_policy_text' )->section = 'woocommerce_checkout';
			$wp_customize->get_control( 'woocommerce_checkout_terms_and_conditions_checkbox_text' )->section = 'woocommerce_checkout';
		}

		/**
		 * Content wrapper.
		 *
		 * @since 1.0.0
		 */
		public static function content_wrapper() {
			get_template_part( 'woocommerce/wc-content-wrapper' );
		}

		/**
		 * Content wrapper end.
		 *
		 * @since 1.0.0
		 */
		public static function content_wrapper_end() {
			get_template_part( 'woocommerce/wc-content-wrapper-end' );
		}

		/**
		 * Runs on Init.
		 * You can't remove certain actions in the constructor because it's too early.
		 *
		 * @since 1.0.0
		 */
		public function init() {

			$settings = acmthemes_settings();

			// Remove WooCommerce breadcrumbs
			remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );

			remove_action( 'woocommerce_single_product_summary', 'YITH_WCWL_Init', 11 );

			// Alter upsells display
			remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
			if ( isset ( $settings['show_upsell_sell'] ) && 1 == $settings['show_upsell_sell'] ) {
				add_action( 'woocommerce_after_single_product_summary', array( $this, 'upsell_display' ), 15 );
			}

			// Alter cross-sells display
			remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
			if ( isset ( $settings['show_cross_sell'] ) && 1 == $settings['show_cross_sell'] ) {
				add_action( 'woocommerce_cart_collaterals', array( $this, 'cross_sell_display' ) );
			}

			// Remove related products if is set to no
			if ( isset ( $settings['disable_related_items'] ) && 1 == $settings['disable_related_items'] ) {
				remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
			}

			// Add product view count
			if ( isset ( $settings['shop_view_pr_count'] ) && 1 == $settings['shop_view_pr_count'] ) {
				add_action( 'woocommerce_before_shop_loop', array( $this, 'result_count' ), 31 );
			}

			if ( defined( 'ELEMENTOR_WOOSTORE__FILE__' ) ) {
				remove_action( 'woocommerce_after_shop_loop_item_title', 'woostore_output_product_excerpt', 35 );
				add_action( 'woocommerce_after_shop_loop_item', 'woostore_output_product_excerpt', 21 );
			}

			if ( ! function_exists( 'yith_wcbm_shop_badge_container_start' )
				&& ! function_exists( 'yith_wcbm_shop_badge_container_end' ) ) {
				add_action( 'woocommerce_before_shop_loop_item_title', array( $this, 'yith_wcbm_shop_badge_container_start' ), 9 );
				add_action( 'woocommerce_before_shop_loop_item_title', array( $this, 'yith_wcbm_shop_badge_container_end' ), 20 );
			}

			if ( class_exists( 'WooCommerce_Germanized' ) ) {
				remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_gzd_template_single_shipping_costs_info', 7 );
				remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_gzd_template_single_tax_info', 6 );
				remove_action( 'woocommerce_single_product_summary', 'woocommerce_gzd_template_single_legal_info', 12 );
				add_action( 'after_archive_product_inner', array( $this, 'woocommerce_germanized' ) );
				add_action( 'after_single_product_price', 'woocommerce_gzd_template_single_legal_info' );
			}

		}

		/**
		 * Remove elemnts.
		 *
		 * @since 1.0.0
		 */
		public function remove_elements() {
			remove_action( 'woocommerce_before_shop_loop_item','woocommerce_template_loop_product_link_open', 10 );
			remove_action( 'woocommerce_after_shop_loop_item','woocommerce_template_loop_product_link_close', 5 );
			remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
			remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
			remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
			remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
			remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
			remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
		}

		/**
		 * Fix the issue in the Elementor Pro editor.
		 *
		 * @since 1.0.0
		 */
		public function before_template_part( $template_name, $template_path, $located, $args ) {
			if ( class_exists( 'Elementor\Plugin' )
				&& \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				self::remove_elements();
			}
		}

		/**
		 * Infinite scroll pagination.
		 *
		 * @since 1.0.0
		 */
		public static function infinite_pagination() {
			global $wp_query;

			if ( $wp_query->max_num_pages <= 1 ) {
				return;
			}

			// Load infinite scroll script
			wp_enqueue_script( 'infinitescroll' );

			// Last text
			$last = esc_html__( 'End of content', 'bookchoix' );

			// Error text
			$error = esc_html__( 'No more pages to load', 'bookchoix' );

			// Output pagination HTML ?>
			<div class="scroller-status">
				<div class="loader-ellips infinite-scroll-request">
					<span class="loader-ellips__dot"></span>
					<span class="loader-ellips__dot"></span>
					<span class="loader-ellips__dot"></span>
					<span class="loader-ellips__dot"></span>
				</div>
				<p class="scroller-status__message infinite-scroll-last"><?php echo esc_attr( $last ); ?></p>
				<p class="scroller-status__message infinite-scroll-error"><?php echo esc_attr( $error ); ?></p>
			</div>
			<div class="infinite-scroll-nav clr">
				<div class="alignleft newer-posts"><?php echo get_previous_posts_link('&larr; '. esc_html__( 'Newer Posts', 'bookchoix' ) ); ?></div>
				<div class="alignright older-posts"><?php echo get_next_posts_link( esc_html__( 'Older Posts', 'bookchoix' ) .' &rarr;', $wp_query->max_num_pages ); ?></div>
			</div>
		<?php
		}

		/**
		 * Helper method to get the version of the currently installed WooCommerce.
		 *
		 * @since 1.0.0
		 * @return string woocommerce version number or null.
		 */
		public static function get_wc_version() {
			return defined( 'WC_VERSION' ) && WC_VERSION ? WC_VERSION : null;
		}

		/**
		 * Remove general settings from Woo Admin panel.
		 *
		 * @since 1.0.0
		 */
		public static function remove_general_settings( $settings ) {
			$remove = array( 'woocommerce_enable_lightbox' );
			foreach( $settings as $key => $val ) {
				if ( isset( $val['id'] ) && in_array( $val['id'], $remove ) ) {
					unset( $settings[$key] );
				}
			}
			return $settings;
		}

		/**
		 * Remove product settings from Woo Admin panel.
		 *
		 * @since 1.0.0
		 */
		public static function remove_product_settings( $settings ) {
			$remove = array(
				'woocommerce_enable_lightbox'
			);
			foreach( $settings as $key => $val ) {
				if ( isset( $val['id'] ) && in_array( $val['id'], $remove ) ) {
					unset( $settings[$key] );
				}
			}
			return $settings;
		}

		/**
		 * Body classes
		 *
		 * @since 1.0.0
		 */
		public static function body_class( $classes ) {

			// My Account page style
			$style = 'original';
			if ( 'side' == $style ) {
				$classes[] = 'account-side-style';
			} else {
				$classes[] = 'account-original-style';
			}

			// Return
 			return $classes;

		}

		/**
		 * Add Custom WooCommerce scripts.
		 *
		 * @since 1.0.0
		 */
		public static function add_custom_scripts() {

			// Register WooCommerce styles
			wp_enqueue_style( 'acmthemes-woocommerce', ACMTHEMES_CSS_DIR_URI .'woo/woocommerce.css' );
			wp_enqueue_style( 'acmthemes-woo-star-font', ACMTHEMES_CSS_DIR_URI .'woo/woo-star-font.min.css' );

			// If rtl
			if ( is_RTL() ) {
				wp_enqueue_style( 'acmthemes-woocommerce-rtl', ACMTHEMES_CSS_DIR_URI .'woo/woocommerce-rtl.css' );
			}

			// If quick view
			wp_enqueue_script( 'acmthemes-woo-quick-view', ACMTHEMES_JS_DIR_URI .'third/woo/woo-quick-view.min.js', array( 'jquery' ), ACMTHEMES_THEME_VERSION, true );
			wp_enqueue_style( 'acmthemes-woo-quick-view', ACMTHEMES_CSS_DIR_URI .'woo/woo-quick-view.min.css' );
			wp_enqueue_script( 'wc-add-to-cart-variation' );
			wp_enqueue_script( 'flexslider' );

			// If whislist
			if ( class_exists( 'TInvWL_Wishlist' ) ) {
				wp_enqueue_style( 'acmthemes-wishlist', ACMTHEMES_CSS_DIR_URI .'woo/wishlist.min.css' );
			}

		}

		/**
		 * Localize array.
		 *
		 * @since 1.0.0
		 */
		public static function localize_array( $array ) {

			// If single product ajax add to cart
			if ( true == get_theme_mod( 'woo_product_ajax_add_to_cart', false ) ) {
				$array['is_cart'] 			= is_cart();
				$array['cart_url'] 			= apply_filters( 'woocommerce_add_to_cart_redirect', wc_get_cart_url() );
			}

			// If quick view, ajax add to cart or floating bar
			$array['ajax_url'] = admin_url( 'admin-ajax.php' );

			// Add the View Cart here to avoid the undefined word on the related products
			$array['view_cart'] = esc_html__( 'View cart', 'bookchoix' );

			// Grouped product button text in the quick view
			$array['grouped_text'] = esc_attr__( 'View products', 'bookchoix' );

			return $array;

		}

		/**
		 * Single Product add to cart ajax request.
		 *
		 * @since 1.0.0
		 */
		public static function add_cart_single_product_ajax() {

			$product_id   	= sanitize_text_field( $_POST['product_id'] );
			$variation_id 	= sanitize_text_field( $_POST['variation_id'] );
			$variation 		= $_POST['variation'];
			$quantity     	= sanitize_text_field( $_POST['quantity'] );

			if ( $variation_id ) {
				WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation );
			} else {
				WC()->cart->add_to_cart( $product_id, $quantity );
			}
			die();

		}


		/**
		 * Get mini cart sidebar.
		 *
		 * @since 1.0.0
		 */
		public static function get_mini_cart_sidebar() {

			// Define classes
			$classes = array( 'acmthemes-cart-sidebar' );

			// Turn classes into string
			$classes = implode( ' ', $classes );

			echo '<div id="acmthemes-cart-sidebar-wrap">';
				echo '<div class="'. $classes .'">';
					echo '<a href="#" class="acmthemes-cart-close">×</a>';
					echo '<p class="woo-cart-title">'. esc_html__( 'Cart', 'bookchoix' ) .'</p><div class="divider"></div>';
					echo '<div class="woo-mini-cart">';
						the_widget( 'WC_Widget_Cart', 'title=' );
					echo '</div>';
				echo '</div>';
				echo '<div class="acmthemes-cart-sidebar-overlay"></div>';
			echo '</div>';

		}

		/**
		 * Adds an opening div "acmthemes-toolbar" around top elements.
		 *
		 * @since 1.0.0
		 */
		public static function add_shop_loop_div() {
			echo '<div class="acmthemes-toolbar clr">';
		}

		/**
		 * Get Off Canvas Sidebar.
		 *
		 * @since 1.0.0
		 */
		public static function get_off_canvas_sidebar() {

			// Return if is not in shop page
			if ( ! acmthemes_is_woo_shop()
				&& ! acmthemes_is_woo_tax() ) {
				return;
			}

		}

		/**
		 * Add off canvas filter button.
		 *
		 * @since 1.0.0
		 */
		public static function off_canvas_filter_button() {
			//get theme settings
			$settings = acmthemes_settings();

			// Return if is not in shop page
			if ( ! acmthemes_is_woo_shop()
				&& ! acmthemes_is_woo_tax() ) {
				return;
			}

			if( isset( $settings['enable_offcanvas_shop_sidebar'] ) && 1 == $settings['enable_offcanvas_shop_sidebar'] ) {
				// Get filter text
				$text = esc_html__( 'Filter', 'bookchoix' );

				$output = '<a href="#" class="acmthemes-off-canvas-filter"><i class="icon-menu"></i><span class="off-canvas-filter-text">'. esc_html( $text ) .'</span></a>';

				echo apply_filters( 'acmthemes_off_canvas_filter_button_output', $output );
			}

		}

		/**
		 * Add grid/list buttons.
		 *1.0.0
		 */
		public static function grid_list_buttons() {

			// Return if is not in shop page
			if ( ! acmthemes_is_woo_shop()
				&& ! acmthemes_is_woo_tax() ) {
				return;
			}

			// Titles
			$grid_view = esc_html__( 'Grid view', 'bookchoix' );
			$list_view = esc_html__( 'List view', 'bookchoix' );

			// Active class
			if ( 'list' == 'grid' ) {
				$list = 'active ';
				$grid = '';
			} else {
				$grid = 'active ';
				$list = '';
			}

			$output = sprintf( '<nav class="acmthemes-grid-list"><a href="#" id="acmthemes-grid" title="%1$s" class="%2$sgrid-btn"><span class="fa fa-th"></span></a><a href="#" id="acmthemes-list" title="%3$s" class="%4$slist-btn"><span class="fa fa-list"></span></a></nav>', esc_html( $grid_view ), esc_attr( $grid ), esc_html( $list_view ), esc_attr( $list ) );

			echo wp_kses_post( apply_filters( 'acmthemes_grid_list_buttons_output', $output ) );
		}

		/**
		 * Closes the opening div "acmthemes-toolbar" around top elements.
		 *
		 * @since 1.0.0
		 */
		public static function close_shop_loop_div() {
			echo '</div>';
		}

		/**
		 * Add result count.
		 *
		 * @since 1.0.0
		 */
		public static function result_count() {

			// Return if is not in shop page
			if ( ! acmthemes_is_woo_shop()
				&& ! is_product_category()
				&& ! is_product_tag() ) {
				return;
			}

			get_template_part( 'woocommerce/result-count' );
		}

		/**
		 * Returns correct posts per page for the shop
		 *
		 * @since 1.0.0
		 */
		public static function loop_shop_per_page() {

			$settings = (function_exists('acmthemes_settings')) ? acmthemes_settings() : "";

			if( isset( $_GET['products-per-page'] ) && !empty( $_GET['products-per-page'] ) ) {
				$products_per_page = sanitize_text_field( wp_unslash( $_GET['products-per-page'] ) );
			}
			else {
				$products_per_page = ( !empty( $settings['shop_products_count'] ) ) ? $settings['shop_products_count'] : '12';
			}

			return $products_per_page;
		}

		/**
		 * Change products per row for the main shop.
		 *
		 * @since 1.0.0
		 */
		public static function loop_shop_columns() {
			$settings = ( function_exists( 'acmthemes_settings' ) ) ? acmthemes_settings() : "";
			$columns = ( !empty( $settings['shop_product_columns'] ) ) ? $settings['shop_product_columns'] : '3';
			return $columns;
		}

		/**
		 * Change products per row for upsells.
		 *
		 * @since 1.0.0
		 */
		public static function upsell_display() {

			// Get count
			$count = 3;

			// Get columns
			$columns = 3;

			// Alter upsell display
			woocommerce_upsell_display( $count, $columns );

		}

		/**
		 * Change products per row for crossells.
		 *
		 * @since 1.0.0
		 */
		public static function cross_sell_display() {

			// Get count
			$count = 2;

			// Get columns
			$columns = 2;

			// Alter cross-sell display
			woocommerce_cross_sell_display( $count, $columns );

		}

		/**
		 * Alter the related product arguments.
		 *
		 * @since 1.0.0
		 */
		public static function related_product_args() {

			// Get global vars
			global $product, $orderby, $related;

			$settings = ( function_exists('acmthemes_settings') ) ? acmthemes_settings() : "";

			// Get posts per page
			$posts_per_page = ( !empty( $settings['shop_products_related_count'] ) ) ? $settings['shop_products_related_count'] : 4;

			// Get columns
			$columns = ( !empty( $settings['shop_products_related_count_per_row'] ) ) ? $settings['shop_products_related_count_per_row'] : 4;

			// Return array
			return array(
				'posts_per_page' => $posts_per_page,
				'columns'        => $columns,
			);

		}

		/**
		 * Adds an opening div "product-inner" around product entries.
		 *
		 * @since 1.0.0
		 */
		public static function add_shop_loop_item_inner_div() {
			echo '<div class="product-wrap clr">';
		}

		/**
		 * Adds an out of stock tag to the products.
		 *
		 * @since 1.0.0
		 */
		public static function add_out_of_stock_badge() {
			if ( function_exists( 'acmthemes_woo_product_instock' ) && ! acmthemes_woo_product_instock() ) {
				$label = esc_html__( 'Out of Stock', 'bookchoix' );  ?>
				<div class="outofstock-badge">
					<?php echo esc_html( apply_filters( 'woo_outofstock_text', $label ) ); ?>
				</div><!-- .product-entry-out-of-stock-badge -->
			<?php }
		}

		/**
		 * Returns our product thumbnail from our template parts based on selected style in theme mods.
		 *
		 * @since 1.0.0
		 */
		public static function loop_product_thumbnail() {
			if ( function_exists( 'wc_get_template' ) ) {
				// Get entry product media style
				$style = 'image-swap';
				// Get entry product media template part
				wc_get_template( 'loop/thumbnail/'. $style .'.php' );
			}
		}

		/**
		 * Archive product content.
		 *
		 * @since 1.0.0
		 */
		public static function archive_product_content() {
			if ( function_exists( 'wc_get_template' ) ) {
					wc_get_template( 'acm-archive-product.php' );
			}
		}

		/**
		 * Closes the "product-inner" div around product entries.
		 *
		 * @since 1.0.0
		 */
		public static function close_shop_loop_item_inner_div() {
			echo '</div><!-- .product-inner .clr -->';
		}

		/**
		 * Quick view button.
		 *
		 * @since 1.0.0
		 */
		public static function quick_view_button() {
			global $product;

			$button  = '<a href="#" id="product_id_' . $product->get_id() . '" class="owp-quick-view" data-product_id="' . $product->get_id() . '"><i class="icon-eye"></i>' . esc_html__( 'Quick View', 'bookchoix' ) . '</a>';

			echo apply_filters( 'woo_quick_view_button_html', $button );
		}

		/**
		 * Quick view ajax.
		 *
		 * @since 1.0.0
		 */
		public static function product_quick_view_ajax() {
			if ( ! isset( $_REQUEST['product_id'] ) ) {
				die();
			}

			$product_id = intval( $_REQUEST['product_id'] );

			// wp_query for the product.
			wp( 'p=' . $product_id . '&post_type=product' );

			ob_start();

			get_template_part( 'woocommerce/quick-view-content' );

			echo ob_get_clean();

			die();
		}

		/**
		 * Quick view template.
		 *
		 * @since 1.0.0
		 */
		public static function quick_view_template() {
			get_template_part( 'woocommerce/quick-view' );
		}

		/**
		 * Quick view image.
		 *
		 * @since 1.0.0
		 */
		public static function quick_view_image() {
			get_template_part( 'woocommerce/quick-view-image' );
		}

		/**
		 * Clear floats after single product summary.
		 *
		 * @since 1.0.0
		 */
		public static function clear_summary_floats() {
			echo '<div class="clear-after-summary clr"></div>';
		}

		/**
		 * Single product content.
		 *
		 * @since 1.0.0
		 */
		public static function single_product_content() {
			if ( function_exists( 'wc_get_template' ) ) {
				wc_get_template( 'woo-single-product.php' );
			}
		}

		/**
		 * Add floating bar.
		 *
		 * @since 1.0.0
		 */
		public static function floating_bar() {

			// Return if is not single product
			if ( ! acmthemes_is_woo_single() ) {
				return;
			}

			// Get product object
			$product = wc_get_product( get_the_ID() );

			// Select options text
			$text = esc_html__( 'Select Options', 'bookchoix' );
			$text = apply_filters( 'floating_bar_select_text', $text ); ?>

			<div class="owp-floating-bar">
				<div class="container clr">
					<div class="left">
				        <p class="selected"><?php esc_html_e( 'Selected:', 'bookchoix' ); ?></p>
				        <h2 class="entry-title" itemprop="name"><?php echo wp_kses_post ( $product->get_title() ) ?></h2>
				    </div>
					<div class="right">
				        <div class="product_price">
				        	<p class="price"><?php echo wp_kses_post ( $product->get_price_html() ); ?></p>
		                </div>
		                <?php
		                // If out of stock
		                if ( 'outofstock' == $product->get_stock_status() ) { ?>
		                	<p class="stock out-of-stock"><?php esc_html_e( 'Out of stock', 'bookchoix' ); ?></p>
		            	<?php
		            	} else if ( $product && $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() && ! $product->is_sold_individually() ) {
		                	echo self::floating_bar_add_to_cart( $product );
		            	} else { ?>
		                	<button type="submit" class="button top"><?php echo esc_attr( $text ); ?></button>
		                <?php
		            	} ?>
				    </div>
		        </div>
		    </div>

		<?php
		}

		/**
		 * Floating bar add to cart button.
		 *
		 * @since 1.0.0
		 */
		public static function floating_bar_add_to_cart( $product ) {

			$html = '<form action="' . esc_url( $product->add_to_cart_url() ) . '" class="cart" method="post" enctype="multipart/form-data">';
			$html .= woocommerce_quantity_input( array(), $product, false );
			$html .= '<button type="submit" name="add-to-cart" value="' . get_the_ID() . '" class="floating_add_to_cart_button button alt">' . esc_html( $product->add_to_cart_text() ) . '</button>';
			$html .= '</form>';

			return $html;
		}

		/**
		 * Floating bar add to cart ajax request.
		 *
		 * @since 1.5.0
		 */
		public static function add_cart_floating_bar_ajax() {

			$product_id   = sanitize_text_field( $_POST['product_id'] );
			$quantity     = sanitize_text_field( $_POST['quantity'] );

			WC()->cart->add_to_cart( $product_id, $quantity );

			die();

		}

		/**
		 * Add wrap and user info to the account navigation.
		 *
		 * @since 1.0.0
		 */
		public static function acmthemes_before_account_navigation() {

			// Name to display
			$current_user = wp_get_current_user();

			if ( $current_user->display_name ) {
				$name = $current_user->display_name;
			} else {
				$name = esc_html__( 'Welcome!', 'bookchoix' );
			}
			$name = apply_filters( 'user_profile_name_text', $name );

			echo '<div class="woocommerce-MyAccount-tabs clr">';
				echo '<div class="acmthemes-user-profile clr">';
					echo '<div class="image">'. get_avatar( $current_user->user_email, 128 ) .'</div>';
					echo '<div class="user-info">';
						echo '<p class="name">'. esc_attr( $name ) .'</p>';
						echo '<a class="logout" href="'. esc_url( wp_logout_url( get_permalink() ) ) .'">'. esc_html__( 'Logout', 'bookchoix' ) .'</a>';
					echo '</div>';
				echo '</div>';

		}

		/**
		 * Add wrap to the account navigation.
		 *
		 * @since 1.0.0
		 */
		public static function acmthemes_after_account_navigation() {
			echo '</div>';
		}

		/**
		 * Adds container wrap for the thumbnail and title of the categories products.
		 *
		 * @since 1.1.1.1
		 */
		public static function add_container_wrap_category() {
			echo '<div class="product-inner clr">';
		}

		/**
		 * Adds a container div before the thumbnail for the categories products.
		 *
		 * @since 1.1.1.1
		 */
		public static function add_div_before_category_thumbnail( $category ) {
			echo '<div class="woo-entry-image clr">';
				echo '<a href="' . esc_url( get_term_link( $category, 'product_cat' ) ) . '">';
		}

		/**
		 * Close a container div before the thumbnail for the categories products.
		 *
		 * @since 1.1.1.1
		 */
		public static function close_div_after_category_thumbnail() {
				echo '</a>';
			echo '</div>';
		}

		/**
		 * Adds a container div before the thumbnail for the categories products.
		 *
		 * @since 1.1.1.1
		 */
		public static function add_div_before_category_title( $category ) {
			echo '<div class="woo-entry-inner clr">';
				echo '<a href="' . esc_url( get_term_link( $category, 'product_cat' ) ) . '">';
		}

		/**
		 * Add description if list view for the categories products.
		 *
		 * @since 1.0.0
		 */
		public static function add_category_description( $category ) {
			// Close category link openend in add_div_before_category_title()
			echo '</a>';

			 // Var
			$term           = get_term( $category->term_id, 'product_cat' );
			$description    = $term->description;
			$length 		= get_theme_mod( 'woo_list_excerpt_length', '60' );

			// Description
			if ( $description ) {
				echo '<div class="woo-desc">';
					echo '<div class="description">';
						if ( ! $length ) {
							echo wp_kses_post( strip_shortcodes( $description ) );
						} else {
							echo wp_trim_words( strip_shortcodes( $description ), $length );
						}
					echo '</div>';
				echo '</div>';
			}
		}

		/**
		 * Close a container div before the thumbnail for the categories products.
		 *
		 * @since 1.1.1.1
		 */
		public static function close_div_after_category_title() {
			echo '</div>';
		}

		/**
		 * Close container wrap for the thumbnail and title of the categories products.
		 *
		 * @since 1.1.1.1
		 */
		public static function close_container_wrap_category() {
			echo '</div>';
		}

		/**
		 * Before my account login.
		 *
		 * @since 1.0.0
		 */
		public static function acmthemes_login_wrap_before() {
			echo '<div class="acmthemes-loginform-wrap">';
		}

		/**
		 * After my account login.
		 *
		 * @since 1.0.0
		 */
		public static function acmthemes_login_wrap_after() {
			echo '</div>';
		}

		/**
		 * Display the categories featured images.
		 *
		 * @since 1.0.0
		 */
		public static function woocommerce_category_image() {
			if ( is_product_category() ) {
			    global $wp_query;
			    $cat 			= $wp_query->get_queried_object();
			    $thumbnail_id 	= get_term_meta( $cat->term_id, 'thumbnail_id', true );
			    $image 			= wp_get_attachment_url( $thumbnail_id );

			    if ( $image && 1 == 2 ) {
				    echo '<div class="category-image"><img src="' . $image . '" alt="' . $cat->name . '" /></div>';
				}
			}
		}

		/**
		 * Tweaks pagination arguments.
		 *
		 * @since 1.0.0
		 */
		public static function pagination_args( $args ) {
			$args['prev_text'] = '<i class="fa fa-angle-left"></i>';
			$args['next_text'] = '<i class="fa fa-angle-right"></i>';
			return $args;
		}

		/**
		 * Alter continue shoping URL.
		 *
		 * @since 1.0.0
		 */
		public static function continue_shopping_redirect( $return_to ) {
			$shop_id = wc_get_page_id( 'shop' );
			if ( function_exists( 'icl_object_id' ) ) {
				$shop_id = icl_object_id( $shop_id, 'page' );
			}
			if ( $shop_id ) {
				$return_to = get_permalink( $shop_id );
			}
			return $return_to;
		}

		/**
		 * Add classes to WooCommerce product entries.
		 *
		 * @since 1.0.0
		 */
		public static function add_product_classes( $classes ) {
			global $woocommerce_loop;

			// Vars
			$product 			= wc_get_product( get_the_ID() );
			$content_alignment 	= 'center';
			$thumbs_layout 		= 'horizontal';
			$tabs_layout 		= 'horizontal';
			$btn_style 			= 'normal';

			// Product entries
			if ( $product && ! empty( $woocommerce_loop['columns'] ) ) {

				// If has rating
				if ( $product->get_rating_count() ) {
					$classes[] = 'has-rating';
				}

				//product navigation class
				$classes[] = 'has-product-nav';

				$classes[] = 'col';
				$classes[] = acmthemes_grid_class( $woocommerce_loop['columns'] );
				$classes[] = 'owp-content-'. $content_alignment;

			}

			// Single product
			if ( post_type_exists( 'product' ) ) {

				// Thumbnails layout
				$classes[] = 'owp-thumbs-layout-' . $thumbs_layout;

				// Add to cart button style
				$classes[] = 'owp-btn-' . $btn_style;

				// Tabs layout
				$classes[] = 'owp-tabs-layout-' . $tabs_layout;

				// If no thumbnails
				$thumbnails = get_post_meta( get_the_ID(), '_product_image_gallery', true );
				if ( empty( $thumbnails ) ) {
					$classes[] = 'has-no-thumbnails';
				}

			}

			return $classes;
		}

		/**
		 * Add the product class to the Elementor editor to fix the product display issue.
		 *
		 * @since 1.5.18
		 */
		public static function add_product_class_for_elementor( $classes ) {
			if ( in_array( 'type-product', $classes ) ) {
	            $classes[] = 'product';
	        }
			return $classes;
		}

		/**
		 * Remove the category description under the page title on taxonomy.
		 *
		 * @since 1.4.7
		 */
		public static function post_subheading( $return ) {
			if ( is_woocommerce() && is_product_taxonomy() ) {
				$return = false;
			}
			return $return;
		}

		/**
		 * Disables the next/previous links.
		 *
		 * @since 1.0.0
		 */
		public static function next_prev( $return ) {
			if ( is_woocommerce() && is_singular( 'product' ) ) {
				$return = false;
			}
			return $return;
		}

		/**
		 * Adds color accents for WooCommerce styles.
		 *
		 * @since 1.0.0
		 */
		public static function primary_texts( $texts ) {
			return array_merge( array(
				'.woocommerce-MyAccount-navigation ul li a:before',
				'.woocommerce-checkout .woocommerce-info a',
				'.woocommerce-checkout #payment ul.payment_methods .wc_payment_method>input[type=radio]:first-child:checked+label:before',
				'.woocommerce-checkout #payment .payment_method_paypal .about_paypal',
				'.woocommerce ul.products li.product li.category a:hover',
				'.woocommerce ul.products li.product .button:hover',
				'.woocommerce ul.products li.product .product-inner .added_to_cart:hover',
				'.product_meta .posted_in a:hover',
				'.product_meta .tagged_as a:hover',
				'.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover',
				'.woocommerce div.product .woocommerce-tabs ul.tabs li.active a',
				'.woocommerce .acmthemes-grid-list a.active',
				'.woocommerce .acmthemes-grid-list a:hover',
				'.woocommerce .acmthemes-off-canvas-filter:hover',
				'.widget_shopping_cart ul.cart_list li .owp-grid-wrap .owp-grid a.remove:hover',
				'.widget_product_categories li a:hover ~ .count',
				'.widget_layered_nav li a:hover ~ .count',
				'.woocommerce ul.products li.product:not(.product-category) .woo-entry-buttons li a:hover',
			), $texts );
		}

		/**
		 * Adds border accents for WooCommerce styles.
		 *
		 * @since 1.0.0
		 */
		public static function primary_borders( $borders ) {
			return array_merge( array(
				'.current-shop-items-dropdown' => array( 'top' ),
				'.woocommerce div.product .woocommerce-tabs ul.tabs li.active a' => array( 'bottom' ),
				'.wcmenucart-details.count:before',
				'.woocommerce ul.products li.product .button:hover',
				'.woocommerce ul.products li.product .product-inner .added_to_cart:hover',
				'.woocommerce div.product .woocommerce-tabs ul.tabs li.active a',
				'.woocommerce .acmthemes-grid-list a.active',
				'.woocommerce .acmthemes-grid-list a:hover',
				'.woocommerce .acmthemes-off-canvas-filter:hover',
				'.owp-product-nav li a.owp-nav-link:hover',
				'.widget_shopping_cart_content .buttons .button:first-child:hover',
				'.widget_shopping_cart ul.cart_list li .owp-grid-wrap .owp-grid a.remove:hover',
				'.widget_product_categories li a:hover ~ .count',
				'.woocommerce .widget_product_categories li.current-cat > a ~ .count',
				'.woocommerce .widget_product_categories li.current-cat > a:before',
				'.widget_layered_nav li a:hover ~ .count',
				'.woocommerce .widget_layered_nav li.chosen a ~ .count',
				'.woocommerce .widget_layered_nav li.chosen a:before',
				'#owp-checkout-timeline.arrow .active .timeline-wrapper:before' => array( 'top', 'bottom' ),
				'#owp-checkout-timeline.arrow .active .timeline-wrapper:after' => array( 'left', 'right' ),
				'.bag-style:hover .wcmenucart-cart-icon .wcmenucart-count',
				'.bag-style:hover .wcmenucart-cart-icon .wcmenucart-count:after',
				'.show-cart .wcmenucart-cart-icon .wcmenucart-count',
				'.show-cart .wcmenucart-cart-icon .wcmenucart-count:after',
				'.woocommerce ul.products li.product:not(.product-category) .woo-product-gallery .active a',
				'.woocommerce ul.products li.product:not(.product-category) .woo-product-gallery a:hover',
			), $borders );
		}

		/**
		 * Adds background accents for WooCommerce styles.
		 *
		 * @since 1.0.0
		 */
		public static function primary_backgrounds( $backgrounds ) {
			return array_merge( array(
				'.woocommerce div.product div.images .open-image',
				'.wcmenucart-details.count',
				'.woocommerce-message a',
				'.woocommerce-error a',
				'.woocommerce-info a',
				'.woocommerce .widget_price_filter .ui-slider .ui-slider-handle',
				'.woocommerce .widget_price_filter .ui-slider .ui-slider-range',
				'.owp-product-nav li a.owp-nav-link:hover',
				'.woocommerce div.product.owp-tabs-layout-vertical .woocommerce-tabs ul.tabs li a:after',
				'.woocommerce .widget_product_categories li.current-cat > a ~ .count',
				'.woocommerce .widget_product_categories li.current-cat > a:before',
				'.woocommerce .widget_layered_nav li.chosen a ~ .count',
				'.woocommerce .widget_layered_nav li.chosen a:before',
				'#owp-checkout-timeline .active .timeline-wrapper',
				'.bag-style:hover .wcmenucart-cart-icon .wcmenucart-count',
				'.show-cart .wcmenucart-cart-icon .wcmenucart-count',
				'.woocommerce ul.products li.product:not(.product-category) .image-wrap .button',
			), $backgrounds );
		}

		/**
		 * Adds background hover accents for WooCommerce styles.
		 *
		 * @since 1.0.0
		 */
		public static function hover_primary_backgrounds( $hover ) {
			return array_merge( array(
				'.woocommerce div.product div.images .open-image:hover',
				'.woocommerce-error a:hover',
				'.woocommerce-info a:hover',
				'.woocommerce-message a:hover',
				'.woocommerce ul.products li.product:not(.product-category) .image-wrap .button:hover',
			), $hover );
		}

		/**
		 * Adds border color elements for WooCommerce styles.
		 *
		 * @since 1.0.0
		 */
		public static function border_color_elements( $elements ) {
			return array_merge( array(
				'.woocommerce table.shop_table',
				'.woocommerce table.shop_table td',
				'.woocommerce-cart .cart-collaterals .cart_totals tr td',
				'.woocommerce-cart .cart-collaterals .cart_totals tr th',
				'.woocommerce table.shop_table tth',
				'.woocommerce table.shop_table tfoot td',
				'.woocommerce table.shop_table tfoot th',
				'.woocommerce .order_details',
				'.woocommerce .shop_table.order_details tfoot th',
				'.woocommerce .shop_table.customer_details th',
				'.woocommerce .cart-collaterals .cross-sells',
				'.woocommerce-page .cart-collaterals .cross-sells',
				'.woocommerce .cart-collaterals .cart_totals',
				'.woocommerce-page .cart-collaterals .cart_totals',
				'.woocommerce .cart-collaterals h2',
				'.woocommerce .cart-collaterals h2',
				'.woocommerce .cart-collaterals h2',
				'.woocommerce-cart .cart-collaterals .cart_totals .order-total th',
				'.woocommerce-cart .cart-collaterals .cart_totals .order-total td',
				'.woocommerce ul.order_details',
				'.woocommerce .shop_table.order_details tfoot th',
				'.woocommerce .shop_table.customer_details th',
				'.woocommerce .woocommerce-checkout #customer_details h3',
				'.woocommerce .woocommerce-checkout h3#order_review_heading',
				'.woocommerce-checkout #payment ul.payment_methods',
				'.woocommerce-checkout form.login',
				'.woocommerce-checkout form.checkout_coupon',
				'.woocommerce-checkout-review-order-table tfoot th',
				'.woocommerce-checkout #payment',
				'.woocommerce ul.order_details',
				'.woocommerce #customer_login > div',
				'.woocommerce .col-1.address',
				'.woocommerce .col-2.address',
				'.woocommerce-checkout .woocommerce-info',
				'.woocommerce div.product form.cart',
				'.product_meta',
				'.woocommerce div.product .woocommerce-tabs ul.tabs',
				'.woocommerce #reviews #comments ol.commentlist li .comment_container',
				'p.stars span a',
				'.woocommerce ul.product_list_widget li',
				'.woocommerce .widget_shopping_cart .cart_list li',
				'.woocommerce.widget_shopping_cart .cart_list li',
				'.woocommerce ul.product_list_widget li:first-child',
				'.woocommerce .widget_shopping_cart .cart_list li:first-child',
				'.woocommerce.widget_shopping_cart .cart_list li:first-child',
				'.widget_product_categories li a',
				'.woocommerce .acmthemes-toolbar',
				'.woocommerce .products.list .product',
			), $elements );
		}

		/**
		 * Alter WooCommerce category classes
		 *
		 * @since 1.0.0
		 */
		public static function product_cat_class( $classes ) {
			global $woocommerce_loop;
			$classes[] = 'col';
			$classes[] = acmthemes_grid_class( $woocommerce_loop['columns'] );
			return $classes;
		}

		/**
		 * Adds cart icon to menu
		 *
		 * @since 1.0.0
		 */
		public static function menu_cart_icon( $items, $args ) {

			// Return items if is in the Elementor edit mode, to avoid error
			if ( ACMTHEMES_ELEMENTOR_ACTIVE
				&& \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				return $items;
			}

			// Only used for the main menu
			if ( 'main_menu' != $args->theme_location ) {
				return $items;
			}

			// Get style
			$style 			= acmthemes_menu_cart_style();
			$header_style 	= acmthemes_header_style();

			// Return items if no style
			if ( ! $style ) {
				return $items;
			}

			// Add cart link to menu items
			if ( 'full_screen' == $header_style ) {
				$items .= '<li class="woo-cart-link"><a href="'. esc_url( wc_get_cart_url() ) .'">'. esc_html__( 'Your cart', 'bookchoix' ) .'</a></li>';
			} else {
				$items .= self::get_cart_icon();
			}

			// Return menu items
			return $items;
		}

		/**
		 * Add cart icon
		 *
		 * @since 1.0.0
		 */
		public static function get_cart_icon() {

			// Style
			$style = acmthemes_menu_cart_style();
			$header_style = acmthemes_header_style();

			// Toggle class
			$toggle_class = 'toggle-cart-widget';

			// Define classes to add to li element
			$classes = array( 'woo-menu-icon' );

			// Add style class
			$classes[] = 'wcmenucart-toggle-'. $style;

			// Prevent clicking on cart and checkout
			if ( 'custom_link' != $style && ( is_cart() || is_checkout() ) ) {
				$classes[] = 'nav-no-click';
			}

			// Add toggle class
			else {
				$classes[] = $toggle_class;
			}

			// Turn classes into string
			$classes = implode( ' ', $classes );

			ob_start(); ?>

			<li class="<?php echo esc_attr( $classes ); ?>">
				<?php acmthemes_wcmenucart_menu_item(); ?>
			</li>

			<?php
			return ob_get_clean();

		}

		/**
		 * Add menu cart item to the Woo fragments so it updates with AJAX
		 *
		 * @since 1.0.0
		 */
		public static function menu_cart_icon_fragments( $fragments ) {
			ob_start();
			acmthemes_wcmenucart_menu_item();
			$fragments['li.woo-menu-icon a.wcmenucart, .acmthemes-mobile-menu-icon a.wcmenucart'] = ob_get_clean();

			return $fragments;
		}

		/**
		 * Sale badge content
		 *
		 * @since 1.0.0
		 */
		public static function sale_flash() {
			global $product;

			if ( $product->is_type( 'simple' ) || $product->is_type( 'external' ) ) {

				$r_price 	= $product->get_regular_price();
				$s_price 	= $product->get_sale_price();
				$percent 	= round( ( ( floatval( $r_price ) - floatval( $s_price ) ) / floatval( $r_price ) ) * 100 );

			} else if ( $product->is_type( 'variable' ) ) {

				$available_variations = $product->get_available_variations();
				$maximumper           = 0;

				for ( $i = 0; $i < count( $available_variations ); ++ $i ) {
					$variation_id     = $available_variations[ $i ]['variation_id'];
					$variable_product = new WC_Product_Variation( $variation_id );

					if ( ! $variable_product->is_on_sale() ) {
						continue;
					}

					$r_price 	= $variable_product->get_regular_price();
					$s_price    = $variable_product->get_sale_price();
					$percent 	= round( ( ( floatval( $r_price ) - floatval( $s_price ) ) / floatval( $r_price ) ) * 100 );

					if ( $percent > $maximumper ) {
						$maximumper = $percent;
					}
				}

				$percent = sprintf( esc_html__( '%s', 'bookchoix' ), $maximumper );

			} else {

				$percent = '<span class="onsale">' . esc_html__( 'Sale!', 'bookchoix' ) . '</span>';
				return $percent;

			}

			$value = '-' . esc_html( $percent ) . '%';

			return '<span class="onsale">' . esc_html( $value ) . '</span>';
		}

		/**
		 * Add links Login/Register on the my account page
		 *
		 * @since 1.0.0
		 */
		public static function login_register_links() {

			// Var
			$registration = get_option( 'woocommerce_enable_myaccount_registration' );

			// Define classes
			$classes = array( 'owp-account-links' );

			// If registration disabled
			if ( 'yes' != $registration ) {
				$classes[] = 'registration-disabled';
			}

			// Turn classes into string
			$classes = implode( ' ', $classes );

			// Login text
			$text = esc_html__( 'Login', 'bookchoix' );

			$html = '<ul class="'. $classes .'">';
				$html .= '<li class="login">';
					if ( 'yes' == $registration ) {
					    $html .= '<a href="#" class="owp-account-link current">'. $text .'</a>';
					} else {
					    $html .= '<span class="owp-account-link current">'. $text .'</span>';
					}
				$html .= '</li>';

				// If registration
				if ( 'yes' == $registration ) {
					$html .= '<li class="or">'. esc_html__( 'Or', 'bookchoix' ) .'</li>';
					$html .= '<li class="register">';
						$html .= '<a href="#" class="owp-account-link">'. esc_html__( 'Register', 'bookchoix' ) .'</a>';
					$html .= '</li>';
				}

			$html .= '</ul>';

			echo wp_kses_post ( $html );
		}


		/**
		 * Checkout login form.
		 *
		 * @since 1.0.0
		 */
		public static function checkout_login_form( $login_message ) {
			woocommerce_login_form(
				array(
					'message'  => $login_message,
					'redirect' => wc_get_page_permalink( 'checkout' ),
					'hidden'   => false
				)
			);

			// If WooCommerce social login
			if ( class_exists( 'WC_Social_Login' ) ) {
                do_shortcode( '[woocommerce_social_login_buttons]' );
            }
		}

		/**
		 * Support to WooCommerce secure submit gateway
		 *
		 * @since 1.0.0
		 */
		public static function woocommerce_securesubmit_support( $value, $options ) {
            $value['use_iframes'] = 'no';
            return $value;
        }


		/**
		 * Supports WooCommerce Match Box extension by removing
		 * duplicate single product summary features on the
		 * product page.
		 *
		 * @since 1.0.0
		 * @static
		 * @author Sébastien Dumont
		 * @global object WC_Product $product
		 */
		public function remove_wc_match_box_single_product_summary() {
			global $product;

			if ( $product->is_type( 'mix-and-match' ) ) {
				remove_action( 'woocommerce_single_product_summary', array( $this, 'single_product_content' ), 10 );
				add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
			}
		}

		/**
		 * Compatibility with YITH WooCommerce Badge.
		 *
		 * @since 1.0.0
		 */
		public function yith_wcbm_shop_badge_container_start() {
			do_action( 'yith_wcbm_theme_badge_container_start' );
		}

		/**
		 * Compatibility with YITH WooCommerce Badge.
		 *
		 * @since 1.0.0
		 */
		public function yith_wcbm_shop_badge_container_end() {
			do_action( 'yith_wcbm_theme_badge_container_end' );
		}

		/**
		 * Compatibility with WooCommerce Germanized.
		 *
		 * @since 1.0.0
		 */
		public function woocommerce_germanized() {
			echo '<li class="wc-gzd">';
				wc_get_template( 'single-product/tax-info.php' );
				wc_get_template( 'single-product/shipping-costs-info.php' );
			echo '</li>';
		}


	}

}
new ACMTHEMES_WOOCOMMERCE_CONFIG();
