<?php
/**
 * Header content
 *
 * @package BookChoix WordPress theme
 */

// Vars
$header_style = acmthemes_header_style();
$position = 'one';
$woo_icon_visibility = 'default';


add_action( 'after_logo_inner', 'acmthemes_mobile_icon', 1 );

add_action( 'header_inner_middle_content', 'acmthemes_header_logo', 10 );

add_action( 'header_inner_right_content', 'acmthemes_header_navigation', 12 );

/**
 * Header logo
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_logo' ) ) {

	function acmthemes_header_logo() {

		get_template_part( 'partials/header/logo' );

	}

}

/**
 * Header social
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_social' ) ) {

	function acmthemes_header_social() {

		get_template_part( 'partials/header/social' );

	}

}

/**
 * Header navigation
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_header_navigation' ) ) {

	function acmthemes_header_navigation() {

		get_template_part( 'partials/header/nav' );

	}

}

/**
 * Header navigation
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'acmthemes_mobile_icon' ) ) {

	function acmthemes_mobile_icon() {

		get_template_part( 'partials/mobile/mobile-icon' );

	}

}

if( ! function_exists( 'acmthemes_header_style2_content' ) ) {

	function acmthemes_header_style2_content() {

		$settings = acmthemes_settings();
		$header_style = acmthemes_header_style();

		if( $header_style == 'header-fullwidth-navi' && isset( $settings['header_style2_right_content'] ) && ! empty( $settings['header_style2_right_content'] ) ) {
			get_template_part( 'partials/header/custom-content' );
		}

	}

}
