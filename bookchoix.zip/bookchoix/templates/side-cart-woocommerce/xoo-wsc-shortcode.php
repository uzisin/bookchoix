<?php
/**
 * Basket Shortcode
 *
 * This template can be overridden by copying it to yourtheme/templates/side-cart-woocommerce/xoo-wsc-shortcode.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen.
 * @see     https://docs.xootix.com/side-cart-woocommerce/
 * @version 2.2
 */


if ( ! defined( 'ABSPATH' ) || !WC() || !WC()->cart ) {
	exit; // Exit if accessed directly
}

extract( Xoo_Wsc_Template_Args::cart_shortcode() );
$cart_id = wc_get_page_id( 'cart' );
if ( function_exists( 'icl_object_id' ) ) {
	$cart_id = icl_object_id( $cart_id, 'page' );
}
$url = get_permalink( $cart_id );
?>


<div class="xoo-wsc-sc-cont">
  <div class="xoo-wsc-cart-trigger">

	<?php if( 1 == 2 && $subtotal === 'yes' ): ?>
		<span class="xoo-wsc-sc-subt">
			<?php echo WC()->cart->get_cart_subtotal() ?>
		</span>
	<?php endif; ?>


	<div class="xoo-wsc-sc-bkcont">		

		<a href="<?php echo esc_url( $url ); ?>" class="wcmenucart xoo-wsc-cart-trigger"><i class="icon-handbag"></i>
		<span class="xoo-wsc-sc-count wcmenucart-details count"><?php echo esc_html( xoo_wsc_cart()->get_cart_count() ) ?></span>				
		</a>
	</div>

	<?php do_action( 'xoo_wsc_cart_shortcode_content' ); ?>

	</div>
</div>