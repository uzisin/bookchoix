<?php
/**
 * Template Name: Landing Page
 * The template for displaying Full width Landing page.
 * @package BookChoix WordPress theme
 */

get_header();

$settings = acmthemes_settings();
?>

	<?php do_action( 'before_content_wrap' ); ?>

		<?php do_action( 'before_primary' ); ?>

		<div id="primary" class="content-area-full clr">

			<?php do_action( 'before_content' ); ?>

			<div id="content" class="site-content clr">

				<?php do_action( 'before_content_inner' ); ?>

				<?php
				// Elementor `single` location
				if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) {

					// Start loop
					while ( have_posts() ) : the_post();

						get_template_part( 'partials/page/layout' );

					endwhile;

				} ?>

				<?php do_action( 'after_content_inner' ); ?>

			</div><!-- #content -->

			<?php do_action( 'after_content' ); ?>

		</div><!-- #primary -->

		<?php do_action( 'after_primary' ); ?>

	<?php do_action( 'after_content_wrap' ); ?>

<?php get_footer(); ?>
