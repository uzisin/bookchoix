<?php
/**
 * preloader html for all pages
 *
 * @package BookChoix WordPress theme
 */
 //get framework settings
 $settings = acmthemes_settings();
 if( isset( $settings['disable_preloader'] ) && 1 == $settings['disable_preloader'] )
    return;
?>
<div id="preloader-wrap">
  <div class="preloader">
    <div class="cssload-box-loading">
    </div>
  </div>
  <div class="preloader-text"><?php echo esc_attr('Loading', 'bookchoix'); ?></div>
</div>
